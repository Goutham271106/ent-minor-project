from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
try:
    from flask_mysqldb import MySQL
except ImportError:
    MySQL = None
from database import DBWrapper
from werkzeug.utils import secure_filename
import os
import datetime
import random

app = Flask(__name__)
app.secret_key = os.environ.get('FLASK_SECRET_KEY', 'dev-only-change-this-secret')

# Upload folder config for expenses
is_vercel = (
    os.environ.get('VERCEL') == '1' or 
    os.environ.get('VERCEL_ENV') is not None or
    'AWS_LAMBDA_FUNCTION_NAME' in os.environ or
    os.environ.get('LAMBDA_TASK_ROOT') is not None or
    os.path.exists('/var/task')
)
if is_vercel:
    UPLOAD_FOLDER = '/tmp/expenses'
else:
    UPLOAD_FOLDER = os.path.join(app.root_path, 'static', 'uploads', 'expenses')

try:
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
except Exception as e:
    print("Warning: could not create UPLOAD_FOLDER:", e)

# Helper functions to encrypt and decrypt transcripts in database
def encrypt_text(plain_text):
    if not plain_text:
        return ""
    data = plain_text.encode('utf-8')
    encrypted = bytearray(data)
    for i in range(len(encrypted)):
        encrypted[i] ^= 0x3C
    return encrypted.hex()

def decrypt_text(hex_str):
    if not hex_str:
        return ""
    try:
        data = bytearray.fromhex(hex_str)
        for i in range(len(data)):
            data[i] ^= 0x3C
        return data.decode('utf-8')
    except Exception:
        return hex_str

def encrypt_json(data_dict):
    import json
    plain_text = json.dumps(data_dict)
    return encrypt_text(plain_text)

def decrypt_json(hex_str):
    import json
    plain_text = decrypt_text(hex_str)
    try:
        return json.loads(plain_text)
    except Exception:
        return {}

# MySQL Config
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'mysql'
app.config['MYSQL_DB'] = 'trisense_db'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'

# Initialize MySQL instance
if MySQL is not None:
    try:
        mysql = MySQL(app)
    except Exception:
        mysql = None
else:
    mysql = None
db = None

def get_db():
    global db
    if db is None:
        try:
            # Test if MySQL connection works
            if mysql is not None and mysql.connection:
                db = DBWrapper(mysql)
            else:
                db = DBWrapper(mysql_instance=None)
        except Exception:
            db = DBWrapper(mysql_instance=None)
    return db

@app.before_request
def setup_db():
    get_db()

def log_action(action, old_val=None, new_val=None):
    try:
        username = session.get('username', 'system')
        now = datetime.datetime.now()
        log_date = now.strftime('%Y-%m-%d')
        log_time = now.strftime('%H:%M:%S')
        get_db().query(
            "INSERT INTO audit_logs (username, action, log_date, log_time, old_value, new_value) VALUES (%s, %s, %s, %s, %s, %s)",
            (username, action, log_date, log_time, str(old_val) if old_val is not None else None, str(new_val) if new_val is not None else None),
            commit=True
        )
    except Exception as ex:
        print("Audit logging error:", ex)

def get_date_conditions(field_name):
    db = get_db()
    if db.use_sqlite:
        return {
            'today': f"DATE({field_name}) = date('now')",
            'month': f"strftime('%Y-%m', {field_name}) = strftime('%Y-%m', 'now')",
            'year': f"strftime('%Y', {field_name}) = strftime('%Y', 'now')"
        }
    else:
        return {
            'today': f"DATE({field_name}) = CURDATE()",
            'month': f"DATE_FORMAT({field_name}, '%Y-%m') = DATE_FORMAT(CURDATE(), '%Y-%m')",
            'year': f"DATE_FORMAT({field_name}, '%Y') = DATE_FORMAT(CURDATE(), '%Y')"
        }

# Middleware/Decorators for authentication
def login_required(f):
    def wrap(*args, **kwargs):
        if 'logged_in' not in session:
            return redirect(url_for('login'))
        return f(*args, **kwargs)
    wrap.__name__ = f.__name__
    return wrap

def role_required(roles):
    def decorator(f):
        def wrap(*args, **kwargs):
            if 'logged_in' not in session:
                return redirect(url_for('login'))
            if session.get('role') not in roles:
                flash("Unauthorized access!", "danger")
                return redirect(url_for('dashboard_redirect'))
            return f(*args, **kwargs)
        wrap.__name__ = f.__name__
        return wrap
    return decorator

@app.route('/')
def index():
    if 'logged_in' in session:
        return redirect(url_for('dashboard_redirect'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = get_db().query("SELECT * FROM users WHERE username = %s AND password = %s", (username, password), one=True)
        if user:
            session['logged_in'] = True
            session['user_id'] = user['user_id'] if 'user_id' in user else user.get('user_id')
            session['username'] = user['username'] if 'username' in user else user.get('username')
            session['role'] = user['role'] if 'role' in user else user.get('role')
            log_action("User Logged In", None, f"Role: {user['role']}")
            return redirect(url_for('dashboard_redirect'))
        else:
            flash("Invalid credentials, please try again.", "danger")
            
    return render_template('login.html')

@app.route('/logout')
def logout():
    log_action("User Logged Out")
    session.clear()
    return redirect(url_for('login', logged_out=1))

@app.route('/dashboard')
@login_required
def dashboard_redirect():
    role = session.get('role')
    if role == 'Admin':
        return redirect(url_for('admin_dashboard'))
    elif role == 'Doctor':
        return redirect(url_for('doctor_dashboard'))
    elif role == 'Reception':
        return redirect(url_for('reception_dashboard'))
    elif role == 'Pharmacy':
        return redirect(url_for('pharmacy_dashboard'))
    return redirect(url_for('login'))


# Helper function to parse dates robustly
def parse_date(date_val):
    if not date_val:
        return None
    if isinstance(date_val, str):
        try:
            return datetime.datetime.strptime(date_val.split('.')[0], "%Y-%m-%d %H:%M:%S")
        except ValueError:
            try:
                return datetime.datetime.strptime(date_val.split('T')[0], "%Y-%m-%d")
            except ValueError:
                return None
    return date_val


# Atomic Billing recalculation for a patient
def recalculate_patient_billing(patient_id):
    # Sum bills
    bills_total = get_db().query("SELECT COALESCE(SUM(amount), 0) as total FROM bills WHERE patient_id = %s", (patient_id,), one=True)['total']
    # Sum payments
    payments_total = get_db().query("SELECT COALESCE(SUM(amount_paid), 0) as total FROM payments WHERE patient_id = %s", (patient_id,), one=True)['total']
    
    remaining = float(bills_total or 0.0) - float(payments_total or 0.0)
    
    status = 'Pending'
    if remaining <= 0.01:
        status = 'Paid'
        remaining = 0.00
    elif float(payments_total or 0.0) > 0.01:
        status = 'Partially Paid'
    else:
        status = 'Pending'
        
    get_db().query("""
        UPDATE patients 
        SET total_bill = %s, total_paid = %s, remaining_balance = %s, payment_status = %s 
        WHERE patient_id = %s
    """, (bills_total, payments_total, remaining, status, patient_id), commit=True)


# Monthly compiler function (Python based for database consistency)
def compile_monthly_financial_report():
    bills = get_db().query("SELECT amount, bill_date, item_category FROM bills")
    payments = get_db().query("SELECT amount_paid, payment_date, payment_method FROM payments")
    expenses = get_db().query("SELECT amount, expense_date, category FROM hospital_expenses")
    
    months_data = {}
    
    # 1. Aggregate bills (Accrual Revenue)
    for b in bills:
        dt = parse_date(b.get('bill_date'))
        if not dt: continue
        key = dt.strftime('%Y-%m')
        if key not in months_data:
            months_data[key] = {
                'month_key': key,
                'month_name': dt.strftime('%B %Y'),
                'billed_revenue': 0.0,
                'collected_cash': 0.0,
                'expenses': 0.0,
                'categories': {}
            }
        amt = float(b['amount'])
        months_data[key]['billed_revenue'] += amt
        cat = b['item_category']
        months_data[key]['categories'][cat] = months_data[key]['categories'].get(cat, 0.0) + amt
        
    # 2. Aggregate payments (Collected Cash Flow)
    for p in payments:
        dt = parse_date(p.get('payment_date'))
        if not dt: continue
        key = dt.strftime('%Y-%m')
        if key not in months_data:
            months_data[key] = {
                'month_key': key,
                'month_name': dt.strftime('%B %Y'),
                'billed_revenue': 0.0,
                'collected_cash': 0.0,
                'expenses': 0.0,
                'categories': {}
            }
        months_data[key]['collected_cash'] += float(p['amount_paid'])
        
    # 3. Aggregate expenses
    for e in expenses:
        dt = parse_date(e.get('expense_date'))
        if not dt: continue
        key = dt.strftime('%Y-%m')
        if key not in months_data:
            months_data[key] = {
                'month_key': key,
                'month_name': dt.strftime('%B %Y'),
                'billed_revenue': 0.0,
                'collected_cash': 0.0,
                'expenses': 0.0,
                'categories': {}
            }
        months_data[key]['expenses'] += float(e['amount'])
        
    # 4. Final Calculations
    for key, data in months_data.items():
        data['outstanding_bills'] = max(0.0, data['billed_revenue'] - data['collected_cash'])
        data['accrual_profit'] = data['billed_revenue'] - data['expenses']
        data['cash_profit'] = data['collected_cash'] - data['expenses']
        
    sorted_months = sorted(months_data.values(), key=lambda x: x['month_key'], reverse=True)
    return sorted_months


# ==================================================
# ADMIN DASHBOARD & API
# ==================================================

@app.route('/admin')
@role_required(['Admin'])
def admin_dashboard():
    # Summary Cards
    total_patients = get_db().query("SELECT COUNT(*) as count FROM patients", one=True)['count']
    
    today_collection = get_db().query(
        "SELECT SUM(amount_paid) as total FROM payments WHERE DATE(payment_date) = CURDATE()", 
        one=True
    )['total'] or 0.0
    
    today_expenses = get_db().query(
        "SELECT SUM(amount) as total FROM hospital_expenses WHERE DATE(expense_date) = CURDATE()", 
        one=True
    )['total'] or 0.0
    
    total_consultations = get_db().query("SELECT COUNT(*) as count FROM consultations", one=True)['count']
    total_visits = get_db().query("SELECT COUNT(*) as count FROM patient_visits", one=True)['count']
    
    pending_bills = get_db().query("SELECT SUM(remaining_balance) as total FROM patients", one=True)['total'] or 0.0

    return render_template(
        'admin.html',
        total_patients=total_patients,
        today_collection=today_collection,
        hospital_expenses=today_expenses, # Shown as Today's Expense on Dashboard
        pending_bills=pending_bills,
        total_consultations=total_consultations,
        total_visits=total_visits
    )

@app.route('/api/admin/patients')
@role_required(['Admin'])
def api_admin_patients():
    patients = get_db().query("SELECT * FROM patients ORDER BY registration_date DESC")
    return jsonify(patients)

@app.route('/api/admin/patients/delete/<patient_id>', methods=['POST'])
@role_required(['Admin'])
def api_admin_delete_patient(patient_id):
    try:
        db = get_db()
        # Verify patient exists
        patient = db.query("SELECT * FROM patients WHERE patient_id = %s", (patient_id,), one=True)
        if not patient:
            return jsonify({'success': False, 'message': 'Patient not found'}), 404
            
        # Delete related records in dependent order:
        # 1. Pharmacy bill items and pharmacy bills
        db.query("DELETE FROM pharmacy_bill_items WHERE bill_id IN (SELECT bill_id FROM pharmacy_bills WHERE patient_id = %s)", (patient_id,), commit=True)
        db.query("DELETE FROM pharmacy_bills WHERE patient_id = %s", (patient_id,), commit=True)
        
        # 2. Investigation bill items and investigation bills
        db.query("DELETE FROM investigation_bill_items WHERE bill_id IN (SELECT bill_id FROM investigation_bills WHERE patient_id = %s)", (patient_id,), commit=True)
        db.query("DELETE FROM investigation_bills WHERE patient_id = %s", (patient_id,), commit=True)
        
        # 3. Scribe sessions
        db.query("DELETE FROM scribe_sessions WHERE patient_id = %s", (patient_id,), commit=True)
        
        # 4. Patient custom sections
        db.query("DELETE FROM patient_custom_sections WHERE patient_id = %s", (patient_id,), commit=True)
        
        # 5. Patient documents (remove files from disk first, then DB records)
        docs = db.query("SELECT filepath FROM patient_documents WHERE patient_id = %s", (patient_id,))
        for doc in docs:
            filepath = doc.get('filepath')
            if filepath and os.path.exists(filepath):
                try:
                    os.remove(filepath)
                except Exception as ex:
                    print("Error deleting document file:", ex)
        db.query("DELETE FROM patient_documents WHERE patient_id = %s", (patient_id,), commit=True)
        
        # 6. Prescriptions
        db.query("DELETE FROM prescriptions WHERE patient_id = %s", (patient_id,), commit=True)
        
        # 7. Consultations
        db.query("DELETE FROM consultations WHERE patient_id = %s", (patient_id,), commit=True)
        
        # 8. Payments
        db.query("DELETE FROM payments WHERE patient_id = %s", (patient_id,), commit=True)
        
        # 9. Bills
        db.query("DELETE FROM bills WHERE patient_id = %s", (patient_id,), commit=True)
        
        # 10. Patient visits
        db.query("DELETE FROM patient_visits WHERE patient_id = %s", (patient_id,), commit=True)
        
        # 11. The main patient profile
        db.query("DELETE FROM patients WHERE patient_id = %s", (patient_id,), commit=True)
        
        log_action(f"Permanently deleted patient {patient_id} and all related clinical & financial records", None, None)
        
        return jsonify({'success': True, 'message': f'Patient {patient_id} and all associated records deleted successfully.'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/admin/visits')
@role_required(['Admin', 'Reception'])
def api_admin_visits():
    visits = get_db().query("""
        SELECT pv.visit_id, pv.patient_id, p.patient_name, pv.visit_date, pv.fee_charged
        FROM patient_visits pv
        JOIN patients p ON pv.patient_id = p.patient_id
        ORDER BY pv.visit_date DESC
    """)
    return jsonify(visits)

@app.route('/api/admin/payments_ledger')
@role_required(['Admin'])
def api_admin_payments_ledger():
    payments = get_db().query("""
        SELECT py.transaction_id, py.patient_id, p.patient_name, py.bill_id, 
               py.payment_date, py.amount_paid, py.payment_method, py.received_by, py.remarks
        FROM payments py
        JOIN patients p ON py.patient_id = p.patient_id
        ORDER BY py.payment_date DESC
    """)
    return jsonify(payments)

@app.route('/api/admin/monthly_reports')
@role_required(['Admin'])
def api_admin_monthly_reports():
    reports = compile_monthly_financial_report()
    return jsonify(reports)

@app.route('/api/admin/financial_summary')
@role_required(['Admin', 'Reception'])
def api_admin_financial_summary():
    try:
        cond_pay = get_date_conditions("payment_date")
        cond_exp = get_date_conditions("expense_date")
        
        # 1. Today metrics
        today_rev_res = get_db().query(f"SELECT SUM(amount_paid) AS total FROM payments WHERE {cond_pay['today']}")
        today_exp_res = get_db().query(f"SELECT SUM(amount) AS total FROM hospital_expenses WHERE {cond_exp['today']}")
        today_rev = float(today_rev_res[0]['total'] or 0) if today_rev_res else 0.0
        today_exp = float(today_exp_res[0]['total'] or 0) if today_exp_res else 0.0
        today_profit = today_rev - today_exp
        
        # Today's detailed breakdown and discount metrics
        cond_pay_today = get_date_conditions("p.payment_date")
        payments = get_db().query(f"""
            SELECT p.amount_paid, b.item_category, p.remarks
            FROM payments p
            LEFT JOIN bills b ON p.bill_id = b.bill_id
            WHERE {cond_pay_today['today']}
        """)
        
        consultation = 0.0
        investigation = 0.0
        pharmacy = 0.0
        other = 0.0
        
        for p in payments:
            cat = p.get('item_category')
            remarks = (p.get('remarks') or '').lower()
            amt = float(p.get('amount_paid') or 0)
            
            if cat in ('Consultation', 'Follow-up Consultation', 'Registration') or 'consultation' in remarks:
                consultation += amt
            elif cat == 'Lab' or 'investigation' in remarks:
                investigation += amt
            elif cat == 'Pharmacy' or 'pharmacy' in remarks:
                pharmacy += amt
            else:
                other += amt
                
        # Registration discounts today
        reg_cond = get_date_conditions("registration_date")
        reg_disc_res = get_db().query(f"""
            SELECT SUM(consultation_fee * (discount_percent / 100)) AS total
            FROM patients
            WHERE {reg_cond['today']}
        """)
        reg_disc = float(reg_disc_res[0]['total'] or 0) if reg_disc_res and reg_disc_res[0]['total'] is not None else 0.0
        
        # Investigation discounts today
        inv_cond = get_date_conditions("created_at")
        inv_disc_res = get_db().query(f"""
            SELECT SUM(discount) AS total
            FROM investigation_bills
            WHERE {inv_cond['today']}
        """)
        inv_disc = float(inv_disc_res[0]['total'] or 0) if inv_disc_res and inv_disc_res[0]['total'] is not None else 0.0
        
        total_discount = reg_disc + inv_disc
        net_revenue = consultation + investigation + pharmacy + other
        gross_revenue = net_revenue + total_discount

        # 2. Month metrics
        month_rev_res = get_db().query(f"SELECT SUM(amount_paid) AS total FROM payments WHERE {cond_pay['month']}")
        month_exp_res = get_db().query(f"SELECT SUM(amount) AS total FROM hospital_expenses WHERE {cond_exp['month']}")
        month_rev = float(month_rev_res[0]['total'] or 0) if month_rev_res else 0.0
        month_exp = float(month_exp_res[0]['total'] or 0) if month_exp_res else 0.0
        month_profit = month_rev - month_exp
        
        # Monthly pharmacy billing
        cond_pay_p_month = get_date_conditions("p.payment_date")
        month_pharmacy_res = get_db().query(f"""
            SELECT SUM(p.amount_paid) AS total 
            FROM payments p 
            LEFT JOIN bills b ON p.bill_id = b.bill_id 
            WHERE {cond_pay_p_month['month']} AND b.item_category = 'Pharmacy'
        """)
        month_pharmacy = float(month_pharmacy_res[0]['total'] or 0) if month_pharmacy_res and month_pharmacy_res[0]['total'] is not None else 0.0
        
        # 3. Year metrics
        year_rev_res = get_db().query(f"SELECT SUM(amount_paid) AS total FROM payments WHERE {cond_pay['year']}")
        year_exp_res = get_db().query(f"SELECT SUM(amount) AS total FROM hospital_expenses WHERE {cond_exp['year']}")
        year_rev = float(year_rev_res[0]['total'] or 0) if year_rev_res else 0.0
        year_exp = float(year_exp_res[0]['total'] or 0) if year_exp_res else 0.0
        year_profit = year_rev - year_exp
        
        # Yearly pharmacy billing
        cond_pay_p_year = get_date_conditions("p.payment_date")
        year_pharmacy_res = get_db().query(f"""
            SELECT SUM(p.amount_paid) AS total 
            FROM payments p 
            LEFT JOIN bills b ON p.bill_id = b.bill_id 
            WHERE {cond_pay_p_year['year']} AND b.item_category = 'Pharmacy'
        """)
        year_pharmacy = float(year_pharmacy_res[0]['total'] or 0) if year_pharmacy_res and year_pharmacy_res[0]['total'] is not None else 0.0
        
        # Category breakdown (Expenses) - current month
        exp_cats = get_db().query(f"SELECT category, SUM(amount) AS total FROM hospital_expenses WHERE {cond_exp['month']} GROUP BY category")
        expense_breakdown = [{'label': x['category'], 'value': float(x['total'])} for x in exp_cats] if exp_cats else []
        
        # Category breakdown (Revenue) - current month
        rev_cats = get_db().query(f"""
            SELECT COALESCE(b.item_category, 'Other') AS category, SUM(p.amount_paid) AS total 
            FROM payments p 
            LEFT JOIN bills b ON p.bill_id = b.bill_id 
            WHERE {cond_pay['month'].replace('payment_date', 'p.payment_date')} 
            GROUP BY category
        """) if not get_db().use_sqlite else get_db().query(f"""
            SELECT coalesce(b.item_category, 'Other') AS category, SUM(p.amount_paid) AS total 
            FROM payments p 
            LEFT JOIN bills b ON p.bill_id = b.bill_id 
            WHERE {cond_pay['month'].replace('payment_date', 'p.payment_date')} 
            GROUP BY category
        """)
        revenue_breakdown = [{'label': x['category'], 'value': float(x['total'])} for x in rev_cats] if rev_cats else []
        
        return jsonify({
            'today_revenue': today_rev,
            'today_expenses': today_exp,
            'today_profit': today_profit,
            'today_gross': gross_revenue,
            'today_discount': total_discount,
            'today_net': net_revenue,
            'today_consultation': consultation,
            'today_investigation': investigation,
            'today_pharmacy': pharmacy,
            'today_other': other,
            'month_revenue': month_rev,
            'month_expenses': month_exp,
            'month_profit': month_profit,
            'month_pharmacy': month_pharmacy,
            'year_revenue': year_rev,
            'year_expenses': year_exp,
            'year_profit': year_profit,
            'year_pharmacy': year_pharmacy,
            'revenue_sources': revenue_breakdown,
            'expense_categories': expense_breakdown
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/admin/chart_data')
@role_required(['Admin'])
def api_admin_chart_data():
    try:
        # Generate last 7 days
        days = []
        daily_rev = []
        daily_exp = []
        daily_prof = []
        
        now = datetime.datetime.now()
        for i in range(6, -1, -1):
            d = now - datetime.timedelta(days=i)
            day_str = d.strftime('%Y-%m-%d')
            day_label = d.strftime('%b %d')
            days.append(day_label)
            
            r_res = get_db().query("SELECT SUM(amount_paid) AS total FROM payments WHERE DATE(payment_date) = %s", (day_str,))
            e_res = get_db().query("SELECT SUM(amount) AS total FROM hospital_expenses WHERE DATE(expense_date) = %s", (day_str,))
                
            rev = float(r_res[0]['total'] or 0) if r_res else 0.0
            exp = float(e_res[0]['total'] or 0) if e_res else 0.0
            
            daily_rev.append(rev)
            daily_exp.append(exp)
            daily_prof.append(rev - exp)
            
        # Generate last 6 months
        month_labels = []
        monthly_rev = []
        monthly_exp = []
        monthly_prof = []
        
        current_year = now.year
        current_month = now.month
        
        for i in range(5, -1, -1):
            m = current_month - i
            y = current_year
            if m <= 0:
                m += 12
                y -= 1
                
            m_str = f"{y}-{m:02d}"
            label = datetime.date(y, m, 1).strftime('%b %Y')
            month_labels.append(label)
            
            if get_db().use_sqlite:
                r_res = get_db().query("SELECT SUM(amount_paid) AS total FROM payments WHERE strftime('%Y-%m', payment_date) = %s", (m_str,))
                e_res = get_db().query("SELECT SUM(amount) AS total FROM hospital_expenses WHERE strftime('%Y-%m', expense_date) = %s", (m_str,))
            else:
                r_res = get_db().query("SELECT SUM(amount_paid) AS total FROM payments WHERE DATE_FORMAT(payment_date, '%Y-%m') = %s", (m_str,))
                e_res = get_db().query("SELECT SUM(amount) AS total FROM hospital_expenses WHERE DATE_FORMAT(expense_date, '%Y-%m') = %s", (m_str,))
                
            rev = float(r_res[0]['total'] or 0) if r_res else 0.0
            exp = float(e_res[0]['total'] or 0) if e_res else 0.0
            
            monthly_rev.append(rev)
            monthly_exp.append(exp)
            monthly_prof.append(rev - exp)
            
        return jsonify({
            'daily': {
                'labels': days,
                'revenue': daily_rev,
                'expenses': daily_exp,
                'profit': daily_prof
            },
            'monthly': {
                'labels': month_labels,
                'revenue': monthly_rev,
                'expenses': monthly_exp,
                'profit': monthly_prof
            }
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Advanced search and filter expense log
@app.route('/api/admin/expenses')
@role_required(['Admin'])
def api_expenses_list():
    try:
        vendor = request.args.get('vendor', '').strip()
        staff = request.args.get('staff', '').strip()
        item = request.args.get('item', '').strip()
        category = request.args.get('category', '').strip()
        invoice = request.args.get('invoice', '').strip()
        date_val = request.args.get('date', '').strip()
        month_val = request.args.get('month', '').strip()
        year_val = request.args.get('year', '').strip()
        search_all = request.args.get('search', '').strip().lower()
        
        sql = "SELECT * FROM hospital_expenses WHERE 1=1"
        params = []
        
        if vendor:
            sql += " AND LOWER(vendor) LIKE %s"
            params.append(f"%{vendor.lower()}%")
        if staff:
            sql += " AND LOWER(created_by) LIKE %s"
            params.append(f"%{staff.lower()}%")
        if item:
            sql += " AND LOWER(item_name) LIKE %s"
            params.append(f"%{item.lower()}%")
        if category:
            sql += " AND category = %s"
            params.append(category)
        if invoice:
            sql += " AND LOWER(invoice_number) LIKE %s"
            params.append(f"%{invoice.lower()}%")
        if date_val:
            sql += " AND DATE(expense_date) = %s"
            params.append(date_val)
        if month_val:
            if get_db().use_sqlite:
                sql += " AND strftime('%Y-%m', expense_date) = %s"
            else:
                sql += " AND DATE_FORMAT(expense_date, '%Y-%m') = %s"
            params.append(month_val)
        if year_val:
            if get_db().use_sqlite:
                sql += " AND strftime('%Y', expense_date) = %s"
            else:
                sql += " AND DATE_FORMAT(expense_date, '%Y') = %s"
            params.append(year_val)
            
        if search_all:
            sql += " AND (LOWER(vendor) LIKE %s OR LOWER(item_name) LIKE %s OR LOWER(category) LIKE %s OR LOWER(invoice_number) LIKE %s OR LOWER(description) LIKE %s)"
            params.extend([f"%{search_all}%"] * 5)
            
        sql += " ORDER BY expense_date DESC"
        
        expenses = get_db().query(sql, tuple(params))
        return jsonify(expenses)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Advanced Expense Report compiler
@app.route('/api/admin/expense_reports')
@role_required(['Admin'])
def api_expense_reports():
    try:
        report_type = request.args.get('report_type', 'all')
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        month_val = request.args.get('month')
        year_val = request.args.get('year')
        
        sql = "SELECT * FROM hospital_expenses WHERE 1=1"
        params = []
        
        today_str = datetime.datetime.now().strftime('%Y-%m-%d')
        this_month_str = datetime.datetime.now().strftime('%Y-%m')
        this_year_str = datetime.datetime.now().strftime('%Y')
        
        if report_type == 'daily':
            sql += " AND DATE(expense_date) = %s"
            params.append(today_str)
        elif report_type == 'monthly':
            m = month_val if month_val else this_month_str
            if get_db().use_sqlite:
                sql += " AND strftime('%Y-%m', expense_date) = %s"
            else:
                sql += " AND DATE_FORMAT(expense_date, '%Y-%m') = %s"
            params.append(m)
        elif report_type == 'yearly':
            y = year_val if year_val else this_year_str
            if get_db().use_sqlite:
                sql += " AND strftime('%Y', expense_date) = %s"
            else:
                sql += " AND DATE_FORMAT(expense_date, '%Y') = %s"
            params.append(y)
        elif report_type == 'custom':
            if start_date:
                sql += " AND DATE(expense_date) >= %s"
                params.append(start_date)
            if end_date:
                sql += " AND DATE(expense_date) <= %s"
                params.append(end_date)
                
        expenses = get_db().query(sql, tuple(params))
        
        total_exp = 0.0
        highest_exp = 0.0
        lowest_exp = float('inf') if expenses else 0.0
        cat_wise = {}
        
        for e in expenses:
            amt = float(e['amount'])
            total_exp += amt
            if amt > highest_exp:
                highest_exp = amt
            if amt < lowest_exp:
                lowest_exp = amt
                
            cat = e['category']
            cat_wise[cat] = cat_wise.get(cat, 0.0) + amt
            
        avg_exp = total_exp / len(expenses) if expenses else 0.0
        lowest_exp = 0.0 if lowest_exp == float('inf') else lowest_exp
        
        cat_summary = [{'category': k, 'amount': v} for k, v in cat_wise.items()]
        cat_summary.sort(key=lambda x: x['amount'], reverse=True)
        
        return jsonify({
            'expenses': expenses,
            'summary': {
                'total_expenses': total_exp,
                'highest_expense': highest_exp,
                'lowest_expense': lowest_exp,
                'average_expense': avg_exp,
                'category_summary': cat_summary
            }
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Endpoint to record advanced hospital expenses
@app.route('/api/admin/add_expense', methods=['POST'])
@role_required(['Admin'])
def api_admin_add_expense():
    try:
        category = request.form.get('category')
        item_name = request.form.get('item_name')
        vendor = request.form.get('vendor')
        description = request.form.get('description', '')
        quantity = int(request.form.get('quantity', 1))
        unit_price = float(request.form.get('unit_price', 0.0))
        amount = quantity * unit_price
        payment_method = request.form.get('payment_method', 'Cash')
        invoice_number = request.form.get('invoice_number', '')
        remarks = request.form.get('remarks', '')
        created_by = session.get('username', 'admin')
        
        attachment_path = None
        if 'attachment' in request.files:
            file = request.files['attachment']
            if file and file.filename:
                from werkzeug.utils import secure_filename
                filename = secure_filename(f"{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}_{file.filename}")
                file_path = os.path.join(UPLOAD_FOLDER, filename)
                file.save(file_path)
                attachment_path = f"/static/uploads/expenses/{filename}"
                
        get_db().query("""
            INSERT INTO hospital_expenses (category, item_name, vendor, description, quantity, unit_price, amount, payment_method, invoice_number, created_by, remarks, attachment_path, expense_date)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW())
        """, (category, item_name, vendor, description, quantity, unit_price, amount, payment_method, invoice_number, created_by, remarks, attachment_path), commit=True)
        
        log_action(f"Recorded hospital expense outflow: {item_name}", None, f"Category: {category}, Vendor: {vendor}, Total: ₹{amount:.2f}")
        return jsonify({'success': True, 'message': 'Expense recorded successfully!'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# Chronological dynamic double-entry financial ledger
@app.route('/api/admin/ledger')
@role_required(['Admin'])
def api_admin_ledger():
    try:
        filter_type = request.args.get('filter_type', 'all')
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        search_q = request.args.get('search', '').strip().lower()
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 20))
        
        # Query Income flow
        if get_db().use_sqlite:
            payments = get_db().query("""
                SELECT p.payment_date AS trans_date,
                       'TX-' || p.transaction_id AS trans_id,
                       pat.patient_name AS party_name,
                       p.remarks AS description,
                       p.amount_paid AS income,
                       0.00 AS expense,
                       p.payment_method
                FROM payments p
                JOIN patients pat ON p.patient_id = pat.patient_id
            """)
        else:
            payments = get_db().query("""
                SELECT p.payment_date AS trans_date,
                       CONCAT('TX-', p.transaction_id) AS trans_id,
                       pat.patient_name AS party_name,
                       p.remarks AS description,
                       p.amount_paid AS income,
                       0.00 AS expense,
                       p.payment_method
                FROM payments p
                JOIN patients pat ON p.patient_id = pat.patient_id
            """)
            
        # Query Expense flow
        if get_db().use_sqlite:
            expenses = get_db().query("""
                SELECT e.expense_date AS trans_date,
                       'EXP-' || e.expense_id AS trans_id,
                       e.vendor AS party_name,
                       '[' || e.category || '] ' || e.item_name || ' - ' || e.description AS description,
                       0.00 AS income,
                       e.amount AS expense,
                       e.payment_method
                FROM hospital_expenses e
            """)
        else:
            expenses = get_db().query("""
                SELECT e.expense_date AS trans_date,
                       CONCAT('EXP-', e.expense_id) AS trans_id,
                       e.vendor AS party_name,
                       CONCAT('[', e.category, '] ', e.item_name, ' - ', e.description) AS description,
                       0.00 AS income,
                       e.amount AS expense,
                       e.payment_method
                FROM hospital_expenses e
            """)
            
        ledger_items = []
        for p in payments:
            ledger_items.append({
                'date': p['trans_date'],
                'trans_id': p['trans_id'],
                'party_name': p['party_name'],
                'description': p['description'] or 'Payment Received',
                'income': float(p['income'] or 0),
                'expense': float(p['expense'] or 0),
                'payment_method': p['payment_method']
            })
            
        for e in expenses:
            ledger_items.append({
                'date': e['trans_date'],
                'trans_id': e['trans_id'],
                'party_name': e['party_name'],
                'description': e['description'],
                'income': float(e['income'] or 0),
                'expense': float(e['expense'] or 0),
                'payment_method': e['payment_method']
            })
            
        # Helper to parse strings/datetimes safely
        def parse_date(date_val):
            if isinstance(date_val, str):
                try:
                    return datetime.datetime.strptime(date_val, '%Y-%m-%d %H:%M:%S')
                except ValueError:
                    try:
                        return datetime.datetime.strptime(date_val, '%Y-%m-%d')
                    except ValueError:
                        return datetime.datetime.min
            elif isinstance(date_val, (datetime.datetime, datetime.date)):
                return date_val
            return datetime.datetime.min
            
        # Chronological sort for balance calculation
        ledger_items.sort(key=lambda x: parse_date(x['date']))
        
        running_bal = 0.0
        for item in ledger_items:
            running_bal += item['income'] - item['expense']
            item['balance'] = running_bal
            
        # Apply filters
        filtered_items = []
        today_str = datetime.datetime.now().strftime('%Y-%m-%d')
        this_month_str = datetime.datetime.now().strftime('%Y-%m')
        this_year_str = datetime.datetime.now().strftime('%Y')
        
        for item in ledger_items:
            item_date_str = parse_date(item['date']).strftime('%Y-%m-%d')
            
            if filter_type == 'daily':
                if item_date_str != today_str:
                    continue
            elif filter_type == 'monthly':
                if item_date_str[:7] != this_month_str:
                    continue
            elif filter_type == 'yearly':
                if item_date_str[:4] != this_year_str:
                    continue
            elif filter_type == 'custom':
                if start_date and item_date_str < start_date:
                    continue
                if end_date and item_date_str > end_date:
                    continue
                    
            if search_q:
                match = (
                    search_q in item['trans_id'].lower() or
                    search_q in item['party_name'].lower() or
                    search_q in item['description'].lower() or
                    search_q in item['payment_method'].lower()
                )
                if not match:
                    continue
                    
            filtered_items.append(item)
            
        # Sort descending (latest transaction first) for UI
        filtered_items.sort(key=lambda x: parse_date(x['date']), reverse=True)
        
        total_records = len(filtered_items)
        start_idx = (page - 1) * per_page
        end_idx = start_idx + per_page
        paginated_items = filtered_items[start_idx:end_idx]
        
        return jsonify({
            'ledger': paginated_items,
            'total_records': total_records,
            'page': page,
            'per_page': per_page,
            'total_pages': (total_records + per_page - 1) // per_page
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Audit log trail api
@app.route('/api/admin/audit_logs')
@role_required(['Admin'])
def api_admin_audit_logs():
    try:
        page = int(request.args.get('page', 1))
        per_page = int(request.args.get('per_page', 25))
        search = request.args.get('search', '').strip().lower()
        
        sql = "SELECT * FROM audit_logs"
        params = []
        
        if search:
            sql += " WHERE LOWER(username) LIKE %s OR LOWER(action) LIKE %s OR LOWER(old_value) LIKE %s OR LOWER(new_value) LIKE %s"
            params.extend([f"%{search}%"] * 4)
            
        sql += " ORDER BY log_date DESC, log_time DESC"
        
        logs = get_db().query(sql, tuple(params))
        total_records = len(logs)
        start_idx = (page - 1) * per_page
        end_idx = start_idx + per_page
        paginated_logs = logs[start_idx:end_idx]
        
        return jsonify({
            'logs': paginated_logs,
            'total_records': total_records,
            'page': page,
            'per_page': per_page,
            'total_pages': (total_records + per_page - 1) // per_page
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ==================================================
# ADMIN USER MANAGEMENT ENDPOINTS
# ==================================================

@app.route('/api/admin/users')
@role_required(['Admin'])
def api_admin_users():
    try:
        users = get_db().query("SELECT user_id, username, role FROM users ORDER BY user_id ASC")
        return jsonify({'success': True, 'users': users})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/admin/users/create', methods=['POST'])
@role_required(['Admin'])
def api_admin_users_create():
    try:
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        role = request.form.get('role', '')
        
        if not username or not password or not role:
            return jsonify({'success': False, 'message': 'Username, password and role are required.'}), 400
            
        if len(password) < 6:
            return jsonify({'success': False, 'message': 'Password must be at least 6 characters long.'}), 400
            
        if role not in ['Admin', 'Doctor', 'Reception', 'Pharmacy']:
            return jsonify({'success': False, 'message': 'Invalid user role selected.'}), 400
            
        db = get_db()
        existing = db.query("SELECT * FROM users WHERE username = %s", (username,), one=True)
        if existing:
            return jsonify({'success': False, 'message': 'Username is already taken.'}), 400
            
        db.query("INSERT INTO users (username, password, role) VALUES (%s, %s, %s)", (username, password, role), commit=True)
        log_action("Created ERP User", None, f"Username: {username}, Role: {role}")
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/admin/users/update', methods=['POST'])
@role_required(['Admin'])
def api_admin_users_update():
    try:
        user_id = request.form.get('user_id')
        password = request.form.get('password', '')
        role = request.form.get('role', '')
        
        if not user_id or not role:
            return jsonify({'success': False, 'message': 'User ID and role are required.'}), 400
            
        if role not in ['Admin', 'Doctor', 'Reception', 'Pharmacy']:
            return jsonify({'success': False, 'message': 'Invalid user role selected.'}), 400
            
        db = get_db()
        user = db.query("SELECT * FROM users WHERE user_id = %s", (user_id,), one=True)
        if not user:
            return jsonify({'success': False, 'message': 'User not found.'}), 404
            
        if int(user_id) == session.get('user_id') and role != 'Admin':
            return jsonify({'success': False, 'message': 'You cannot change your own admin role to prevent lockout.'}), 400
            
        if password:
            if len(password) < 6:
                return jsonify({'success': False, 'message': 'Password must be at least 6 characters long.'}), 400
            db.query("UPDATE users SET password = %s, role = %s WHERE user_id = %s", (password, role, user_id), commit=True)
            log_action("Updated ERP User Password & Role", None, f"Username: {user['username']}, New Role: {role}")
        else:
            db.query("UPDATE users SET role = %s WHERE user_id = %s", (role, user_id), commit=True)
            log_action("Updated ERP User Role", None, f"Username: {user['username']}, New Role: {role}")
            
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/admin/users/delete', methods=['POST'])
@role_required(['Admin'])
def api_admin_users_delete():
    try:
        user_id = request.form.get('user_id')
        if not user_id:
            return jsonify({'success': False, 'message': 'User ID is required.'}), 400
            
        if int(user_id) == session.get('user_id'):
            return jsonify({'success': False, 'message': 'You cannot delete your own admin account.'}), 400
            
        db = get_db()
        user = db.query("SELECT * FROM users WHERE user_id = %s", (user_id,), one=True)
        if not user:
            return jsonify({'success': False, 'message': 'User not found.'}), 404
            
        db.query("DELETE FROM users WHERE user_id = %s", (user_id,), commit=True)
        log_action("Deleted ERP User", None, f"Username: {user['username']}, Role: {user['role']}")
        return jsonify({'success': True})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500


# DOCTOR MODULE & API
# ==================================================

@app.route('/doctor')
@role_required(['Doctor'])
def doctor_dashboard():
    return render_template('doctor.html')

@app.route('/api/doctor/search_patient')
@role_required(['Doctor', 'Reception', 'Pharmacy', 'Admin'])
def api_doctor_search_patient():
    q = request.args.get('query', '')
    if len(q) < 2:
        return jsonify([])
        
    query_str = f"%{q}%"
    patients = get_db().query("""
        SELECT patient_id, patient_name, gender, age, address, phone1, phone2, occupation, registration_date
        FROM patients
        WHERE patient_id LIKE %s OR patient_name LIKE %s OR phone1 LIKE %s OR phone2 LIKE %s
        LIMIT 20
    """, (query_str, query_str, query_str, query_str))
    
    return jsonify(patients)

@app.route('/api/doctor/waiting_list')
@role_required(['Doctor', 'Admin', 'Reception'])
def api_doctor_waiting_list():
    try:
        db = get_db()
        query = """
            SELECT DISTINCT p.patient_id, p.patient_name, p.phone1, pv.visit_date, pv.visit_id, pv.viewed
            FROM patient_visits pv
            JOIN patients p ON pv.patient_id = p.patient_id
            WHERE date(pv.visit_date) = date('now') OR pv.viewed = 0
            ORDER BY pv.visit_id DESC
        """
        queue = db.query(query)
        if not queue:
            query = """
                SELECT DISTINCT p.patient_id, p.patient_name, p.phone1, pv.visit_date, pv.visit_id, pv.viewed
                FROM patient_visits pv
                JOIN patients p ON pv.patient_id = p.patient_id
                ORDER BY pv.visit_id DESC
                LIMIT 5
            """
            queue = db.query(query)
        return jsonify(queue)
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/reception/pending_investigations')
@role_required(['Reception', 'Admin', 'Doctor'])
def api_reception_pending_investigations():
    try:
        db = get_db()
        query = """
            SELECT c.consultation_id, c.patient_id, p.patient_name, p.phone1, c.investigation_details, c.consultation_date
            FROM consultations c
            JOIN patients p ON c.patient_id = p.patient_id
            WHERE c.investigation_billed = 0 AND c.investigation_details != '' AND c.investigation_details IS NOT NULL
            ORDER BY c.consultation_id DESC
        """
        pending = db.query(query)
        return jsonify(pending)
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

import queue

reception_listeners = []

def notify_reception_update():
    try:
        db = get_db()
        query = """
            SELECT c.consultation_id, c.patient_id, p.patient_name, p.phone1, c.investigation_details, c.consultation_date
            FROM consultations c
            JOIN patients p ON c.patient_id = p.patient_id
            WHERE c.investigation_billed = 0 AND c.investigation_details != '' AND c.investigation_details IS NOT NULL
            ORDER BY c.consultation_id DESC
        """
        pending = db.query(query)
        import json
        data_str = json.dumps(pending)
        for q in list(reception_listeners):
            try:
                q.put(data_str)
            except Exception:
                pass
    except Exception as e:
        print("Error notifying reception update:", e)

@app.route('/api/reception/pending_investigations_stream')
@role_required(['Reception', 'Admin', 'Doctor'])
def api_reception_pending_investigations_stream():
    from flask import Response
    def event_stream():
        q = queue.Queue()
        reception_listeners.append(q)
        try:
            # Yield initial state
            db = get_db()
            query = """
                SELECT c.consultation_id, c.patient_id, p.patient_name, p.phone1, c.investigation_details, c.consultation_date
                FROM consultations c
                JOIN patients p ON c.patient_id = p.patient_id
                WHERE c.investigation_billed = 0 AND c.investigation_details != '' AND c.investigation_details IS NOT NULL
                ORDER BY c.consultation_id DESC
            """
            pending = db.query(query)
            import json
            yield f"data: {json.dumps(pending)}\n\n"
            
            while True:
                try:
                    data = q.get(timeout=20)
                    yield f"data: {data}\n\n"
                except queue.Empty:
                    yield ": ping\n\n"
        except GeneratorExit:
            if q in reception_listeners:
                reception_listeners.remove(q)
    return Response(event_stream(), mimetype="text/event-stream")


@app.route('/api/doctor/patient_profile/<patient_id>')
@role_required(['Doctor', 'Reception', 'Pharmacy', 'Admin'])
def api_doctor_patient_profile(patient_id):
    patient = get_db().query("SELECT * FROM patients WHERE patient_id = %s", (patient_id,), one=True)
    if not patient:
        return jsonify({'error': 'Patient not found'}), 404
        
    # Mark patient visits as viewed when checking their profile
    get_db().query("UPDATE patient_visits SET viewed = 1 WHERE patient_id = %s AND viewed = 0", (patient_id,), commit=True)
    
    visits = get_db().query("SELECT * FROM patient_visits WHERE patient_id = %s ORDER BY visit_date DESC", (patient_id,))
    consultations = get_db().query("""
        SELECT c.*, s.session_id 
        FROM consultations c 
        LEFT JOIN scribe_sessions s ON c.consultation_id = s.consultation_id 
        WHERE c.patient_id = %s 
        ORDER BY c.consultation_date DESC
    """, (patient_id,))
    prescriptions = get_db().query("SELECT * FROM prescriptions WHERE patient_id = %s ORDER BY created_at DESC", (patient_id,))
    
    return jsonify({
        'patient': patient,
        'visits': visits,
        'consultations': consultations,
        'prescriptions': prescriptions
    })

# Configure Patient Documents Directory
if is_vercel:
    UPLOAD_DOCS_DIR = '/tmp/patient_documents'
else:
    UPLOAD_DOCS_DIR = os.path.join(app.root_path, 'uploads', 'patient_documents')

try:
    os.makedirs(UPLOAD_DOCS_DIR, exist_ok=True)
except Exception as e:
    print("Warning: could not create UPLOAD_DOCS_DIR:", e)

@app.route('/api/doctor/upload_document', methods=['POST'])
@role_required(['Doctor'])
def api_doctor_upload_document():
    try:
        patient_id = request.form.get('patient_id')
        description = request.form.get('description', '')
        
        if 'file' not in request.files:
            return jsonify({'success': False, 'message': 'No file part in the request'}), 400
            
        file = request.files['file']
        if file.filename == '':
            return jsonify({'success': False, 'message': 'No selected file'}), 400
            
        if not patient_id:
            return jsonify({'success': False, 'message': 'No patient ID specified'}), 400
            
        # Secure filename and generate path
        base_filename = secure_filename(file.filename)
        timestamp = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
        stored_filename = f"{patient_id}_{timestamp}_{base_filename}"
        filepath = os.path.join(UPLOAD_DOCS_DIR, stored_filename)
        
        file.save(filepath)
        
        # Save to database
        db = get_db()
        db.query("""
            INSERT INTO patient_documents (patient_id, filename, filepath, description, uploaded_at)
            VALUES (%s, %s, %s, %s, NOW())
        """, (patient_id, base_filename, filepath, description), commit=True)
        
        log_action(f"Uploaded document {base_filename} for patient {patient_id}", None, f"Description: {description}")
        return jsonify({'success': True, 'message': 'Document uploaded successfully!'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/doctor/list_documents/<patient_id>')
@role_required(['Doctor'])
def api_doctor_list_documents(patient_id):
    try:
        docs = get_db().query("""
            SELECT document_id, patient_id, filename, description, uploaded_at 
            FROM patient_documents 
            WHERE patient_id = %s 
            ORDER BY uploaded_at DESC
        """, (patient_id,))
        return jsonify(docs)
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/doctor/download_document/<int:document_id>')
@role_required(['Doctor'])
def api_doctor_download_document(document_id):
    try:
        doc = get_db().query("SELECT * FROM patient_documents WHERE document_id = %s", (document_id,), one=True)
        if not doc:
            return "Document not found", 404
            
        if not os.path.exists(doc['filepath']):
            return "File not found on server", 404
            
        from flask import send_file
        return send_file(doc['filepath'], download_name=doc['filename'], as_attachment=False)
    except Exception as e:
        return str(e), 500

@app.route('/static/patient_history/<filename>')
def serve_patient_history_pdf(filename):
    from flask import send_file
    if is_vercel:
        path = os.path.join('/tmp/patient_history', filename)
    else:
        path = os.path.join(app.root_path, 'static', 'patient_history', filename)
    
    if os.path.exists(path):
        return send_file(path)
    else:
        return "File not found", 404

@app.route('/api/doctor/delete_document/<int:document_id>', methods=['POST'])
@role_required(['Doctor'])
def api_doctor_delete_document(document_id):
    try:
        db = get_db()
        doc = db.query("SELECT * FROM patient_documents WHERE document_id = %s", (document_id,), one=True)
        if not doc:
            return jsonify({'success': False, 'message': 'Document not found'}), 404
            
        # Delete file from disk
        if os.path.exists(doc['filepath']):
            try:
                os.remove(doc['filepath'])
            except Exception as fe:
                print("Warning: could not delete file from disk:", fe)
        db.query("DELETE FROM patient_documents WHERE document_id = %s", (document_id,), commit=True)
        log_action(f"Deleted document {doc['filename']} for patient {doc['patient_id']}", None, "")
        return jsonify({'success': True, 'message': 'Document deleted successfully!'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

def generate_patient_history_pdf(consultation_id):
    import os
    import json
    import datetime
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Image, KeepTogether
    from reportlab.platypus.flowables import HRFlowable
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from pypdf import PdfWriter, PdfReader
    
    db = get_db()
    
    # 1. Fetch current consultation
    consult = db.query("SELECT * FROM consultations WHERE consultation_id = %s", (consultation_id,), one=True)
    if not consult:
        raise ValueError("Consultation not found")
        
    patient_id = consult['patient_id']
    
    # 2. Fetch patient details
    patient = db.query("SELECT * FROM patients WHERE patient_id = %s", (patient_id,), one=True)
    if not patient:
        raise ValueError("Patient not found")
        
    # 3. Fetch current prescriptions
    prescriptions = db.query("SELECT * FROM prescriptions WHERE consultation_id = %s", (consultation_id,))
    if not prescriptions:
        # Fallback to matching patient_id and created_at date
        prescriptions = db.query("""
            SELECT * FROM prescriptions 
            WHERE patient_id = %s AND date(created_at) = date(%s)
        """, (patient_id, consult['consultation_date']))
        
    # 4. Fetch past consultations (excluding current one)
    past_consults = db.query("""
        SELECT * FROM consultations 
        WHERE patient_id = %s AND consultation_id != %s 
        ORDER BY consultation_date DESC
    """, (patient_id, consultation_id))
    
    # Create output directory
    if is_vercel:
        pdf_dir = '/tmp/patient_history'
    else:
        pdf_dir = os.path.join(app.root_path, 'static', 'patient_history')
    try:
        os.makedirs(pdf_dir, exist_ok=True)
    except Exception as e:
        print("Warning: could not create pdf_dir:", e)
    
    pdf_filename = f"patient_{patient_id}_consult_{consultation_id}.pdf"
    pdf_path = os.path.join(pdf_dir, pdf_filename)
    
    # Temporary PDF file for reportlab output
    temp_pdf_path = pdf_path + ".tmp"
    
    # Build the main report PDF using ReportLab
    # topMargin=135 leaves space for custom-drawn header (above Y=710)
    # bottomMargin=50 leaves space for custom-drawn footer (below Y=40)
    doc = SimpleDocTemplate(temp_pdf_path, pagesize=A4, rightMargin=40, leftMargin=40, topMargin=135, bottomMargin=50)
    story = []
    
    styles = getSampleStyleSheet()
    
    # Custom styles
    h1_style = ParagraphStyle(
        'SectionH1',
        parent=styles['Heading2'],
        fontName='Helvetica-Bold',
        fontSize=12,
        leading=16,
        textColor=colors.HexColor('#0078d4'),
        spaceBefore=12,
        spaceAfter=6,
        keepWithNext=True
    )

    h2_style = ParagraphStyle(
        'SubSectionH2',
        parent=styles['Heading3'],
        fontName='Helvetica-Bold',
        fontSize=10,
        leading=14,
        textColor=colors.HexColor('#00bcf2'),
        spaceBefore=8,
        spaceAfter=4,
        keepWithNext=True
    )
    
    body_style = ParagraphStyle(
        'BodyDark',
        parent=styles['Normal'],
        fontName='Helvetica',
        fontSize=9,
        leading=13,
        textColor=colors.HexColor('#333333'),
        spaceAfter=4
    )

    bold_body_style = ParagraphStyle(
        'BodyDarkBold',
        parent=body_style,
        fontName='Helvetica-Bold'
    )
    
    rx_style = ParagraphStyle(
        'RxText',
        parent=styles['Normal'],
        fontName='Helvetica-Bold',
        fontSize=14,
        leading=18,
        textColor=colors.HexColor('#0078d4'),
        spaceBefore=10,
        spaceAfter=5
    )
    
    # Patient Metadata Table
    c_date = consult['consultation_date']
    if isinstance(c_date, str):
        try:
            c_date_parsed = datetime.datetime.strptime(c_date.split('.')[0], "%Y-%m-%d %H:%M:%S")
            visit_date_str = c_date_parsed.strftime("%d-%b-%Y %I:%M %p")
        except Exception:
            visit_date_str = c_date
    else:
        visit_date_str = c_date.strftime("%d-%b-%Y %I:%M %p") if c_date else ""
        
    meta_data = [
        [Paragraph(f"<b>Patient Name:</b> {patient['patient_name']}", body_style), Paragraph(f"<b>Patient ID:</b> {patient_id}", body_style)],
        [Paragraph(f"<b>Age / Gender:</b> {patient['age']} Y / {patient['gender']}", body_style), Paragraph(f"<b>Date:</b> {visit_date_str}", body_style)],
        [Paragraph(f"<b>Phone:</b> {patient['phone1']}", body_style), Paragraph(f"<b>Address:</b> {patient['address']}", body_style)]
    ]
    meta_table = Table(meta_data, colWidths=[260, 260])
    meta_table.setStyle(TableStyle([
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('BOTTOMPADDING', (0,0), (-1,-1), 4),
        ('TOPPADDING', (0,0), (-1,-1), 4),
        ('LEFTPADDING', (0,0), (-1,-1), 0),
        ('RIGHTPADDING', (0,0), (-1,-1), 0),
    ]))
    story.append(meta_table)
    story.append(Spacer(1, 10))
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#cccccc'), spaceAfter=10))
    
    # 1. Clinical Summary
    story.append(Paragraph("CLINICAL SUMMARY", h1_style))
    
    # Symptoms / Complaints (Format JSON string if valid)
    complaints_display = "None"
    if consult['complaints']:
        try:
            c_list = json.loads(consult['complaints'])
            parts = []
            for item in c_list:
                comp = item.get('complaint', '').replace('_', ' ').title()
                val = item.get('duration_value', '')
                unit = item.get('duration_unit', '').title()
                if val:
                    parts.append(f"{comp} ({val} {unit})")
                else:
                    parts.append(comp)
            complaints_display = ", ".join(parts)
        except Exception:
            parts = [c.replace('_', ' ').title() for c in consult['complaints'].split(';') if c]
            complaints_display = ", ".join(parts)
            
    story.append(Paragraph(f"<b>Chief Complaints:</b> {complaints_display}", body_style))
    
    # Present Illness
    story.append(Paragraph(f"<b>History of Present Illness:</b> {consult['present_illness'] or 'N/A'}", body_style))
    
    # Past, Family, Personal history
    h_text = []
    if consult['past_history']: h_text.append(f"Past History: {consult['past_history']}")
    if consult['treatment_history']: h_text.append(f"Treatment History: {consult['treatment_history']}")
    if consult['family_history']: h_text.append(f"Family History: {consult['family_history']}")
    if consult['personal_history']: h_text.append(f"Personal History: {consult['personal_history']}")
    if h_text:
        story.append(Paragraph(f"<b>Medical History:</b> {'; '.join(h_text)}", body_style))
        
    # Examination
    story.append(Paragraph(f"<b>Clinical Examination:</b> {consult['examination'] or 'N/A'}", body_style))
    
    # provisional Diagnosis
    story.append(Paragraph(f"<b>Provisional Diagnosis:</b> {consult['provisional_diagnosis'] or 'N/A'}", body_style))
    
    # Recommended Investigations
    investigations_display = "None"
    if consult['investigation_details']:
        parts = [i.strip() for i in consult['investigation_details'].split(';') if i.strip()]
        investigations_display = ", ".join(parts)
    story.append(Paragraph(f"<b>Recommended Investigations:</b> {investigations_display}", body_style))
    
    story.append(Spacer(1, 10))
    story.append(HRFlowable(width="100%", thickness=0.5, color=colors.HexColor('#cccccc'), spaceAfter=10))
    
    # 2. Prescription Section
    story.append(Paragraph("Rx (PRESCRIPTION)", rx_style))
    
    if prescriptions:
        rx_data = [[
            Paragraph("<b>S.No</b>", bold_body_style),
            Paragraph("<b>Medicine Name</b>", bold_body_style),
            Paragraph("<b>Dosage (M-A-N)</b>", bold_body_style),
            Paragraph("<b>Instruction</b>", bold_body_style),
            Paragraph("<b>Duration</b>", bold_body_style),
        ]]
        for idx, p in enumerate(prescriptions):
            m = "1" if p['morning'] else "0"
            a = "1" if p['afternoon'] else "0"
            n = "1" if p['night'] else "0"
            food_rel = p.get('food_relation', 'After Food') or 'After Food'
            rx_data.append([
                Paragraph(str(idx + 1), body_style),
                Paragraph(p['medicine_name'], bold_body_style),
                Paragraph(f"{m} - {a} - {n}", body_style),
                Paragraph(food_rel, body_style),
                Paragraph(f"{p['duration_days']} Days", body_style)
            ])
            
        rx_table = Table(rx_data, colWidths=[40, 220, 90, 100, 70])
        rx_table.setStyle(TableStyle([
            ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
            ('GRID', (0,0), (-1,-1), 0.5, colors.HexColor('#dddddd')),
            ('BACKGROUND', (0,0), (-1,0), colors.HexColor('#f5f5f5')),
            ('TOPPADDING', (0,0), (-1,-1), 6),
            ('BOTTOMPADDING', (0,0), (-1,-1), 6),
        ]))
        story.append(rx_table)
    else:
        story.append(Paragraph("No medications prescribed in this visit.", body_style))
        
    story.append(Spacer(1, 15))
    story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor('#0078d4'), spaceAfter=15))
    
    # 3. Past Consultation History
    if past_consults:
        story.append(Paragraph("PREVIOUS CLINICAL HISTORY", h1_style))
        
        for pc in past_consults:
            pc_date = pc['consultation_date']
            if isinstance(pc_date, str):
                try:
                    pc_date_parsed = datetime.datetime.strptime(pc_date.split('.')[0], "%Y-%m-%d %H:%M:%S")
                    pc_date_str = pc_date_parsed.strftime("%d-%b-%Y")
                except Exception:
                    pc_date_str = pc_date
            else:
                pc_date_str = pc_date.strftime("%d-%b-%Y") if pc_date else ""
                
            story.append(Paragraph(f"<b>Visit Date:</b> {pc_date_str}", h2_style))
            
            pc_complaints = "None"
            if pc['complaints']:
                try:
                    c_list = json.loads(pc['complaints'])
                    pc_parts = []
                    for item in c_list:
                        comp = item.get('complaint', '').replace('_', ' ').title()
                        val = item.get('duration_value', '')
                        unit = item.get('duration_unit', '').title()
                        if val:
                            pc_parts.append(f"{comp} ({val} {unit})")
                        else:
                            pc_parts.append(comp)
                    pc_complaints = ", ".join(pc_parts)
                except Exception:
                    pc_parts = [c.replace('_', ' ').title() for c in pc['complaints'].split(';') if c]
                    pc_complaints = ", ".join(pc_parts)
                    
            story.append(Paragraph(f"• <b>Complaints:</b> {pc_complaints}", body_style))
            story.append(Paragraph(f"• <b>Diagnosis:</b> {pc['provisional_diagnosis'] or 'N/A'}", body_style))
            if pc['examination']:
                story.append(Paragraph(f"• <b>Exams:</b> {pc['examination']}", body_style))
                
            # Past medicines
            past_meds = db.query("SELECT * FROM prescriptions WHERE consultation_id = %s", (pc['consultation_id'],))
            if not past_meds:
                past_meds = db.query("""
                    SELECT * FROM prescriptions 
                    WHERE patient_id = %s AND date(created_at) = date(%s)
                """, (patient_id, pc['consultation_date']))
                
            if past_meds:
                med_list = []
                for pm in past_meds:
                    m = "1" if pm['morning'] else "0"
                    a = "1" if pm['afternoon'] else "0"
                    n = "1" if pm['night'] else "0"
                    food_relation_str = f" - {pm['food_relation']}" if pm.get('food_relation') else ""
                    med_list.append(f"{pm['medicine_name']} ({m}-{a}-{n}{food_relation_str} for {pm['duration_days']}d)")
                story.append(Paragraph(f"• <b>Medications:</b> {', '.join(med_list)}", body_style))
            story.append(HRFlowable(width="100%", thickness=0.25, color=colors.HexColor('#e0e0e0'), spaceBefore=4, spaceAfter=8))
            
    # Page template callbacks to draw header/footer from the second photo
    def draw_header_footer(canvas, doc):
        canvas.saveState()
        
        # Header Title
        canvas.setFont('Helvetica-Bold', 14)
        canvas.setFillColor(colors.HexColor('#A31D1D'))
        canvas.drawCentredString(297.6, 810, "Sagar ENT- Head and Neck Superspeciality Center")
        
        # Left Column (Dr. R. Vidyasagar)
        canvas.setFont('Helvetica-Bold', 9.5)
        canvas.setFillColor(colors.HexColor('#A31D1D'))
        canvas.drawString(40, 792, "Dr. R. Vidyasagar")
        
        canvas.setFont('Helvetica', 6.2)
        canvas.setFillColor(colors.HexColor('#333333'))
        canvas.drawString(40, 783, "MS (ENT), MD (USA)")
        canvas.drawString(40, 774, "Fellow in Snoring & Sleep Apnea Surgery,")
        canvas.drawString(40, 765, "Endoscopic Sinus Surgery (USA)")
        canvas.drawString(40, 756, "Fellow in Pediatric ENT (USA)")
        canvas.drawString(40, 747, "Fellow in Head and Neck -")
        canvas.drawString(40, 738, "Microvascular Reconstructive Surgery (USA)")
        
        # Middle Column (Dr. Lavan Kumar Borra & Dr. Annamneni Chandrika)
        canvas.setFont('Helvetica-Bold', 9.5)
        canvas.setFillColor(colors.HexColor('#A31D1D'))
        canvas.drawString(225, 792, "Dr. Lavan Kumar Borra")
        
        canvas.setFont('Helvetica', 6.2)
        canvas.setFillColor(colors.HexColor('#333333'))
        canvas.drawString(225, 783, "MBBS, DORL (ENT), FAGE, Manipal")
        canvas.drawString(225, 774, "Fellow in Snoring and Sleep Apnea(IASSA)")
        
        canvas.setFont('Helvetica-Bold', 9.5)
        canvas.setFillColor(colors.HexColor('#A31D1D'))
        canvas.drawString(225, 755, "Dr. Annamneni Chandrika")
        
        canvas.setFont('Helvetica', 6.2)
        canvas.setFillColor(colors.HexColor('#333333'))
        canvas.drawString(225, 746, "MBBS, DNB (ENT-HNS)")
        canvas.drawString(225, 737, "Neurologist (Specialist in Vertigo)")
        
        # Right Column - Circular logo
        logo_path = os.path.join(app.root_path, 'static', 'images', 'logo.jpg')
        if os.path.exists(logo_path):
            canvas.drawImage(logo_path, 475, 740, width=50, height=50)
        else:
            canvas.setStrokeColor(colors.HexColor('#A31D1D'))
            canvas.setLineWidth(1)
            canvas.circle(500, 765, 25, stroke=True, fill=False)
            canvas.setFont('Helvetica-Bold', 6)
            canvas.setFillColor(colors.HexColor('#A31D1D'))
            canvas.drawCentredString(500, 767, "SAGAR")
            canvas.drawCentredString(500, 758, "ENT")
        
        # Separator Line
        canvas.setStrokeColor(colors.HexColor('#A31D1D'))
        canvas.setLineWidth(1.2)
        canvas.line(40, 725, 555, 725)
        
        # Footer Bar
        canvas.setFillColor(colors.HexColor('#A31D1D'))
        canvas.rect(0, 0, 595.27, 28, fill=True, stroke=False)
        
        # Footer Text
        canvas.setFillColor(colors.white)
        canvas.setFont('Helvetica-Bold', 8)
        canvas.drawCentredString(297.6, 10, "D.No:29-28/1-16 Kovelamudivari Street, Suryaraopet, Vijayawada - 520002, Ph:0866-2440806, 9502480806")
        
        canvas.restoreState()

    doc.build(story, onFirstPage=draw_header_footer, onLaterPages=draw_header_footer)
    
    # 5. Merge with attached reports using pypdf
    writer = PdfWriter()
    writer.append(temp_pdf_path)
    
    docs = db.query("SELECT * FROM patient_documents WHERE patient_id = %s ORDER BY uploaded_at ASC", (patient_id,))
    temp_images_pdf_paths = []
    
    for doc_record in docs:
        filepath = doc_record['filepath']
        if not os.path.exists(filepath):
            continue
            
        ext = os.path.splitext(filepath)[1].lower()
        if ext == '.pdf':
            try:
                writer.append(filepath)
            except Exception as pe:
                print(f"Error appending PDF attachment {filepath}:", pe)
        elif ext in ['.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.webp']:
            try:
                img_pdf_path = filepath + "_img.pdf"
                img_doc = SimpleDocTemplate(img_pdf_path, pagesize=A4, rightMargin=20, leftMargin=20, topMargin=20, bottomMargin=20)
                img_story = []
                
                img_story.append(Paragraph(f"ATTACHMENT: {doc_record['filename']} ({doc_record['description'] or 'Report'})", h1_style))
                img_story.append(Spacer(1, 10))
                
                from reportlab.lib.utils import ImageReader
                ir = ImageReader(filepath)
                w, h = ir.getSize()
                
                max_w = 530
                max_h = 700
                
                scale = min(max_w / w, max_h / h)
                new_w = w * scale
                new_h = h * scale
                
                img_story.append(Image(filepath, width=new_w, height=new_h))
                img_doc.build(img_story)
                
                writer.append(img_pdf_path)
                temp_images_pdf_paths.append(img_pdf_path)
            except Exception as ie:
                print(f"Error rendering image attachment {filepath} in PDF:", ie)
                
    with open(pdf_path, "wb") as f_out:
        writer.write(f_out)
        
    writer.close()
    
    # Cleanup temp files
    try:
        if os.path.exists(temp_pdf_path):
            os.remove(temp_pdf_path)
        for tp in temp_images_pdf_paths:
            if os.path.exists(tp):
                os.remove(tp)
    except Exception as ce:
        print("Warning: could not clean up temp files:", ce)
        
    return f"/static/patient_history/{pdf_filename}"

@app.route('/api/doctor/add_consultation', methods=['POST'])
@role_required(['Doctor'])
def api_doctor_add_consultation():
    try:
        patient_id = request.form.get('patient_id')
        present_illness = request.form.get('present_illness', '')
        extra_headings = request.form.getlist('extra_heading[]')
        extra_values = request.form.getlist('extra_value[]')
        extra_text = ""
        for h, v in zip(extra_headings, extra_values):
            if h.strip() and v.strip():
                extra_text += f"\n\n[{h.strip()}]: {v.strip()}"
        present_illness = present_illness + extra_text
        past_history = request.form.get('past_history', '')
        treatment_history = request.form.get('treatment_history', '')
        family_history = request.form.get('family_history', '')
        personal_history = request.form.get('personal_history', '')
        examination = request.form.get('examination', '')
        provisional_diagnosis = request.form.get('provisional_diagnosis', '')
        surgery_eligible = request.form.get('surgery_eligible', 'No')
        
        # Ear Complaints
        # Symptoms complaints
        complaints_json = request.form.get('complaints_json')
        if complaints_json:
            all_complaints = complaints_json
        else:
            ear_complaints = []
            for c in ['Ear Pain', 'Ear Discharge', 'Hearing Loss', 'Tinnitus', 'Vertigo', 'Ear Block']:
                if request.form.get(f"complaint_ear_{c.lower().replace(' ', '_')}"):
                    ear_complaints.append(c)
                    
            nose_complaints = []
            for c in ['Nasal Blockage', 'Running Nose', 'Sneezing', 'Nose Bleeding', 'Sinus Pain', 'Post nasal drip', 'Nasal discharge', 'Headache', 'Facial pain', 'Frequent URTI']:
                if request.form.get(f"complaint_nose_{c.lower().replace(' ', '_')}"):
                    nose_complaints.append(c)
                    
            throat_complaints = []
            for c in ['Sore Throat', 'Difficulty Swallowing', 'Hoarseness', 'Cough', 'Mouth breathing', 'Snoring', 'Lump sensation in throat']:
                if request.form.get(f"complaint_throat_{c.lower().replace(' ', '_')}"):
                    throat_complaints.append(c)
                    
            general_complaints = []
            for c in ['Fever']:
                if request.form.get(f"complaint_general_{c.lower().replace(' ', '_')}"):
                    general_complaints.append(c)
                    
            all_complaints = ";".join(ear_complaints + nose_complaints + throat_complaints + general_complaints)
        
        # Investigations
        investigations = [x.strip() for x in request.form.getlist('investigations[]') if x.strip()]
        all_investigations = ";".join(investigations)
        
        # Save Consultation
        consultation_id = get_db().query("""
            INSERT INTO consultations (
                patient_id, present_illness, past_history, treatment_history, 
                family_history, personal_history, examination, provisional_diagnosis, 
                complaints, investigation_details, surgery_eligible, consultation_date
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW())
        """, (
            patient_id, present_illness, past_history, treatment_history,
            family_history, personal_history, examination, provisional_diagnosis,
            all_complaints, all_investigations, surgery_eligible
        ), commit=True)
        
        # Link Scribe Session if present
        scribe_session_id = request.form.get('scribe_session_id')
        if scribe_session_id and scribe_session_id.strip():
            try:
                get_db().query("""
                    UPDATE scribe_sessions SET consultation_id = %s WHERE session_id = %s
                """, (consultation_id, int(scribe_session_id)), commit=True)
            except Exception as se:
                print("Scribe link warning:", se)
                
        # Link Patient Custom Sections to the newly created consultation
        try:
            get_db().query("""
                UPDATE patient_custom_sections 
                SET consultation_id = %s 
                WHERE patient_id = %s AND (consultation_id IS NULL OR consultation_id = 0)
            """, (consultation_id, patient_id), commit=True)
        except Exception as cse:
            print("Custom sections link warning:", cse)
        
        # Log Surgery Billed Charge automatically if Doctor marks Surgery Eligible!
        if surgery_eligible == 'Yes':
            get_db().query("""
                INSERT INTO bills (patient_id, item_category, description, amount, created_by, bill_date)
                VALUES (%s, 'Surgery', 'Surgical procedure advised during consultation (Pending Schedule)', 4000.00, %s, NOW())
            """, (patient_id, session.get('username', 'doctor')), commit=True)
            recalculate_patient_billing(patient_id)
        
        # Save Prescriptions (Dynamic Rows)
        medicine_names = request.form.getlist('medicine_name[]')
        duration_days = request.form.getlist('duration_days[]')
        morning_dose = request.form.getlist('morning[]')
        afternoon_dose = request.form.getlist('afternoon[]')
        night_dose = request.form.getlist('night[]')
        food_relations = request.form.getlist('food_relation[]')
        
        for i in range(len(medicine_names)):
            if medicine_names[i].strip():
                m_check = 1 if morning_dose[i] == '1' else 0
                a_check = 1 if afternoon_dose[i] == '1' else 0
                n_check = 1 if night_dose[i] == '1' else 0
                food_rel = food_relations[i] if i < len(food_relations) else 'After Food'
                
                get_db().query("""
                    INSERT INTO prescriptions (
                        patient_id, consultation_id, medicine_name, duration_days, morning, afternoon, night, food_relation, dispensed, created_at
                    ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, 'No', NOW())
                """, (
                    patient_id, consultation_id, medicine_names[i], int(duration_days[i] or 1), 
                    m_check, a_check, n_check, food_rel
                ), commit=True)
                
        # Mark patient visits as viewed
        get_db().query("UPDATE patient_visits SET viewed = 1 WHERE patient_id = %s AND viewed = 0", (patient_id,), commit=True)
        
        # Generate the consolidated PDF report
        pdf_url = None
        try:
            pdf_url = generate_patient_history_pdf(consultation_id)
        except Exception as pdf_err:
            print("Error generating consultation PDF:", pdf_err)
                
        if all_investigations:
            notify_reception_update()
        log_action(f"Recorded clinical consultation for {patient_id}", None, f"Diagnosis: {provisional_diagnosis}, Surgery Eligible: {surgery_eligible}")
        return jsonify({'success': True, 'message': 'Consultation saved!', 'pdf_url': pdf_url})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# Configure Scribe Recordings Private Directory
if is_vercel:
    RECORDINGS_DIR = '/tmp/recordings'
else:
    RECORDINGS_DIR = os.path.join(app.root_path, 'data', 'recordings')

try:
    os.makedirs(RECORDINGS_DIR, exist_ok=True)
except Exception as e:
    print("Warning: could not create RECORDINGS_DIR:", e)

# Helper function to translate mixed-language speech inputs to English medical terminology
def translate_multilingual_transcript(text):
    if not text:
        return ""
        
    text_lower = text.lower()
    
    translations = {
        # Dosing timings & units
        "ఉదయం": "morning",
        "పొద్దున్న": "morning",
        "మధ్యాహ్నం": "afternoon",
        "రాత్రి": "night",
        "రోజులు": "days",
        "రోజు": "days",
        "సార్లు": "times",
        "మాత్రలు": "tablets",
        "మాత్ర": "tablet",
        
        "सुबह": "morning",
        "दोपहर": "afternoon",
        "रात": "night",
        "दिन": "days",
        "बार": "times",
        "गोली": "tablet",
        "गोलियां": "tablets",
        
        "காலை": "morning",
        "மதியம்": "afternoon",
        "இரவு": "night",
        "நாட்கள்": "days",
        "நாள்": "days",
        "மாத்திரை": "tablet",
        
        "ಬೆಳಗ್ಗೆ": "morning",
        "ಮಧ್ಯಾಹ್ನ": "afternoon",
        "ರಾತ್ರಿ": "night",
        "ದಿನಗಳು": "days",
        "ದಿನ": "days",
        "ಮಾತ್ರೆ": "tablet",
        
        "രാവിലെ": "morning",
        "ഉച്ചയ്ക്ക്": "afternoon",
        "രാത്രി": "night",
        "ദിവസം": "days",
        
        # Telugu (Unicode & Phonetic Transliteration)
        "చెవి నొప్పి": "ear pain",
        "చెవినొప్పి": "ear pain",
        "గొంతు నొప్పి": "sore throat",
        "గొంతునొప్పి": "sore throat",
        "మింగడం కష్టం": "difficulty swallowing",
        "రక్త పరీక్ష": "blood test",
        "రక్తపోటు": "hypertension",
        "నొప్పిఉంది": "has pain",
        "నొప్పి ఉంది": "has pain",
        "నొప్పి": "pain",
        "దగ్గు": "cough",
        "జ్వరం": "fever",
        "షుగర్": "diabetes",
        "బిపి": "hypertension",
        "ఆస్తమా": "asthma",
        "ఎండోస్కోపీ": "FLP Endoscopy",
        "ఈసీజీ": "ecg",
        "పరీక్ష": "examination",
        "చెవి": "ear",
        "ముక్కు": "nose",
        "గొంతు": "throat",
        "కారుతోంది": "discharge",
        "వినపడటం లేదు": "hearing loss",
        "తల తిరుగుతోంది": "vertigo",
        "తల తిరగడం": "vertigo",
        
        # Hindi
        "कान दर्द": "ear pain",
        "गले में खराश": "sore throat",
        "गला खराब": "sore throat",
        "निगलने में कठिनाई": "difficulty swallowing",
        "नाक बहना": "running nose",
        "नाक बंद": "nasal blockage",
        "नाक से खून": "nose bleeding",
        "दर्द": "pain",
        "खांसी": "cough",
        "बुखार": "fever",
        "शुगर": "diabetes",
        "बीपी": "hypertension",
        "दमा": "asthma",
        "चक्कर": "vertigo",
        "इलाज": "treatment",
        
        # Tamil
        "காது வலி": "ear pain",
        "தொண்டை வலி": "sore throat",
        "இருமல்": "cough",
        "காய்ச்சல்": "fever",
        "நீரிழிவு": "diabetes",
        "தலைச்சுற்றல்": "vertigo",
        "சளி": "running nose",
        "வலி": "pain",
        
        # Kannada
        "ಕಿವಿ ನೋವು": "ear pain",
        "ಗಂಟಲು ನೋವು": "sore throat",
        "ಕೆಮ್ಮು": "cough",
        "ಜ್ವರ": "fever",
        "ತಲೆಸುತ್ತು": "vertigo",
        "ನೆಗಡಿ": "running nose",
        "ನೋವು": "pain",
        
        # Malayalam
        "ചെവി വേദന": "ear pain",
        "തൊണ്ട വേദന": "sore throat",
        "ചുമ": "cough",
        "പനി": "fever",
        "തലകറക്കം": "vertigo",
        "വേദന": "pain"
    }
    
    translated_text = text
    for foreign_word, english_word in translations.items():
        if foreign_word in translated_text:
            translated_text = translated_text.replace(foreign_word, english_word)
            
    # Handle case-insensitive phonetic synonyms
    phonetics = {
        "ear pain": ["chevi noppi", "chevinoppi", "kaan dard", "kaandard", "kadhu vali", "kivi novu", "kivi noovu"],
        "sore throat": ["gontu noppi", "gontunoppi", "gale me kharash", "galeme kharash", "gala kharab", "gantlu novu", "gantalu novu", "thondai vali"],
        "vertigo": ["thala thirugutta", "thalathirugutta", "chakkar", "thalesuttu", "thalachutru", "talakirukkam"],
        "cough": ["daggu", "khansi", "kemmu", "chuma", "irumal"],
        "difficulty swallowing": ["mingadam kashtam", "swallowing difficulty", "nigalne me taklif", "nigalne me takleef"],
        "ear block": ["kaan block", "chevi block", "chevi moosukuపోయింది"],
        "tinnitus": ["ringing in ear", "ringing sound", "chevi lo sound", "kaan me aawaz"],
        "diabetes": ["sugar", "sugar test", "madhumeham", "neerilivu"],
        "hypertension": ["bp", "ranyupotu", "raktapotu", "raktha ottham"],
        "running nose": ["jalubu", "naak behna", "sali", "negadi"],
        "sneezing": ["tummulu", "cheenk", "thummal"],
        "blood test": ["raktha pareeksha", "rakthapareeksha", "khoon test", "bloodtest"],
        "flp endoscopy": ["endoscopy", "endoscopi", "endoscopee"],
        "ecg": ["eceg", "ecg test"],
        "examination": ["pariksha", "pariksa", "pareeksha", "parixa"],
        "morning": ["poddunna", "udayam", "subah", "kaalai", "belagge", "ravile"],
        "afternoon": ["madyahnam", "dopahar", "mathiyam", "madyahna", "uchaykku"],
        "night": ["ratri", "raat", "iravu", "rathri"],
        "days": ["rojulu", "roju", "din", "naal", "naatkal", "dina", "dinagalu", "divasam"]
    }
    
    text_lower_after = translated_text.lower()
    for english_word, synonyms in phonetics.items():
        for syn in synonyms:
            if syn in text_lower_after:
                translated_text += f" . Patient has {english_word}."
                
    # Build Speaker Turns verbatim
    import re
    raw_sentences = re.split(r'(?<=[.!?])\s+', translated_text)
    
    current_speaker = "Patient"
    speaker_turns = []
    
    for s in raw_sentences:
        s_clean = s.strip()
        if not s_clean:
            continue
            
        lower_s = s_clean.lower()
        if lower_s.startswith("doctor:"):
            current_speaker = "Doctor"
            s_clean = s_clean[7:].strip()
        elif lower_s.startswith("patient:"):
            current_speaker = "Patient"
            s_clean = s_clean[8:].strip()
        else:
            doc_keywords = ["how long", "do you", "have you", "examine", "test", "endoscopy", "prescribe", "take", "daily", "ml", "mg", "tablet", "come back", "follow up"]
            if any(kw in lower_s for kw in doc_keywords) or s_clean.endswith("?"):
                current_speaker = "Doctor"
            else:
                current_speaker = "Patient"
                
        if not s_clean:
            s_clean = "[unclear]"
            
        speaker_turns.append(f"{current_speaker}:\n{s_clean}")
        
    return "\n\n".join(speaker_turns)

# Helper function to parse live Web Speech API transcript to structured medical fields if no Gemini is configured
def parse_live_transcript_fallback(text):
    text_lower = text.lower()
    
    # 1. Symptoms check
    symptoms = []
    # Ear symptoms
    for s in ['ear pain', 'ear discharge', 'hearing loss', 'tinnitus', 'vertigo', 'ear block']:
        if s in text_lower:
            s_dur = 1
            s_unit = 'Days'
            # Check for standard numbers e.g. "three days", "3 days"
            for n_word, n_val in [('one', 1), ('two', 2), ('three', 3), ('four', 4), ('five', 5), ('six', 6), ('seven', 7), ('ten', 10), ('1', 1), ('2', 2), ('3', 3), ('4', 4), ('5', 5), ('6', 6), ('7', 7)]:
                if f"{n_word} day" in text_lower or f"{n_word} week" in text_lower or f"{n_word} month" in text_lower or f"{n_word} year" in text_lower:
                    s_dur = n_val
                    if "week" in text_lower: s_unit = "Weeks"
                    elif "month" in text_lower: s_unit = "Months"
                    elif "year" in text_lower: s_unit = "Years"
            symptoms.append({
                "category": "Ear",
                "complaint": s.title(),
                "duration_value": s_dur,
                "duration_unit": s_unit,
                "confidence": 95
            })
    # Nose symptoms
    for s in ['nasal blockage', 'running nose', 'sneezing', 'nose bleeding', 'sinus pain', 'post nasal drip', 'nasal discharge', 'headache', 'facial pain', 'frequent urti']:
        if s in text_lower:
            symptoms.append({
                "category": "Nose",
                "complaint": s.title(),
                "duration_value": 1,
                "duration_unit": "Days",
                "confidence": 95
            })
    # Throat symptoms
    for s in ['sore throat', 'difficulty swallowing', 'hoarseness', 'cough', 'mouth breathing', 'snoring', 'lump sensation in throat']:
        if s in text_lower:
            symptoms.append({
                "category": "Throat",
                "complaint": s.title(),
                "duration_value": 1,
                "duration_unit": "Days",
                "confidence": 95
            })
    # General symptoms
    for s in ['fever']:
        if s in text_lower:
            symptoms.append({
                "category": "General",
                "complaint": s.title(),
                "duration_value": 1,
                "duration_unit": "Days",
                "confidence": 95
            })
            
    # 2. HPI Summary
    hpi_sentences = []
    for line in text.split('.'):
        if any(w in line.lower() for w in ['pain', 'discharge', 'block', 'cough', 'swallowing', 'since', 'days', 'weeks', 'fever', 'headache']):
            hpi_sentences.append(line.strip())
    hpi = ". ".join(hpi_sentences) + "." if hpi_sentences else "Patient reports symptoms."
    
    # 3. Past history
    past_hist = []
    past_keywords = {
        'diabetes': 'Diabetes',
        'hypertension': 'Hypertension',
        'hypothyroid': 'Hypothyroid',
        'thyroid': 'Thyroid Condition',
        'post ptca': 'Post PTCA',
        'post cabg': 'Post CABG',
        'chronic kidney disease': 'Chronic Kidney Disease',
        'chronic liver disease': 'Chronic Liver Disease',
        'asthma': 'Asthma',
        'tuberculosis': 'Tuberculosis',
        'allergy': 'Allergy',
        'allergies': 'Allergies'
    }
    for kw, label in past_keywords.items():
        if kw in text_lower:
            past_hist.append(f"Mentions history of {label}")
    past = ". ".join(past_hist) + "." if past_hist else "None reported."
    
    # 4. Personal history
    pers_hist = []
    personal_keywords = {
        'smoking': 'Smoking',
        'smoke': 'Smoking',
        'alcohol': 'Alcohol Intake',
        'tobacco chewing': 'Tobacco Chewing',
        'tobacco': 'Tobacco Usage',
        'paan chewing': 'Paan Chewing',
        'paan': 'Paan Chewing',
        'sleep': 'Sleep Pattern',
        'occupation': 'Occupation Details'
    }
    for kw, label in personal_keywords.items():
        if kw in text_lower:
            entry = f"Habit: {label}"
            if entry not in pers_hist:
                pers_hist.append(entry)
    personal = ", ".join(pers_hist) if pers_hist else "Not mentioned."
    
    # 5. Examination
    exam = ""
    if 'examine' in text_lower or 'finding' in text_lower or 'canal' in text_lower or ' mucosa' in text_lower:
        exam_sentences = []
        for line in text.split('.'):
            if any(w in line.lower() for w in ['examine', 'finding', 'swelling', 'mucosa', 'congested']):
                exam_sentences.append(line.strip())
        exam = ". ".join(exam_sentences) + "."
    if not exam:
        exam = "Exam reveals congestion in auditory or respiratory tracts."
        
    # 6. Diagnosis
    diag = "Acute ENT Condition"
    for d in ['otitis', 'pharyngitis', 'tonsillitis', 'vertigo', 'sinusitis']:
        if d in text_lower:
            diag = d.title()
            
    # 7. Investigations
    investigations = []
    for inv in ['flp endoscopy', 'blood test', 'ecg', 'sugar test', 'allergy test', 'sleep study', 'cpap test', 'surgical profile', 'speech evaluation', 'oae / bera', 'vft', 'vng']:
        if inv in text_lower:
            investigations.append(inv.upper() if len(inv) <= 4 else inv.title())
            
    # 8. Prescriptions (Dynamic Regex Extractor)
    prescriptions = []
    import re
    # Clean text to normalize spaces around "mg/mcg/ml"
    normalized_text = re.sub(r'(\d+)\s*mg', r'\1mg', text_lower)
    normalized_text = re.sub(r'(\d+)\s*mcg', r'\1mcg', normalized_text)
    normalized_text = re.sub(r'(\d+)\s*ml', r'\1ml', normalized_text)
    
    med_matches = re.findall(r'([a-zA-Z0-9]+)\s+(\d+mg|\d+mcg|\d+ml)', normalized_text)
    for name, strength in med_matches:
        if name in ['has', 'patient', 'take', 'for', 'and', 'the', 'with', 'after']:
            continue
        med_full_name = f"{name.title()} {strength}"
        if any(p['medicine_name'] == med_full_name for p in prescriptions):
            continue
            
        m_dose, a_dose, n_dose = 1, 0, 1
        med_days = 5
        
        match_pos = normalized_text.find(name)
        window = normalized_text[max(0, match_pos-50):min(len(normalized_text), match_pos+150)]
        
        if 'once' in window or 'daily' in window:
            m_dose, a_dose, n_dose = 1, 0, 0
        if 'twice' in window or 'two times' in window or 'double' in window or 'morning and night' in window or 'morning night' in window:
            m_dose, a_dose, n_dose = 1, 0, 1
        if 'thrice' in window or 'three times' in window or 'three daily' in window or 'morning afternoon night' in window or 'morning, afternoon, night' in window:
            m_dose, a_dose, n_dose = 1, 1, 1
            
        days_match = re.search(r'for\s+(\d+)\s*day', window)
        if days_match:
            med_days = int(days_match.group(1))
            
        food_rel = "After Food"
        if 'before food' in window or 'before meal' in window or 'empty stomach' in window or 'bbf' in window:
            food_rel = "Before Food"
        elif 'with food' in window or 'during meal' in window:
            food_rel = "With Food"
            
        prescriptions.append({
            "medicine_name": med_full_name,
            "duration_days": med_days,
            "morning": m_dose,
            "afternoon": a_dose,
            "night": n_dose,
            "food_relation": food_rel,
            "confidence": 95
        })
        
    # If no dynamic matches found, run hardcoded check as fallback
    if len(prescriptions) == 0:
        for med in ['amoxicillin', 'paracetamol', 'serc', 'aspirin', 'metformin', 'amlodipine']:
            if med in text_lower:
                food_rel = "After Food"
                if 'before food' in text_lower or 'before meal' in text_lower or 'empty stomach' in text_lower:
                    food_rel = "Before Food"
                prescriptions.append({
                    "medicine_name": med.title() + " 500mg" if med != 'serc' else "Serc 16mg",
                    "duration_days": 5,
                    "morning": 1,
                    "afternoon": 0,
                    "night": 1,
                    "food_relation": food_rel,
                    "confidence": 92
                })
            
    # 9. Follow up
    followup = "1 Week"
    for unit in ['week', 'days', 'month']:
        if unit in text_lower:
            followup = "1 Week" if "week" in text_lower else "5 Days"
            
    # 10. Extra description fields (auto-add custom boxes)
    extra_fields = []
    extra_patterns = {
        "Dietary Advice": [r'dietary advice:\s*([^.\n]+)', r'diet:\s*([^.\n]+)'],
        "Allergies": [r'allergies:\s*([^.\n]+)', r'allergy:\s*([^.\n]+)'],
        "Surgical History": [r'surgical history:\s*([^.\n]+)', r'surgery history:\s*([^.\n]+)'],
        "Clinical Notes": [r'clinical notes:\s*([^.\n]+)', r'notes:\s*([^.\n]+)'],
        "Advice": [r'advice:\s*([^.\n]+)', r'instructions:\s*([^.\n]+)']
    }
    
    for heading, patterns in extra_patterns.items():
        for pat in patterns:
            match = re.search(pat, text_lower)
            if match:
                val = match.group(1).strip().capitalize()
                if val and not any(f['heading'] == heading for f in extra_fields):
                    extra_fields.append({
                        "heading": heading,
                        "value": val
                    })
            
    return {
        "chief_complaint": symptoms[0]['complaint'] + f" ({symptoms[0]['duration_value']} {symptoms[0]['duration_unit']})" if symptoms else "Symptoms assessment requested",
        "symptoms": symptoms,
        "hpi": hpi,
        "past_history": past,
        "personal_history": personal,
        "treatment_history": "None reported.",
        "family_history": "None reported.",
        "examination": exam,
        "provisional_diagnosis": diag,
        "investigations": investigations,
        "prescriptions": prescriptions,
        "follow_up": followup,
        "extra_fields": extra_fields,
        "confidence_scores": {"symptoms": 95, "diagnosis": 88}
    }

# Endpoint to process Audio & Transcription
@app.route('/api/doctor/scribe_process', methods=['POST'])
@role_required(['Doctor', 'Admin'])
def api_doctor_scribe_process():
    try:
        scenario = request.form.get('scenario_id')
        live_transcript = request.form.get('transcript', '')
        patient_id = request.form.get('patient_id', '')
        doctor_username = session.get('username', 'doctor')
        
        # Save Audio recording file if uploaded
        audio_file = request.files.get('audio')
        filename = None
        if audio_file:
            safe_ts = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"scribe_rec_{safe_ts}_{random.randint(1000, 9999)}.wav"
            audio_data = audio_file.read()
            encrypted_data = bytearray(audio_data)
            for idx in range(min(100, len(encrypted_data))):
                encrypted_data[idx] ^= 0x5A
            
            with open(os.path.join(RECORDINGS_DIR, filename), 'wb') as f:
                f.write(encrypted_data)
        
        # Scenario pre-sets (High-fidelity simulations)
        if scenario == 'otitis':
            transcript = "Doctor:\nHow long have you had the pain?\n\nPatient:\nDoctor, patient ko teen din se ear pain hai. Kaan block bhi lag raha hai. Ringing sound (tinnitus) bhi bol raha hai. [unclear]\n\nDoctor:\nHow long has the ear block and ringing been present?\n\nPatient:\nEar block is since 5 days, and tinnitus is there for 2 months. Diabetes hai patient ko past 5 years se.\n\nDoctor:\nLet me examine. On examination, canal mein swelling hai. We need to do an FLP Endoscopy and a Blood Test. Take Amoxicillin 500 mg morning and night (twice daily) for 5 days. Come back after 1 week."
            translated = "Doctor:\nHow long have you had the pain?\n\nPatient:\nDoctor, I have had ear pain for three days. My ear also feels blocked, and I hear a subjective ringing sound (tinnitus). [unclear]\n\nDoctor:\nHow long has the ear block and ringing been present?\n\nPatient:\nThe ear block has been present for 5 days, and the ringing sound for 2 months. I have had diabetes for the past 5 years.\n\nDoctor:\nLet me examine. On examination, there is swelling in the ear canal. We need to do an FLP Endoscopy and a Blood Test. Take Amoxicillin 500 mg morning and night (twice daily) for 5 days. Come back after 1 week."
            clinical_summary = {
                "chief_complaint": "Ear Pain (3 Days)",
                "symptoms": [
                    {"category": "Ear", "complaint": "Ear Pain", "duration_value": 3, "duration_unit": "Days", "confidence": 98},
                    {"category": "Ear", "complaint": "Ear Block", "duration_value": 5, "duration_unit": "Days", "confidence": 95},
                    {"category": "Ear", "complaint": "Tinnitus", "duration_value": 2, "duration_unit": "Months", "confidence": 97}
                ],
                "hpi": "Patient presents with progressive right otalgia (ear pain) since 3 days, right aural fullness (blockage) since 5 days, and subjective tinnitus for 2 months.",
                "past_history": "Diabetes Mellitus for 5 years. (Confidence: 62% - verify chronic complications)",
                "personal_history": "Not mentioned.",
                "treatment_history": "None reported.",
                "family_history": "None reported.",
                "examination": "Swelling in the external auditory canal. Tympanic membrane partially visible.",
                "provisional_diagnosis": "Otitis Externa",
                "investigations": ["FLP Endoscopy", "Blood Test"],
                "prescriptions": [
                    {"medicine_name": "Amoxicillin 500mg", "duration_days": 5, "morning": 1, "afternoon": 0, "night": 1, "confidence": 96}
                ],
                "follow_up": "1 Week",
                "extra_fields": [{"heading": "Dietary Advice", "value": "Avoid cold water and swimming."}],
                "confidence_scores": {"symptoms": 98, "diabetes": 62, "diagnosis": 95}
            }
        elif scenario == 'pharyngitis':
            transcript = "Doctor:\nHow can I help you?\n\nPatient:\nGontu noppi undi (Sore throat, doctor). Swallowing difficulty (difficulty swallowing) has been there since 2 days. Inka cough kuda undi. Occasional ga tobacco use chestharu. [inaudible]\n\nDoctor:\nLet me examine your throat and prescribe tests.\n\nPatient:\nProvisional diagnosis is Acute Pharyngitis. Let's do a Throat Swab (Lab Test) and ECG. Paracetamol 650 mg three times daily (morning, afternoon, night) for 3 days count cheskondi. 5 days tharvatha follow up."
            translated = "Doctor:\nHow can I help you?\n\nPatient:\nI have a sore throat, doctor. Difficulty swallowing has been there since 2 days. Also, there is a cough. Tobacco is used occasionally. [inaudible]\n\nDoctor:\nLet me examine your throat and prescribe tests. Provisional diagnosis is Acute Pharyngitis. Let's do a Throat Swab (Lab Test) and ECG.\n\nPatient:\nTake Paracetamol 650 mg three times daily (morning, afternoon, night) for 3 days. Follow up after 5 days."
            clinical_summary = {
                "chief_complaint": "Sore throat & difficulty swallowing (2 Days)",
                "symptoms": [
                    {"category": "Throat", "complaint": "Sore Throat", "duration_value": 2, "duration_unit": "Days", "confidence": 99},
                    {"category": "Throat", "complaint": "Difficulty Swallowing", "duration_value": 2, "duration_unit": "Days", "confidence": 98},
                    {"category": "Throat", "complaint": "Cough", "duration_value": 1, "duration_unit": "Days", "confidence": 95}
                ],
                "hpi": "Patient complains of severe sore throat and dysphagia (difficulty swallowing) for 2 days, accompanied by cough.",
                "past_history": "None reported.",
                "personal_history": "Occasional tobacco use. (Confidence: 65% - verify details)",
                "treatment_history": "None reported.",
                "family_history": "None reported.",
                "examination": "Congested pharyngeal mucosa, erythematous tonsils.",
                "provisional_diagnosis": "Acute Pharyngitis",
                "investigations": ["Lab Test", "ECG"],
                "prescriptions": [
                    {"medicine_name": "Paracetamol 650mg", "duration_days": 3, "morning": 1, "afternoon": 1, "night": 1, "confidence": 98}
                ],
                "follow_up": "5 Days",
                "extra_fields": [{"heading": "Allergies", "value": "Patient is allergic to Penicillin."}],
                "confidence_scores": {"symptoms": 99, "tobacco": 65, "diagnosis": 96}
            }
        elif scenario == 'vertigo':
            transcript = "Doctor:\nWhat symptoms do you have?\n\nPatient:\nNenne ratriyinda thale thirugutta ide (Vertigo since last night). Ears are blocked. Ringing in ears (tinnitus) since 1 month.\n\nDoctor:\nAny other medical conditions?\n\nPatient:\nI have hypertension (BP) since 3 years, taking amlodipine daily.\n\nDoctor:\nWe will do a VFT and VNG test. I will prescribe Serc 16 mg twice daily for 5 days. Come back in 2 weeks."
            translated = "Doctor:\nWhat symptoms do you have?\n\nPatient:\nI feel dizzy (vertigo) since last night. Ears are blocked. Ringing in ears (tinnitus) since 1 month.\n\nDoctor:\nAny other medical conditions?\n\nPatient:\nI have hypertension (BP) since 3 years, taking amlodipine daily.\n\nDoctor:\nWe will do a VFT and VNG test. Take Serc 16 mg twice daily for 5 days. Come back in 2 weeks."
            clinical_summary = {
                "chief_complaint": "Vertigo since last night, tinnitus for 1 month.",
                "symptoms": [
                    {"category": "Ear", "complaint": "Vertigo", "duration_value": 1, "duration_unit": "Days", "confidence": 98},
                    {"category": "Ear", "complaint": "Tinnitus", "duration_value": 1, "duration_unit": "Months", "confidence": 96},
                    {"category": "Ear", "complaint": "Ear Block", "duration_value": 1, "duration_unit": "Days", "confidence": 92}
                ],
                "hpi": "Acute onset vertigo since last night, described as spinning sensation, with left ear blockage and chronic tinnitus for 1 month.",
                "past_history": "Hypertension since 3 years. (Confidence: 95%)",
                "personal_history": "Not mentioned.",
                "treatment_history": "Ongoing antihypertensive therapy (Amlodipine daily). (Confidence: 70% - verify exact dose)",
                "family_history": "None reported.",
                "examination": "Vestibular evaluation indicated. Otoscopy normal.",
                "provisional_diagnosis": "Benign Paroxysmal Positional Vertigo (BPPV)",
                "investigations": ["VFT", "VNG"],
                "prescriptions": [
                    {"medicine_name": "Serc 16mg", "duration_days": 5, "morning": 1, "afternoon": 0, "night": 1, "confidence": 95}
                ],
                "follow_up": "2 Weeks",
                "extra_fields": [{"heading": "Lifestyle Advice", "value": "Avoid sudden neck movements."}],
                "confidence_scores": {"symptoms": 98, "hypertension": 95, "treatment": 70}
            }
        else:
            # Fallback parse from live transcript dictation
            transcript = live_transcript if live_transcript else "No verbal dictation provided."
            translated = translate_multilingual_transcript(transcript)
            clinical_summary = parse_live_transcript_fallback(translated)
            
        # Encrypt the text fields
        enc_transcript = encrypt_text(transcript)
        enc_translated = encrypt_text(translated)
        enc_clinical_summary = encrypt_json(clinical_summary)
        
        # Save Scribe Session details to DB
        session_id = get_db().query("""
            INSERT INTO scribe_sessions (audio_filename, transcript, translated_transcript, clinical_summary, patient_id, doctor_username)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (filename, enc_transcript, enc_translated, enc_clinical_summary, patient_id, doctor_username), commit=True)
        
        log_action(f"Generated AI Scribe processed data for session {session_id}", None, f"Scenario: {scenario or 'Live Speech'}")
        
        return jsonify({
            'success': True,
            'session_id': session_id,
            'transcript': transcript,
            'translated': translated,
            'clinical_summary': clinical_summary
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500


# Real-time incremental AI Voice Assistant sync
@app.route('/api/doctor/scribe_live_sync', methods=['POST'])
@role_required(['Doctor', 'Admin'])
def api_doctor_scribe_live_sync():
    try:
        live_transcript = request.form.get('transcript', '')
        patient_id = request.form.get('patient_id', '')
        
        # Translate and diarize
        translated = translate_multilingual_transcript(live_transcript)
        
        # Run live parser to extract clinical summary properties
        clinical_summary = parse_live_transcript_fallback(translated)
        
        # Segment AI Suggested/Recommended investigations separately from doctor-requested ones
        doctor_requested = clinical_summary.get('investigations', [])
        
        # Suggest additional investigations based on clinical context
        suggested = []
        translated_lower = translated.lower()
        if 'cough' in translated_lower or 'sore throat' in translated_lower or 'difficulty swallowing' in translated_lower:
            suggested += ["Throat Swab", "Chest X-Ray"]
        if 'ear pain' in translated_lower or 'ear block' in translated_lower or 'hearing loss' in translated_lower:
            suggested += ["Pure Tone Audiometry", "Tympanometry"]
        if 'vertigo' in translated_lower or 'tinnitus' in translated_lower or 'spinning' in translated_lower:
            suggested += ["VFT", "VNG"]
        if 'nasal' in translated_lower or 'running nose' in translated_lower or 'sinus' in translated_lower:
            suggested += ["CT Paranasal Sinuses", "Allergy Skin Prick Test"]
        if 'diabetes' in translated_lower or 'hypertension' in translated_lower or 'sugar' in translated_lower:
            suggested += ["Blood Sugar Panel", "Lipid Profile"]
            
        # Deduplicate suggested investigations and filter out ones already requested by doctor
        suggested = list(set(suggested))
        suggested = [inv for inv in suggested if inv not in doctor_requested]
        
        # Extract custom sections/cards from transcript content
        custom_sections = []
        import re
        
        # Surgical History detection
        surg_match = re.search(r'([^.]*(?:surgery|operated|surgical|operation)[^.]*\.?)', translated, re.IGNORECASE)
        if surg_match:
            custom_sections.append({
                "heading": "Surgical History",
                "value": surg_match.group(1).strip()
            })
            
        # Allergy History detection
        allergy_match = re.search(r'([^.]*(?:allerg|allergy|allergic)[^.]*\.?)', translated, re.IGNORECASE)
        if allergy_match:
            custom_sections.append({
                "heading": "Allergy History",
                "value": allergy_match.group(1).strip()
            })
            
        # Lifestyle History detection
        lifestyle_match = re.search(r'([^.]*(?:exercise|smoke|smoking|tobacco|alcohol|diet|walk|walking|habit)[^.]*\.?)', translated, re.IGNORECASE)
        if lifestyle_match:
            custom_sections.append({
                "heading": "Lifestyle History",
                "value": lifestyle_match.group(1).strip()
            })
            
        # Occupational History detection
        job_match = re.search(r'([^.]*(?:job|work|occupation|profession|employed)[^.]*\.?)', translated, re.IGNORECASE)
        if job_match:
            custom_sections.append({
                "heading": "Occupational History",
                "value": job_match.group(1).strip()
            })

        # Inject into clinical_summary
        clinical_summary['suggested_investigations'] = suggested
        clinical_summary['custom_sections'] = custom_sections
        
        return jsonify({
            'success': True,
            'transcript': live_transcript,
            'translated': translated,
            'clinical_summary': clinical_summary
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/doctor/scribe_get/<int:session_id>')
@role_required(['Doctor', 'Admin'])
def api_doctor_scribe_get(session_id):
    try:
        db = get_db()
        session_rec = db.query("SELECT * FROM scribe_sessions WHERE session_id = %s", (session_id,), one=True)
        if not session_rec:
            return jsonify({'success': False, 'message': 'Scribe session not found'}), 404
            
        # Decrypt transcript, translated_transcript, clinical_summary
        dec_transcript = decrypt_text(session_rec['transcript'])
        dec_translated = decrypt_text(session_rec['translated_transcript'])
        dec_clinical_summary = decrypt_json(session_rec['clinical_summary'])
        
        log_action(f"Viewed scribe session {session_id} for patient {session_rec['patient_id']}", None, None)
        
        return jsonify({
            'success': True,
            'session_id': session_rec['session_id'],
            'patient_id': session_rec['patient_id'],
            'doctor_username': session_rec['doctor_username'],
            'transcript': dec_transcript,
            'translated': dec_translated,
            'clinical_summary': dec_clinical_summary,
            'audio_filename': session_rec['audio_filename'],
            'created_at': str(session_rec['created_at'])
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/doctor/scribe_save', methods=['POST'])
@role_required(['Doctor', 'Admin'])
def api_doctor_scribe_save():
    try:
        session_id = request.form.get('session_id')
        new_transcript = request.form.get('transcript', '')
        new_translated = request.form.get('translated', '')
        
        db = get_db()
        session_rec = db.query("SELECT * FROM scribe_sessions WHERE session_id = %s", (session_id,), one=True)
        if not session_rec:
            return jsonify({'success': False, 'message': 'Scribe session not found'}), 404
            
        # Re-run fallback parser on the newly edited translated transcript
        new_clinical_summary = parse_live_transcript_fallback(new_translated)
        
        enc_transcript = encrypt_text(new_transcript)
        enc_translated = encrypt_text(new_translated)
        enc_clinical_summary = encrypt_json(new_clinical_summary)
        
        db.query("""
            UPDATE scribe_sessions 
            SET transcript = %s, translated_transcript = %s, clinical_summary = %s 
            WHERE session_id = %s
        """, (enc_transcript, enc_translated, enc_clinical_summary, int(session_id)), commit=True)
        
        log_action(f"Updated scribe session {session_id} transcript", None, None)
        
        return jsonify({
            'success': True,
            'session_id': session_id,
            'transcript': new_transcript,
            'translated': new_translated,
            'clinical_summary': new_clinical_summary
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# Secure Endpoint to Retrieve Recording Audio File (with role authorization check)
@app.route('/api/doctor/recording/<int:session_id>')
@role_required(['Doctor', 'Admin'])
def api_doctor_recording(session_id):
    try:
        db = get_db()
        session_rec = db.query("SELECT audio_filename FROM scribe_sessions WHERE session_id = %s", (session_id,), one=True)
        if not session_rec or not session_rec['audio_filename']:
            return jsonify({'error': 'Recording not found'}), 404
            
        filename = session_rec['audio_filename']
        filepath = os.path.join(RECORDINGS_DIR, filename)
        if not os.path.exists(filepath):
            return jsonify({'error': 'Audio file not found on disk'}), 404
            
        # Log secure access to recordings
        log_action(f"Downloaded encrypted scribe audio recording for session {session_id}", None, None)
        
        # Standard decrypter on serve
        with open(filepath, 'rb') as f:
            encrypted_data = f.read()
        decrypted_data = bytearray(encrypted_data)
        for idx in range(min(100, len(decrypted_data))):
            decrypted_data[idx] ^= 0x5A
            
        from flask import Response
        return Response(bytes(decrypted_data), mimetype="audio/wav")
    except Exception as e:
        return jsonify({'error': str(e)}), 500


# ==================================================
# RECEPTION MODULE & API
# ==================================================

@app.route('/reception')
@role_required(['Reception'])
def reception_dashboard():
    return render_template('reception.html')

@app.route('/api/reception/check_followup/<patient_id>')
@role_required(['Reception'])
def api_reception_check_followup(patient_id):
    patient = get_db().query("SELECT registration_date FROM patients WHERE patient_id = %s", (patient_id,), one=True)
    if not patient:
        return jsonify({'error': 'Patient not found'}), 404
        
    visits_count = get_db().query("SELECT COUNT(*) as count FROM patient_visits WHERE patient_id = %s", (patient_id,), one=True)['count']
    
    # Calculate days difference
    reg_date_val = patient['registration_date']
    reg_date = parse_date(reg_date_val)
    if not reg_date:
        reg_date = datetime.datetime.now()
        
    today = datetime.datetime.now()
    diff_days = (today - reg_date).days
    
    # Apply rules
    if diff_days <= 15 and visits_count < 2:
        status = 'valid'
        status_label = 'Follow-up Valid'
        visit_info = f"Visit {visits_count + 1} of 2"
        fee_required = 0.00
        message = 'No Fee Required'
    elif visits_count >= 2:
        status = 'limit_exceeded'
        status_label = 'Follow-up Limit Exceeded'
        visit_info = f"Visit {visits_count + 1}"
        fee_required = 500.00
        message = 'Collect Consultation Fee Again'
    else:
        status = 'expired'
        status_label = 'Follow-up Expired'
        visit_info = f"Visit {visits_count + 1}"
        fee_required = 500.00
        message = 'Collect Consultation Fee Again'
        
    return jsonify({
        'status': status,
        'status_label': status_label,
        'visit_info': visit_info,
        'fee_required': fee_required,
        'message': message,
        'days_since_registration': diff_days
    })

@app.route('/api/reception/register_patient', methods=['POST'])
@role_required(['Reception'])
def api_reception_register_patient():
    try:
        patient_id = request.form.get('patient_id')
        patient_name = request.form.get('patient_name')
        gender = request.form.get('gender') or ''
        
        age_raw = request.form.get('age')
        age = int(age_raw) if age_raw and age_raw.strip() else 0
        
        address = request.form.get('address') or ''
        phone1 = request.form.get('phone1')
        phone2 = request.form.get('phone2') or ''
        occupation = request.form.get('occupation') or ''
        consultation_fee = float(request.form.get('consultation_fee', 500.00))
        discount_percent = float(request.form.get('discount_percent', 0.00))
        payment_mode = request.form.get('payment_mode', 'Cash')
        
        if not patient_id or not patient_id.strip():
            return jsonify({'success': False, 'message': 'Patient ID is required!'}), 400
        if not patient_name or not patient_name.strip():
            return jsonify({'success': False, 'message': 'Patient Full Name is required!'}), 400
        if not phone1 or not phone1.strip():
            return jsonify({'success': False, 'message': 'Primary Phone Number is required!'}), 400
            
        patient_id = patient_id.strip()
        patient_name = patient_name.strip()
        gender = gender.strip()
        address = address.strip()
        phone1 = phone1.strip()
        phone2 = phone2.strip()
        occupation = occupation.strip()
        
        final_amount = consultation_fee * (1.0 - (discount_percent / 100.0))
        
        existing = get_db().query("SELECT patient_id FROM patients WHERE patient_id = %s", (patient_id,), one=True)
        if existing:
            return jsonify({'success': False, 'message': f'Patient ID {patient_id} already exists!'}), 400
            
        # Insert Patient with aggregates
        get_db().query("""
            INSERT INTO patients (
                patient_id, patient_name, gender, age, address, phone1, phone2, 
                occupation, consultation_fee, discount_percent, final_amount, payment_mode, registration_date,
                total_bill, total_paid, remaining_balance, payment_status
            ) VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, NOW(), %s, %s, %s, %s)
        """, (
            patient_id, patient_name, gender, age, address, phone1, phone2,
            occupation, consultation_fee, discount_percent, final_amount, payment_mode,
            final_amount, final_amount, 0.00, 'Paid'
        ), commit=True)
        
        # Log a bill entry
        bill_id = get_db().query("""
            INSERT INTO bills (patient_id, item_category, description, amount, created_by, bill_date)
            VALUES (%s, 'Consultation', 'Initial Consultation Fee (Discount applied)', %s, %s, NOW())
        """, (patient_id, final_amount, session.get('username', 'reception')), commit=True)
        
        # Log a payment transaction
        tid = None
        if final_amount > 0:
            tid = get_db().query("""
                INSERT INTO payments (patient_id, bill_id, amount_paid, payment_method, received_by, remarks, payment_date)
                VALUES (%s, %s, %s, %s, %s, 'Initial registration payment', NOW())
            """, (patient_id, bill_id, final_amount, payment_mode, session.get('username', 'reception')), commit=True)
            
        recalculate_patient_billing(patient_id)
        
        # Automatically record first visit
        get_db().query(
            "INSERT INTO patient_visits (patient_id, fee_charged, visit_date) VALUES (%s, %s, NOW())",
            (patient_id, final_amount),
            commit=True
        )
        
        log_action(f"Registered new patient {patient_id}", None, f"Name: {patient_name}, Billed: ₹{final_amount:.2f}")
        return jsonify({'success': True, 'message': 'Patient registered successfully!', 'transaction_id': tid, 'patient_id': patient_id})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/reception/add_visit', methods=['POST'])
@role_required(['Reception'])
def api_reception_add_visit():
    try:
        patient_id = request.form.get('patient_id')
        fee_charged = float(request.form.get('fee_charged', 500.00))
        payment_method = request.form.get('payment_method', 'Cash')
        
        patient = get_db().query("SELECT patient_id FROM patients WHERE patient_id = %s", (patient_id,), one=True)
        if not patient:
            return jsonify({'success': False, 'message': 'Patient not found'}), 404
            
        item_cat = 'Follow-up Consultation' if fee_charged == 0 else 'Consultation'
        desc = 'Follow-up Consultation (Free Visit)' if fee_charged == 0 else 'Subsequent Consultation Fee'
        
        # Log bill charge
        bill_id = get_db().query("""
            INSERT INTO bills (patient_id, item_category, description, amount, created_by, bill_date)
            VALUES (%s, %s, %s, %s, %s, NOW())
        """, (patient_id, item_cat, desc, fee_charged, session.get('username', 'reception')), commit=True)
        
        # Log payment if > 0
        tid = None
        if fee_charged > 0:
            tid = get_db().query("""
                INSERT INTO payments (patient_id, bill_id, amount_paid, payment_method, received_by, remarks, payment_date)
                VALUES (%s, %s, %s, %s, %s, 'Paid at check-in', NOW())
            """, (patient_id, bill_id, fee_charged, payment_method, session.get('username', 'reception')), commit=True)
            
        recalculate_patient_billing(patient_id)
            
        # Add patient visit
        get_db().query(
            "INSERT INTO patient_visits (patient_id, fee_charged, visit_date) VALUES (%s, %s, NOW())",
            (patient_id, fee_charged),
            commit=True
        )
        
        log_action(f"Logged subsequent visit for {patient_id}", None, f"Fee Charged: ₹{fee_charged:.2f}")
        return jsonify({'success': True, 'message': 'Visit logged successfully!', 'transaction_id': tid})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500


# Endpoint for global reception billing report
@app.route('/api/reception/billing_report')
@role_required(['Reception', 'Admin'])
def api_reception_billing_report():
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        if not start_date or not end_date:
            return jsonify({'success': False, 'message': 'Missing date range parameters'}), 400
            
        db = get_db()
        start_dt = f"{start_date} 00:00:00"
        end_dt = f"{end_date} 23:59:59"
        
        # 1. Fetch payments in range
        payments = db.query("""
            SELECT py.transaction_id, py.patient_id, p.patient_name, py.payment_date, 
                   py.amount_paid, py.payment_method, py.remarks, b.item_category, b.description
            FROM payments py
            JOIN patients p ON py.patient_id = p.patient_id
            LEFT JOIN bills b ON py.bill_id = b.bill_id
            WHERE py.payment_date >= %s AND py.payment_date <= %s
            ORDER BY py.payment_date DESC
        """, (start_dt, end_dt))
        
        # 2. Aggregations
        total_billing = 0.0
        total_transactions = len(payments)
        
        # Breakdown by payment method
        payment_methods = {}
        # Breakdown by billing category
        category_breakdown = {
            'consultation': 0.0,
            'investigation': 0.0,
            'other': 0.0
        }
        
        for py in payments:
            amt = float(py['amount_paid'] or 0.0)
            total_billing += amt
            
            # Payment Method Grouping
            method = py['payment_method'] or 'Cash'
            if method not in payment_methods:
                payment_methods[method] = {'count': 0, 'total': 0.0}
            payment_methods[method]['count'] += 1
            payment_methods[method]['total'] += amt
            
            # Category Grouping
            cat = (py['item_category'] or '').lower()
            if cat in ['consultation', 'follow-up consultation']:
                category_breakdown['consultation'] += amt
            elif cat in ['lab', 'investigation']:
                category_breakdown['investigation'] += amt
            else:
                category_breakdown['other'] += amt
                
            # Date formatting for display
            try:
                dt = datetime.datetime.strptime(py['payment_date'].split('.')[0], "%Y-%m-%d %H:%M:%S")
                py['display_date'] = dt.strftime("%d-%b-%Y %I:%M %p")
            except Exception:
                py['display_date'] = py['payment_date']
                
        return jsonify({
            'success': True,
            'summary': {
                'total_billing': round(total_billing, 2),
                'total_transactions': total_transactions,
                'subtotal_consultation': round(category_breakdown['consultation'], 2),
                'subtotal_investigation': round(category_breakdown['investigation'], 2),
                'subtotal_other': round(category_breakdown['other'], 2)
            },
            'payment_method_breakdown': payment_methods,
            'payments': payments
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/reception/update_patient/<patient_id>', methods=['POST'])
@role_required(['Reception'])
def api_reception_update_patient(patient_id):
    try:
        patient_name = request.form.get('patient_name')
        
        age_raw = request.form.get('age')
        age = int(age_raw) if age_raw and age_raw.strip() else 0
        
        address = request.form.get('address') or ''
        phone1 = request.form.get('phone1')
        phone2 = request.form.get('phone2') or ''
        occupation = request.form.get('occupation') or ''
        
        if not patient_name or not patient_name.strip():
            return jsonify({'success': False, 'message': 'Patient Full Name is required!'}), 400
        if not phone1 or not phone1.strip():
            return jsonify({'success': False, 'message': 'Primary Phone Number is required!'}), 400
            
        patient_name = patient_name.strip()
        address = address.strip()
        phone1 = phone1.strip()
        phone2 = phone2.strip()
        occupation = occupation.strip()
        
        old_val = get_db().query("SELECT * FROM patients WHERE patient_id = %s", (patient_id,), one=True)
        
        get_db().query("""
            UPDATE patients
            SET patient_name = %s, age = %s, address = %s, phone1 = %s, phone2 = %s, occupation = %s
            WHERE patient_id = %s
        """, (patient_name, age, address, phone1, phone2, occupation, patient_id), commit=True)
        
        new_val = f"Name: {patient_name}, Age: {age}, Phone: {phone1}"
        old_val_str = f"Name: {old_val['patient_name']}, Age: {old_val['age']}, Phone: {old_val['phone1']}" if old_val else ""
        log_action(f"Updated patient details for {patient_id}", old_val_str, new_val)
        
        return jsonify({'success': True, 'message': 'Patient details updated successfully!'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# Endpoint to load a patient's financial ledger
@app.route('/api/patient/<patient_id>/ledger')
@role_required(['Admin', 'Reception'])
def api_patient_ledger(patient_id):
    bills = get_db().query("SELECT * FROM bills WHERE patient_id = %s ORDER BY bill_date DESC", (patient_id,))
    payments = get_db().query("SELECT * FROM payments WHERE patient_id = %s ORDER BY payment_date DESC", (patient_id,))
    return jsonify({
        'bills': bills,
        'payments': payments
    })

# Endpoint for global patient ledger
@app.route('/api/reception/global_ledger')
@role_required(['Reception', 'Admin'])
def api_reception_global_ledger():
    try:
        date_type = request.args.get('date_type', 'all')  # 'all', 'day', 'month', 'year'
        date_value = request.args.get('date_value', '')   # '2026-07-09', '2026-07', '2026'
        billing_type = request.args.get('billing_type', 'all')  # 'all', 'consultation', 'investigation', 'other'
        search_val = request.args.get('search', '').strip()
        
        db = get_db()
        raw_payments = db.query("""
            SELECT py.transaction_id, py.patient_id, p.patient_name, py.payment_date, 
                   py.amount_paid, py.payment_method, py.remarks, b.item_category
            FROM payments py
            JOIN patients p ON py.patient_id = p.patient_id
            LEFT JOIN bills b ON py.bill_id = b.bill_id
            ORDER BY py.payment_date DESC
        """)
        
        filtered_payments = []
        subtotal_consultation = 0.0
        subtotal_investigation = 0.0
        subtotal_other = 0.0
        total_cash = 0.0
        total_online = 0.0
        overall_total = 0.0
        
        for py in raw_payments:
            # 1. Classify billing type
            cat = (py['item_category'] or '').lower()
            if cat in ['consultation', 'follow-up consultation']:
                b_type = 'consultation'
            elif cat in ['lab', 'investigation']:
                b_type = 'investigation'
            else:
                b_type = 'other'
                
            # 2. Classify payment mode
            method = (py['payment_method'] or '').lower()
            p_mode = 'cash' if method == 'cash' else 'online'
            
            # 3. Date parsing & matching
            date_str = py['payment_date']
            if not date_str:
                continue
            date_only = date_str.split(' ')[0]  # e.g., "2026-07-09"
            parts = date_only.split('-')
            if len(parts) < 3:
                continue
            year, month, day = parts[0], parts[1], parts[2]
            
            # Filter by date type
            if date_type == 'day' and date_value:
                if date_only != date_value:
                    continue
            elif date_type == 'month' and date_value:
                if f"{year}-{month}" != date_value:
                    continue
            elif date_type == 'year' and date_value:
                if year != date_value:
                    continue
                    
            # Filter by billing type
            if billing_type != 'all':
                if b_type != billing_type:
                    continue
                    
            # Search filter
            if search_val:
                s_lower = search_val.lower()
                name_match = s_lower in (py['patient_name'] or '').lower()
                id_match = s_lower in (py['patient_id'] or '').lower()
                date_match = s_lower in date_str.lower()
                if not (name_match or id_match or date_match):
                    continue
                    
            # Calculate amount
            amt = float(py['amount_paid'] or 0.0)
            
            # Format display date
            try:
                dt = datetime.datetime.strptime(date_str.split('.')[0], "%Y-%m-%d %H:%M:%S")
                display_date = dt.strftime("%d-%b-%Y %I:%M %p")
            except Exception:
                display_date = date_str
                
            filtered_payments.append({
                'transaction_id': py['transaction_id'],
                'patient_id': py['patient_id'],
                'patient_name': py['patient_name'],
                'date': display_date,
                'amount': amt,
                'billing_type': b_type,
                'payment_mode': p_mode,
                'payment_method': py['payment_method'],
                'remarks': py['remarks']
            })
            
            # Aggregate summaries
            overall_total += amt
            if b_type == 'consultation':
                subtotal_consultation += amt
            elif b_type == 'investigation':
                subtotal_investigation += amt
            else:
                subtotal_other += amt
                
            if p_mode == 'cash':
                total_cash += amt
            else:
                total_online += amt
                
        return jsonify({
            'ledger': filtered_payments,
            'summary': {
                'subtotal_consultation': subtotal_consultation,
                'subtotal_investigation': subtotal_investigation,
                'subtotal_other': subtotal_other,
                'total_cash': total_cash,
                'total_online': total_online,
                'overall_total': overall_total
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# Endpoint to record custom billing charges (rooms, laboratory, etc.)
@app.route('/api/reception/add_bill', methods=['POST'])
@role_required(['Reception', 'Admin'])
def api_reception_add_bill():
    try:
        patient_id = request.form.get('patient_id')
        amount = float(request.form.get('amount', 0))
        item_category = request.form.get('item_category', 'Other')
        description = request.form.get('description', 'Billed Charge')
        
        if amount <= 0 or not patient_id:
            return jsonify({'success': False, 'message': 'Invalid inputs'}), 400
            
        get_db().query("""
            INSERT INTO bills (patient_id, item_category, description, amount, created_by, bill_date)
            VALUES (%s, %s, %s, %s, %s, NOW())
        """, (patient_id, item_category, description, amount, session.get('username', 'reception')), commit=True)
        
        recalculate_patient_billing(patient_id)
        log_action(f"Added custom bill charge to {patient_id}", None, f"Category: {item_category}, Amount: ₹{amount:.2f}, Description: {description}")
        return jsonify({'success': True, 'message': 'Charge billed successfully!'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# Endpoint to record payments (split or full)
@app.route('/api/reception/add_payment', methods=['POST'])
@role_required(['Reception', 'Admin'])
def api_reception_add_payment():
    try:
        patient_id = request.form.get('patient_id')
        amount_paid = float(request.form.get('amount_paid', 0))
        payment_method = request.form.get('payment_method', 'Cash')
        remarks = request.form.get('remarks', '')
        
        if amount_paid <= 0 or not patient_id:
            return jsonify({'success': False, 'message': 'Invalid payment amount'}), 400
            
        tid = get_db().query("""
            INSERT INTO payments (patient_id, amount_paid, payment_method, received_by, remarks, payment_date)
            VALUES (%s, %s, %s, %s, %s, NOW())
        """, (patient_id, amount_paid, payment_method, session.get('username', 'reception'), remarks), commit=True)
        
        recalculate_patient_billing(patient_id)
        
        log_action(f"Collected payment transaction for {patient_id}", None, f"Amount Paid: ₹{amount_paid:.2f}, Method: {payment_method}, Transaction ID: {tid}")
        return jsonify({'success': True, 'message': 'Payment transaction recorded!', 'transaction_id': tid})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# Endpoint for "Today's Revenue" auto-refresh
@app.route('/api/reception/today_revenue')
@role_required(['Reception', 'Admin'])
def api_reception_today_revenue():
    try:
        cond_pay = get_date_conditions("p.payment_date")
        
        # Fetch today's payments and corresponding categories, excluding Pharmacy
        payments = get_db().query(f"""
            SELECT p.amount_paid, b.item_category, p.remarks
            FROM payments p
            LEFT JOIN bills b ON p.bill_id = b.bill_id
            WHERE {cond_pay['today']}
              AND (b.item_category IS NULL OR b.item_category != 'Pharmacy')
              AND (p.remarks IS NULL OR LOWER(p.remarks) NOT LIKE '%%pharmacy%%')
        """)
        
        consultation = 0.0
        investigation = 0.0
        other = 0.0
        
        for p in payments:
            cat = p.get('item_category')
            remarks = (p.get('remarks') or '').lower()
            amt = float(p.get('amount_paid') or 0)
            
            if cat in ('Consultation', 'Follow-up Consultation', 'Registration') or 'consultation' in remarks:
                consultation += amt
            elif cat == 'Lab' or 'investigation' in remarks:
                investigation += amt
            else:
                other += amt
                
        # Registration discounts today
        reg_cond = get_date_conditions("registration_date")
        reg_disc_res = get_db().query(f"""
            SELECT SUM(consultation_fee * (discount_percent / 100)) AS total
            FROM patients
            WHERE {reg_cond['today']}
        """)
        reg_disc = float(reg_disc_res[0]['total'] or 0) if reg_disc_res and reg_disc_res[0]['total'] is not None else 0.0
        
        # Investigation discounts today
        inv_cond = get_date_conditions("created_at")
        inv_disc_res = get_db().query(f"""
            SELECT SUM(discount) AS total
            FROM investigation_bills
            WHERE {inv_cond['today']}
        """)
        inv_disc = float(inv_disc_res[0]['total'] or 0) if inv_disc_res and inv_disc_res[0]['total'] is not None else 0.0
        
        total_discount = reg_disc + inv_disc
        net_revenue = consultation + investigation + other
        gross_revenue = net_revenue + total_discount
        
        return jsonify({
            'consultation': consultation,
            'investigation': investigation,
            'other': other,
            'discount': total_discount,
            'gross': gross_revenue,
            'net': net_revenue
        })
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Endpoint to fetch standard investigations reference list
@app.route('/api/reception/investigations')
@role_required(['Reception', 'Admin', 'Doctor'])
def get_investigations_list():
    try:
        res = get_db().query("SELECT * FROM investigations_list ORDER BY name ASC")
        return jsonify(res)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# Endpoint to generate/checkout investigation billing
@app.route('/api/reception/add_investigation_bill', methods=['POST'])
@role_required(['Reception'])
def api_reception_add_investigation_bill():
    try:
        data = request.get_json()
        patient_id = data.get('patient_id')
        investigations = data.get('investigations', []) # List of investigation names
        discount_type = data.get('discount_type', 'percent') # 'percent' or 'fixed'
        discount_value = float(data.get('discount_value', 0.0))
        gst_enabled = data.get('gst_enabled', False)
        payment_method = data.get('payment_method', 'Cash')
        payment_status = data.get('payment_status', 'Paid')
        
        patient = get_db().query("SELECT patient_name FROM patients WHERE patient_id = %s", (patient_id,), one=True)
        if not patient:
            return jsonify({'success': False, 'message': 'Patient not found'}), 404
            
        # Calculate subtotal
        subtotal = 0.0
        items_billed = []
        inv_names = []
        for item in investigations:
            if isinstance(item, dict):
                name = item.get('name')
                fee = float(item.get('fee', 0.0))
            else:
                name = item
                inv_info = get_db().query("SELECT default_fee FROM investigations_list WHERE name = %s", (name,), one=True)
                fee = float(inv_info['default_fee']) if inv_info else 0.0
            subtotal += fee
            items_billed.append({'name': name, 'fee': fee})
            inv_names.append(name)
            
        # Calculate discount
        discount_amount = 0.0
        if discount_type == 'percent':
            discount_amount = subtotal * (discount_value / 100.0)
        else:
            discount_amount = discount_value
        discount_amount = min(discount_amount, subtotal)
        
        # Calculate GST
        taxable_amt = subtotal - discount_amount
        gst_amount = taxable_amt * 0.18 if gst_enabled else 0.0
        final_total = taxable_amt + gst_amount
        
        # Receipt sequence
        receipt_num = f"REC-INV-{datetime.datetime.now().strftime('%Y%m%d%H%M%S')}-{random.randint(1000, 9999)}"
        
        # Save invoice record
        inv_bill_id = get_db().query("""
            INSERT INTO investigation_bills (patient_id, subtotal, discount, gst, final_total, payment_status, payment_method, receipt_number, created_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, NOW())
        """, (patient_id, subtotal, discount_amount, gst_amount, final_total, payment_status, payment_method, receipt_num), commit=True)
        
        # Save invoice items
        for item in items_billed:
            get_db().query("""
                INSERT INTO investigation_bill_items (bill_id, investigation_name, fee)
                VALUES (%s, %s, %s)
            """, (inv_bill_id, item['name'], item['fee']), commit=True)
            
        # Record into global bills ledger
        desc = f"Investigations: {', '.join(inv_names)} (Receipt: {receipt_num})"
        ledger_bill_id = get_db().query("""
            INSERT INTO bills (patient_id, item_category, description, amount, created_by, bill_date)
            VALUES (%s, 'Lab', %s, %s, %s, NOW())
        """, (patient_id, desc, final_total, session.get('username', 'reception')), commit=True)
        
        # Record immediate payment if status is 'Paid'
        tid = None
        if payment_status == 'Paid':
            tid = get_db().query("""
                INSERT INTO payments (patient_id, bill_id, amount_paid, payment_method, received_by, remarks, payment_date)
                VALUES (%s, %s, %s, %s, %s, %s, NOW())
            """, (patient_id, ledger_bill_id, final_total, payment_method, session.get('username', 'reception'), f"Paid investigation receipt {receipt_num}"), commit=True)
            
        recalculate_patient_billing(patient_id)
        
        # Mark the latest consultation with investigations for this patient as billed
        try:
            get_db().query("""
                UPDATE consultations
                SET investigation_billed = 1
                WHERE patient_id = %s AND investigation_billed = 0 AND investigation_details != '' AND investigation_details IS NOT NULL
            """, (patient_id,), commit=True)
            notify_reception_update()
        except Exception as ex:
            print("Warning: failed to mark consultation investigations as billed:", ex)
            
        log_action(f"Billed Investigations for {patient_id}", None, f"Receipt: {receipt_num}, Items: {', '.join(inv_names)}, Total: ₹{final_total:.2f}")
        return jsonify({
            'success': True,
            'message': 'Investigation bill generated successfully!',
            'receipt_number': receipt_num,
            'transaction_id': tid,
            'bill_id': inv_bill_id
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# Helper to convert numbers to words (English format)
def number_to_words(number):
    try:
        num = int(round(number))
        if num == 0:
            return "Zero Only"
        
        units = ["", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine", "Ten", 
                 "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen"]
        tens = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"]
        
        words = []
        if num >= 1000:
            words.append(units[num // 1000] + " Thousand")
            num %= 1000
        if num >= 100:
            words.append(units[num // 100] + " Hundred")
            num %= 100
        if num >= 20:
            words.append(tens[num // 10])
            num %= 10
        if num > 0:
            words.append(units[num])
            
        return " ".join(filter(None, words)) + " Only"
    except Exception as e:
        return ""

# Print Receipt HTML view
@app.route('/print_receipt/<int:transaction_id>')
@app.route('/patient/payment_receipt/<int:transaction_id>')
@login_required
def print_payment_receipt(transaction_id):
    payment = get_db().query("SELECT * FROM payments WHERE transaction_id = %s", (transaction_id,), one=True)
    if not payment:
        return "Transaction not found", 404
        
    patient = get_db().query("SELECT * FROM patients WHERE patient_id = %s", (payment['patient_id'],), one=True)
    bill = get_db().query("SELECT * FROM bills WHERE bill_id = %s", (payment['bill_id'],), one=True) if payment['bill_id'] else None
    
    items = []
    subtotal = float(payment['amount_paid'])
    discount = 0.0
    grand_total = float(payment['amount_paid'])
    category = "General"
    billed_by = "reception"
    
    if bill:
        category = bill['item_category']
        billed_by = bill['created_by']
        
        if category == 'Lab':
            import re
            match = re.search(r'REC-INV-\d+-\d+', bill['description'])
            if match:
                receipt_num = match.group(0)
                inv_bill = get_db().query("SELECT * FROM investigation_bills WHERE receipt_number = %s", (receipt_num,), one=True)
                if inv_bill:
                    inv_items = get_db().query("SELECT * FROM investigation_bill_items WHERE bill_id = %s", (inv_bill['bill_id'],))
                    discount = float(inv_bill['discount'])
                    subtotal = float(inv_bill['subtotal'])
                    grand_total = float(inv_bill['final_total'])
                    for item in inv_items:
                        items.append({
                            'description': item['investigation_name'],
                            'qty': 1,
                            'unit_price': float(item['fee']),
                            'discount': 0.0,
                            'total': float(item['fee'])
                        })
            if not items:
                items.append({
                    'description': bill['description'],
                    'qty': 1,
                    'unit_price': float(bill['amount']),
                    'discount': 0.0,
                    'total': float(bill['amount'])
                })
        elif category == 'Pharmacy':
            import re
            bill_number = None
            match_bill = re.search(r'Receipt:\s*(SL-\d+)', bill['description'])
            if match_bill:
                bill_number = match_bill.group(1)
            else:
                match_bill_lazy = re.search(r'(SL-\d+)', bill['description'])
                if match_bill_lazy:
                    bill_number = match_bill_lazy.group(1)
                    
            p_bill = None
            if bill_number:
                p_bill = get_db().query("SELECT * FROM pharmacy_bills WHERE bill_number = %s", (bill_number,), one=True)
                
            if p_bill:
                p_items = get_db().query("SELECT * FROM pharmacy_bill_items WHERE bill_id = %s", (p_bill['bill_id'],))
                
                formatted_items = []
                tax_buckets = {
                    '0%': {'taxable': 0.0, 'cgst': 0.0, 'sgst': 0.0},
                    '5%': {'taxable': 0.0, 'cgst': 0.0, 'sgst': 0.0},
                    '12%': {'taxable': 0.0, 'cgst': 0.0, 'sgst': 0.0},
                    '18%': {'taxable': 0.0, 'cgst': 0.0, 'sgst': 0.0},
                    '28%': {'taxable': 0.0, 'cgst': 0.0, 'sgst': 0.0}
                }
                
                for idx, pi in enumerate(p_items):
                    exp_str = pi['expiry_date']
                    try:
                        dt = datetime.datetime.strptime(pi['expiry_date'], '%Y-%m-%d')
                        exp_str = dt.strftime('%b/%y')
                    except:
                        try:
                            dt = datetime.datetime.strptime(pi['expiry_date'], '%Y-%m')
                            exp_str = dt.strftime('%b/%y')
                        except:
                            pass
                    
                    mfr_str = (pi['manufacturer'] or 'GEN')[:3].upper()
                    
                    formatted_items.append({
                        'sno': idx + 1,
                        'name': pi['medicine_name'],
                        'mfr': mfr_str,
                        'batch': pi['batch_number'],
                        'exp': exp_str,
                        'qty': float(pi['quantity']),
                        'mrp': float(pi['mrp']),
                        'rate': float(pi['taxable_rate']),
                        'discount_percent': float(pi['discount_percent'] or 0.0),
                        'sgst_percent': float(pi['sgst_percent']),
                        'cgst_percent': float(pi['cgst_percent']),
                        'total_amount': float(pi['total_amount'])
                    })
                    
                    gst_pct = float(pi['gst_rate'])
                    bucket_key = None
                    if abs(gst_pct - 0.0) < 0.1: bucket_key = '0%'
                    elif abs(gst_pct - 5.0) < 0.1: bucket_key = '5%'
                    elif abs(gst_pct - 12.0) < 0.1: bucket_key = '12%'
                    elif abs(gst_pct - 18.0) < 0.1: bucket_key = '18%'
                    elif abs(gst_pct - 28.0) < 0.1: bucket_key = '28%'
                    
                    if bucket_key:
                        tax_buckets[bucket_key]['taxable'] += float(pi['taxable_rate']) * float(pi['quantity'])
                        tax_buckets[bucket_key]['cgst'] += float(pi['cgst_amount'])
                        tax_buckets[bucket_key]['sgst'] += float(pi['sgst_amount'])
                
                amt_in_words = number_to_words(float(p_bill['final_total']))
                
                bill_date_str = ""
                try:
                    if isinstance(p_bill['created_at'], str):
                        b_dt = datetime.datetime.strptime(p_bill['created_at'], '%Y-%m-%d %H:%M:%S')
                    else:
                        b_dt = p_bill['created_at']
                    bill_date_str = b_dt.strftime('%d-%b-%y')
                except:
                    bill_date_str = datetime.datetime.now().strftime('%d-%b-%y')
                    
                items_rows_html = ""
                for fit in formatted_items:
                    items_rows_html += f"""
                    <tr>
                        <td style="text-align: center; border-right: 1px solid #000; border-left: 1px solid #000;">{fit['sno']}</td>
                        <td style="border-right: 1px solid #000; padding-left: 5px;">{fit['name']}</td>
                        <td style="text-align: center; border-right: 1px solid #000;">{fit['mfr']}</td>
                        <td style="text-align: center; border-right: 1px solid #000;">{fit['batch']}</td>
                        <td style="text-align: center; border-right: 1px solid #000;">{fit['exp']}</td>
                        <td style="text-align: right; padding-right: 5px; border-right: 1px solid #000;">{fit['qty']:.1f}</td>
                        <td style="text-align: right; padding-right: 5px; border-right: 1px solid #000;">{fit['mrp']:.2f}</td>
                        <td style="text-align: right; padding-right: 5px; border-right: 1px solid #000;">{fit['rate']:.2f}</td>
                        <td style="text-align: right; padding-right: 5px; border-right: 1px solid #000;">{fit['discount_percent']:.1f}</td>
                        <td style="text-align: right; padding-right: 5px; border-right: 1px solid #000;">{fit['sgst_percent']:.2f}</td>
                        <td style="text-align: right; padding-right: 5px; border-right: 1px solid #000;">{fit['cgst_percent']:.2f}</td>
                        <td style="text-align: right; padding-right: 5px; border-right: 1px solid #000;">{fit['total_amount']:.2f}</td>
                    </tr>
                    """
                    
                # Pad out table rows for layout height matching
                pad_rows = max(1, 10 - len(formatted_items))
                for _ in range(pad_rows):
                    items_rows_html += """
                    <tr style="height: 20px;">
                        <td style="border-right: 1px solid #000; border-left: 1px solid #000;"></td>
                        <td style="border-right: 1px solid #000;"></td>
                        <td style="border-right: 1px solid #000;"></td>
                        <td style="border-right: 1px solid #000;"></td>
                        <td style="border-right: 1px solid #000;"></td>
                        <td style="border-right: 1px solid #000;"></td>
                        <td style="border-right: 1px solid #000;"></td>
                        <td style="border-right: 1px solid #000;"></td>
                        <td style="border-right: 1px solid #000;"></td>
                        <td style="border-right: 1px solid #000;"></td>
                        <td style="border-right: 1px solid #000;"></td>
                        <td style="border-right: 1px solid #000;"></td>
                    </tr>
                    """
                    
                taxable_row_html = ""
                cgst_row_html = ""
                sgst_row_html = ""
                for bk in ['0%', '5%', '12%', '18%', '28%']:
                    taxable_row_html += f'<td style="text-align: right; padding: 2px 5px; border: 1px solid #000;">{tax_buckets[bk]["taxable"]:.2f}</td>'
                    cgst_row_html += f'<td style="text-align: right; padding: 2px 5px; border: 1px solid #000;">{tax_buckets[bk]["cgst"]:.2f}</td>'
                    sgst_row_html += f'<td style="text-align: right; padding: 2px 5px; border: 1px solid #000;">{tax_buckets[bk]["sgst"]:.2f}</td>'

                return f"""
                <!DOCTYPE html>
                <html>
                <head>
                    <title>Sagar Pharmacy Invoice - {bill_number}</title>
                    <style>
                        body {{
                            font-family: Arial, sans-serif;
                            color: #000000;
                            margin: 0;
                            padding: 10px;
                            font-size: 11px;
                            background-color: #ffffff;
                        }}
                        .bill-container {{
                            max-width: 820px;
                            margin: 0 auto;
                            border: 1px solid #000000;
                            padding: 10px;
                        }}
                        .shop-header {{
                            text-align: center;
                            border-bottom: 1px solid #000000;
                            padding-bottom: 5px;
                            margin-bottom: 8px;
                        }}
                        .shop-title {{
                            font-size: 18px;
                            font-weight: bold;
                            margin: 0;
                        }}
                        .shop-subtitle {{
                            font-size: 9px;
                            margin: 2px 0 0 0;
                        }}
                        .meta-table {{
                            width: 100%;
                            border-collapse: collapse;
                            margin-bottom: 8px;
                        }}
                        .meta-table td {{
                            padding: 2px 0;
                            vertical-align: top;
                        }}
                        .items-table {{
                            width: 100%;
                            border-collapse: collapse;
                            border-top: 1px solid #000;
                            border-bottom: 1px solid #000;
                            margin-bottom: 8px;
                        }}
                        .items-table th {{
                            border-bottom: 1px solid #000;
                            border-top: 1px solid #000;
                            border-right: 1px solid #000;
                            padding: 5px 2px;
                            font-weight: bold;
                            text-align: center;
                            background-color: #f2f2f2;
                        }}
                        .items-table th:first-child, .items-table td:first-child {{
                            border-left: 1px solid #000;
                        }}
                        .items-table td {{
                            padding: 4px 2px;
                        }}
                        .items-table tr.total-row td {{
                            border-top: 1px solid #000;
                            border-bottom: 1px solid #000;
                            font-weight: bold;
                        }}
                        .tax-summary-table {{
                            width: 100%;
                            border-collapse: collapse;
                        }}
                        .tax-summary-table th, .tax-summary-table td {{
                            border: 1px solid #000;
                            padding: 3px;
                        }}
                        @media print {{
                            body {{
                                padding: 0;
                            }}
                            .bill-container {{
                                border: 1px solid #000;
                            }}
                        }}
                    </style>
                </head>
                <body onload="window.print()">
                    <div class="bill-container">
                        <div class="shop-header">
                            <div class="shop-title">SAGAR PHARMACY</div>
                            <div class="shop-subtitle">#D.NO: 29 - 28/1-16 KOVELAMUDIVARI STREET, SURYARAOPET, VIJAYAWADA - 520002. PH: 0866-2440806, 9502480806</div>
                        </div>
                        
                        <table class="meta-table">
                            <tr>
                                <td style="width: 15%; font-weight: bold;">Dl20b :</td>
                                <td style="width: 35%;">AP/06/03/2017-142466</td>
                                <td style="width: 15%; font-weight: bold;">BILL NO :</td>
                                <td style="width: 35%; font-weight: bold;">{bill_number}</td>
                            </tr>
                            <tr>
                                <td style="font-weight: bold;">DL21b :</td>
                                <td>AP/06/03/2017-142467</td>
                                <td style="font-weight: bold;">BILL DATE :</td>
                                <td>{bill_date_str}</td>
                            </tr>
                            <tr>
                                <td style="font-weight: bold;">GSTIN :</td>
                                <td>37AMCPG5565G1Z1</td>
                                <td style="font-weight: bold;">MODE :</td>
                                <td>{p_bill['payment_method']}</td>
                            </tr>
                            <tr>
                                <td style="font-weight: bold;">State :</td>
                                <td>ANDHRA PRADESH</td>
                                <td style="font-weight: bold;">Cell :</td>
                                <td>{patient['phone1'] or ''}</td>
                            </tr>
                            <tr>
                                <td colspan="4" style="border-top: 1px dashed #000; padding-top: 5px; font-size: 12px;">
                                    <span style="font-weight: bold;">Patient Details :</span> <span style="font-weight: bold; font-size: 13px;">{patient['patient_name'].upper()}</span>
                                </td>
                            </tr>
                        </table>
                        
                        <table class="items-table">
                            <thead>
                                <tr>
                                    <th style="width: 4%; text-align: center;">S.No</th>
                                    <th style="width: 32%; text-align: left; padding-left: 5px;">Description</th>
                                    <th style="width: 6%; text-align: center;">MFR</th>
                                    <th style="width: 10%; text-align: center;">Batch</th>
                                    <th style="width: 8%; text-align: center;">ExpDt.</th>
                                    <th style="width: 6%; text-align: right; padding-right: 5px;">Qty</th>
                                    <th style="width: 8%; text-align: right; padding-right: 5px;">MRP</th>
                                    <th style="width: 8%; text-align: right; padding-right: 5px;">Rate</th>
                                    <th style="width: 5%; text-align: right; padding-right: 5px;">Dis%</th>
                                    <th style="width: 5%; text-align: right; padding-right: 5px;">SGST</th>
                                    <th style="width: 5%; text-align: right; padding-right: 5px;">CGST</th>
                                    <th style="width: 8%; text-align: right; padding-right: 5px;">Amount</th>
                                </tr>
                            </thead>
                            <tbody>
                                {items_rows_html}
                                <tr class="total-row">
                                    <td colspan="5" style="text-align: right; padding-right: 10px; border-left: 1px solid #000;">Total :</td>
                                    <td style="text-align: right; padding-right: 5px; border-right: 1px solid #000;">{sum(f['qty'] for f in formatted_items):.1f}</td>
                                    <td style="border-right: 1px solid #000;"></td>
                                    <td style="text-align: right; padding-right: 5px; border-right: 1px solid #000;">{p_bill['subtotal']:.2f}</td>
                                    <td style="border-right: 1px solid #000;"></td>
                                    <td style="text-align: right; padding-right: 5px; border-right: 1px solid #000;">{p_bill['sgst']:.2f}</td>
                                    <td style="text-align: right; padding-right: 5px; border-right: 1px solid #000;">{p_bill['cgst']:.2f}</td>
                                    <td style="text-align: right; padding-right: 5px; border-right: 1px solid #000;">{p_bill['final_total']:.2f}</td>
                                </tr>
                            </tbody>
                        </table>
                        
                        <table style="width: 100%; border-collapse: collapse;">
                            <tr>
                                <td style="width: 60%; vertical-align: top; padding-right: 15px;">
                                    <table class="tax-summary-table">
                                        <thead>
                                            <tr style="background-color: #f2f2f2;">
                                                <th style="font-weight: bold; text-align: left;">No.of TAXES</th>
                                                <th style="text-align: right; width: 15%;">0%</th>
                                                <th style="text-align: right; width: 15%;">5%</th>
                                                <th style="text-align: right; width: 15%;">12%</th>
                                                <th style="text-align: right; width: 15%;">18%</th>
                                                <th style="text-align: right; width: 15%;">28%</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td style="font-weight: bold;">TAXABLE</td>
                                                {taxable_row_html}
                                            </tr>
                                            <tr>
                                                <td style="font-weight: bold;">CGST</td>
                                                {cgst_row_html}
                                            </tr>
                                            <tr>
                                                <td style="font-weight: bold;">SGST</td>
                                                {sgst_row_html}
                                            </tr>
                                        </tbody>
                                    </table>
                                    
                                    <div style="margin-top: 10px; font-weight: bold; font-size: 11px;">
                                        Rupees {amt_in_words}
                                    </div>
                                    <div style="margin-top: 15px; font-size: 10px; color: #333;">
                                        User Name : <span style="font-weight: bold;">{p_bill['created_by'] or 'pharmacy'}</span><br>
                                        Subject to Vijayawada Jurisdiction Only
                                    </div>
                                </td>
                                
                                <td style="width: 40%; vertical-align: top;">
                                    <table style="width: 100%; border-collapse: collapse; font-size: 12px;">
                                        <tr>
                                            <td style="padding: 4px 0; color: #333;">Total Taxable Amount :</td>
                                            <td style="text-align: right; font-weight: bold; padding: 4px 0;">{p_bill['subtotal']:.2f}</td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 4px 0; color: #333;">Total Discount :</td>
                                            <td style="text-align: right; font-weight: bold; padding: 4px 0;">{p_bill['discount']:.2f}</td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 4px 0; color: #333;">Total CGST Amount :</td>
                                            <td style="text-align: right; font-weight: bold; padding: 4px 0;">{p_bill['cgst']:.2f}</td>
                                        </tr>
                                        <tr>
                                            <td style="padding: 4px 0; color: #333;">Total SGST Amount :</td>
                                            <td style="text-align: right; font-weight: bold; padding: 4px 0;">{p_bill['sgst']:.2f}</td>
                                        </tr>
                                        <tr style="border-top: 1px solid #000; border-bottom: 1px double #000;">
                                            <td style="padding: 6px 0; font-weight: bold; font-size: 13px;">Net Amount :</td>
                                            <td style="text-align: right; font-weight: bold; font-size: 14px; padding: 6px 0;">{p_bill['final_total']:.2f}</td>
                                        </tr>
                                    </table>
                                    <div style="margin-top: 25px; text-align: right; font-weight: bold; padding-right: 10px;">
                                        For SAGAR PHARMACY
                                    </div>
                                </td>
                            </tr>
                        </table>
                    </div>
                </body>
                </html>
                """

            desc = bill['description']
            med_part = desc.replace("Medicines issued:", "").split("(RX-")[0].strip()
            items.append({
                'description': med_part or "Prescribed Medicines",
                'qty': 1,
                'unit_price': float(bill['amount']),
                'discount': 0.0,
                'total': float(bill['amount'])
            })
        else:
            items.append({
                'description': bill['description'],
                'qty': 1,
                'unit_price': float(bill['amount']),
                'discount': 0.0,
                'total': float(bill['amount'])
            })
    else:
        items.append({
            'description': payment['remarks'] or "Account Ledger Payment",
            'qty': 1,
            'unit_price': float(payment['amount_paid']),
            'discount': 0.0,
            'total': float(payment['amount_paid'])
        })
        
    item_rows_html = ""
    for item in items:
        item_rows_html += f"""
        <tr>
            <td style="font-weight: 600;">{item['description']}</td>
            <td style="text-align: center;">{item['qty']}</td>
            <td style="text-align: right;">{item['unit_price']:.2f}</td>
            <td style="text-align: right;">{item['discount']:.2f}</td>
            <td style="text-align: right; font-weight: 600;">{item['total']:.2f}</td>
        </tr>
        """
        
    pay_date = payment['payment_date']
    if isinstance(pay_date, str):
        try:
            date_obj = datetime.datetime.strptime(pay_date, '%Y-%m-%d %H:%M:%S')
            date_time_str = date_obj.strftime('%d-%b-%Y %I:%M %p')
            receipt_no = f"REC-INV-{date_obj.strftime('%Y%m%d')}-{transaction_id:04d}"
        except:
            date_time_str = pay_date
            receipt_no = f"REC-INV-{datetime.datetime.now().strftime('%Y%m%d')}-{transaction_id:04d}"
    else:
        date_time_str = pay_date.strftime('%d-%b-%Y %I:%M %p')
        receipt_no = f"REC-INV-{pay_date.strftime('%Y%m%d')}-{transaction_id:04d}"
        
    return f"""
    <!DOCTYPE html>
    <html>
    <head>
        <title>Payment Receipt - TX-{transaction_id}</title>
        <style>
            @import url('https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700&family=Plus+Jakarta+Sans:wght@400;500;600;700&display=swap');
            body {{
                font-family: 'Plus Jakarta Sans', sans-serif;
                color: #1e293b;
                margin: 0;
                padding: 30px;
                background-color: #ffffff;
                font-size: 14px;
            }}
            .receipt-container {{
                max-width: 800px;
                margin: 0 auto;
                border: 1px solid #e2e8f0;
                padding: 40px;
                border-radius: 8px;
            }}
            .header-table {{
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 20px;
            }}
            .hospital-title {{
                font-family: 'Outfit', sans-serif;
                font-size: 26px;
                font-weight: 700;
                color: #0f766e;
                margin: 0;
                letter-spacing: 0.5px;
            }}
            .hospital-subtitle {{
                font-size: 11px;
                color: #64748b;
                margin: 3px 0 0 0;
                text-transform: uppercase;
                font-weight: 600;
            }}
            .contact-info {{
                text-align: right;
                font-size: 12px;
                color: #475569;
                line-height: 1.5;
            }}
            .divider {{
                border-top: 2px solid #334155;
                margin-bottom: 25px;
            }}
            .doc-title {{
                text-align: center;
                font-family: 'Outfit', sans-serif;
                font-size: 18px;
                font-weight: 700;
                text-decoration: underline;
                letter-spacing: 1px;
                margin-bottom: 30px;
                color: #0f172a;
            }}
            .meta-table {{
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 35px;
            }}
            .meta-table td {{
                padding: 6px 0;
                vertical-align: top;
            }}
            .meta-label {{
                color: #64748b;
                font-weight: 600;
                width: 120px;
            }}
            .meta-value {{
                font-weight: 600;
                color: #0f172a;
            }}
            .items-table {{
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 30px;
            }}
            .items-table th {{
                border-top: 1px solid #94a3b8;
                border-bottom: 1px solid #94a3b8;
                padding: 10px 8px;
                text-align: left;
                font-weight: 700;
                color: #334155;
                font-size: 13px;
            }}
            .items-table td {{
                border-bottom: 1px solid #e2e8f0;
                padding: 12px 8px;
                color: #334155;
            }}
            .totals-table {{
                width: 300px;
                float: right;
                border-collapse: collapse;
                margin-bottom: 40px;
            }}
            .totals-table td {{
                padding: 6px 8px;
            }}
            .grand-total-row td {{
                border-top: 1px solid #94a3b8;
                border-bottom: 1px solid #94a3b8;
                font-weight: 700;
                font-size: 16px;
                color: #0f172a;
                padding: 10px 8px;
            }}
            .footer-note {{
                clear: both;
                text-align: center;
                font-size: 11px;
                color: #94a3b8;
                border-top: 1px dashed #cbd5e1;
                padding-top: 20px;
                margin-top: 50px;
            }}
            @media print {{
                body {{
                    padding: 0;
                    background-color: transparent;
                }}
                .receipt-container {{
                    border: none;
                    padding: 0;
                }}
            }}
        </style>
    </head>
    <body onload="window.print()">
        <div class="receipt-container">
            <table class="header-table">
                <tr>
                    <td style="width: 70px; vertical-align: middle; padding-right: 10px;">
                        <img src="/static/images/logo.jpg" alt="Logo" style="height: 55px; width: 55px; border-radius: 50%; object-fit: cover;">
                    </td>
                    <td style="vertical-align: middle;">
                        <h1 class="hospital-title" style="margin: 0; font-size: 1.6rem; color: #1e3a8a; font-weight: 800;">Sagar ENT</h1>
                        <div class="hospital-subtitle" style="font-size: 0.8rem; color: #4b5563; font-weight: 600;">Head and Neck Superspeciality Center</div>
                    </td>
                    <td class="contact-info" style="text-align: right; font-size: 0.8rem; color: #4b5563;">
                        <strong>Address:</strong> Hospital Main Road, Sagar<br>
                        <strong>Phone:</strong> +91 98765 43210, +91 98765 43211<br>
                        <strong>Email:</strong> info@sagarent.com
                    </td>
                </tr>
            </table>
            
            <div class="divider"></div>
            
            <div class="doc-title">PAYMENT RECEIPT</div>
            
            <table class="meta-table">
                <tr>
                    <td class="meta-label">Patient ID:</td>
                    <td class="meta-value">{patient['patient_id']}</td>
                    <td class="meta-label" style="text-align: right; padding-right: 20px;">Receipt No:</td>
                    <td class="meta-value">{receipt_no}</td>
                </tr>
                <tr>
                    <td class="meta-label">Patient Name:</td>
                    <td class="meta-value">{patient['patient_name']}</td>
                    <td class="meta-label" style="text-align: right; padding-right: 20px;">Date & Time:</td>
                    <td class="meta-value">{date_time_str}</td>
                </tr>
                <tr>
                    <td class="meta-label">Age / Gender:</td>
                    <td class="meta-value">{patient['age']} yrs / {patient['gender']}</td>
                    <td class="meta-label" style="text-align: right; padding-right: 20px;">Bill Category:</td>
                    <td class="meta-value">{category}</td>
                </tr>
                <tr>
                    <td class="meta-label">Phone:</td>
                    <td class="meta-value">{patient['phone1']}</td>
                    <td class="meta-label" style="text-align: right; padding-right: 20px;">Billed By:</td>
                    <td class="meta-value">{billed_by}</td>
                </tr>
            </table>
            
            <table class="items-table">
                <thead>
                    <tr>
                        <th style="width: 50%;">Item Description</th>
                        <th style="text-align: center; width: 10%;">Qty</th>
                        <th style="text-align: right; width: 15%;">Unit Price (₹)</th>
                        <th style="text-align: right; width: 10%;">Discount (₹)</th>
                        <th style="text-align: right; width: 15%;">Total (₹)</th>
                    </tr>
                </thead>
                <tbody>
                    {item_rows_html}
                </tbody>
            </table>
            
            <table class="totals-table">
                <tr>
                    <td style="color: #64748b; font-weight: 600;">Subtotal:</td>
                    <td style="text-align: right; font-weight: 600;">₹{subtotal:.2f}</td>
                </tr>
                <tr>
                    <td style="color: #64748b; font-weight: 600;">Discount:</td>
                    <td style="text-align: right; font-weight: 600;">-₹{discount:.2f}</td>
                </tr>
                <tr class="grand-total-row">
                    <td>Grand Total:</td>
                    <td style="text-align: right;">₹{grand_total:.2f}</td>
                </tr>
                <tr>
                    <td style="color: #64748b; font-weight: 600; padding-top: 15px;">Payment Mode:</td>
                    <td style="text-align: right; font-weight: 700; color: #0f766e; padding-top: 15px;">{payment['payment_method']} (Paid)</td>
                </tr>
            </table>
            
            <div class="footer-note">
                <p>Thank you for choosing Sagar ENT Speciality Center.</p>
                <p>This is a system generated receipt. Signature not required.</p>
            </div>
        </div>
    </body>
    </html>
    """


# ==================================================
# PHARMACY MODULE & API
# ==================================================

@app.route('/pharmacy')
@role_required(['Pharmacy'])
def pharmacy_dashboard():
    return render_template('pharmacy.html')

@app.route('/api/pharmacy/prescriptions')
@role_required(['Pharmacy'])
def api_pharmacy_prescriptions():
    prescriptions = get_db().query("""
        SELECT pr.prescription_id, pr.patient_id, p.patient_name, pr.medicine_name, 
               pr.duration_days, pr.morning, pr.afternoon, pr.night, pr.dispensed, pr.created_at, pr.consultation_id, pr.dispensed_at
        FROM prescriptions pr
        JOIN patients p ON pr.patient_id = p.patient_id
        ORDER BY pr.created_at DESC
    """)
    return jsonify(prescriptions)

@app.route('/api/pharmacy/dispense/<string:prescription_ids>', methods=['POST'])
@role_required(['Pharmacy'])
def api_pharmacy_dispense(prescription_ids):
    try:
        pharmacy_charge = float(request.form.get('pharmacy_charge', 0.00))
        payment_method = request.form.get('payment_method', 'Cash')
        
        id_list = [int(x.strip()) for x in prescription_ids.split(',') if x.strip()]
        if not id_list:
            return jsonify({'success': False, 'message': 'No prescription IDs provided'}), 400
            
        db = get_db()
        placeholders = ','.join(['%s'] * len(id_list))
        prescs = db.query(f"SELECT * FROM prescriptions WHERE prescription_id IN ({placeholders})", tuple(id_list))
        
        if not prescs:
            return jsonify({'success': False, 'message': 'Prescriptions not found'}), 404
            
        patient_id = prescs[0]['patient_id']
        
        # Generate invoice bill number (e.g. SL-2214 style)
        last_p_bill = get_db().query("SELECT MAX(bill_id) as max_id FROM pharmacy_bills", one=True)
        next_id = (last_p_bill['max_id'] or 0) + 1
        bill_number = f"SL-{next_id + 2200}"

        items_deducted = []
        total_taxable = 0.0
        total_cgst = 0.0
        total_sgst = 0.0
        total_mrp_amt = 0.0
        
        medicine_names_dispensed = []

        for presc in prescs:
            med_name = presc['medicine_name']
            medicine_names_dispensed.append(med_name)
            
            # Calculate daily frequency and total quantity to deduct from stock
            daily_freq = (1 if presc['morning'] else 0) + (1 if presc['afternoon'] else 0) + (1 if presc['night'] else 0)
            if daily_freq == 0:
                daily_freq = 1
            total_qty = daily_freq * presc['duration_days']
            
            # Try to find a matching stock name
            match = db.query("SELECT * FROM pharmacy_stock WHERE LOWER(medicine_name) = LOWER(%s) LIMIT 1", (med_name,), one=True)
            if not match:
                match = db.query("SELECT * FROM pharmacy_stock WHERE LOWER(medicine_name) LIKE LOWER(%s) LIMIT 1", (f"%{med_name}%",), one=True)
            if not match:
                import re
                norm_presc = re.sub(r'[^a-zA-Z0-9]', '', med_name).lower()
                stock_items = db.query("SELECT * FROM pharmacy_stock")
                for item in stock_items:
                    norm_stock = re.sub(r'[^a-zA-Z0-9]', '', item['medicine_name']).lower()
                    if norm_stock in norm_presc or norm_presc in norm_stock:
                        match = item
                        break
                        
            items_for_presc_deducted = []
            if match:
                matched_name = match['medicine_name']
                batches = db.query("SELECT * FROM pharmacy_stock WHERE LOWER(medicine_name) = LOWER(%s) ORDER BY expiry_date ASC", (matched_name,))
                
                remaining_needed = total_qty
                for batch in batches:
                    if remaining_needed <= 0:
                        break
                    if batch['stock_quantity'] <= 0:
                        continue
                    
                    deduct = min(remaining_needed, batch['stock_quantity'])
                    new_qty = batch['stock_quantity'] - deduct
                    db.query("UPDATE pharmacy_stock SET stock_quantity = %s WHERE medicine_id = %s", (new_qty, batch['medicine_id']), commit=True)
                    remaining_needed -= deduct

                    # Calculate item level financial fields
                    qty_f = float(deduct)
                    mrp_f = float(batch['sale_price'])
                    gst_f = float(batch['gst_rate'])
                    
                    taxable_rate = round(mrp_f / (1.0 + (gst_f / 100.0)), 2)
                    cgst_pct = gst_f / 2.0
                    sgst_pct = gst_f / 2.0
                    
                    item_taxable = round(taxable_rate * qty_f, 2)
                    item_cgst = round(item_taxable * (cgst_pct / 100.0), 2)
                    item_sgst = round(item_taxable * (sgst_pct / 100.0), 2)
                    item_total = round(mrp_f * qty_f, 2)
                    
                    item_details = {
                        'medicine_name': matched_name,
                        'manufacturer': batch['supplier_company'],
                        'batch_number': batch['batch_number'],
                        'expiry_date': batch['expiry_date'],
                        'quantity': qty_f,
                        'mrp': mrp_f,
                        'taxable_rate': taxable_rate,
                        'gst_rate': gst_f,
                        'cgst_percent': cgst_pct,
                        'sgst_percent': sgst_pct,
                        'cgst_amount': item_cgst,
                        'sgst_amount': item_sgst,
                        'total_amount': item_total
                    }
                    items_deducted.append(item_details)
                    items_for_presc_deducted.append(item_details)
                    
                    total_taxable += item_taxable
                    total_cgst += item_cgst
                    total_sgst += item_sgst
                    total_mrp_amt += item_total
            
            # Fallback if no items were deducted
            if not items_for_presc_deducted:
                qty_f = float(total_qty)
                unit_price = 10.00
                gst_f = 12.0
                taxable_rate = round(unit_price, 2)
                cgst_pct = 6.0
                sgst_pct = 6.0
                
                item_taxable = round(taxable_rate * qty_f, 2)
                item_cgst = round(item_taxable * 0.06, 2)
                item_sgst = round(item_taxable * 0.06, 2)
                item_total = round(item_taxable * 1.12, 2)
                
                item_details = {
                    'medicine_name': med_name,
                    'manufacturer': 'GEN',
                    'batch_number': 'B-GEN',
                    'expiry_date': '2028-12-31',
                    'quantity': qty_f,
                    'mrp': unit_price * 1.12,
                    'taxable_rate': taxable_rate,
                    'gst_rate': gst_f,
                    'cgst_percent': cgst_pct,
                    'sgst_percent': sgst_pct,
                    'cgst_amount': item_cgst,
                    'sgst_amount': item_sgst,
                    'total_amount': item_total
                }
                items_deducted.append(item_details)
                
                total_taxable += item_taxable
                total_cgst += item_cgst
                total_sgst += item_sgst
                total_mrp_amt += item_total

        if pharmacy_charge > 0:
            discount_amount = max(0.0, total_mrp_amt - pharmacy_charge)
        else:
            discount_amount = 0.0

        # Mark prescriptions as dispensed
        db.query(
            f"UPDATE prescriptions SET dispensed = 'Yes', dispensed_at = NOW() WHERE prescription_id IN ({placeholders})",
            tuple(id_list),
            commit=True
        )
        
        # Log pharmacy sales bill and immediate payments
        tid = None
        if pharmacy_charge > 0:
            # Save pharmacy bills
            p_bill_id = db.query("""
                INSERT INTO pharmacy_bills (patient_id, subtotal, discount, cgst, sgst, final_total, payment_method, payment_status, bill_number, created_by)
                VALUES (%s, %s, %s, %s, %s, %s, %s, 'Paid', %s, %s)
            """, (patient_id, total_taxable, discount_amount, total_cgst, total_sgst, pharmacy_charge, payment_method, bill_number, session.get('username', 'pharmacy')), commit=True)
            
            # Save pharmacy bill items
            for item in items_deducted:
                db.query("""
                    INSERT INTO pharmacy_bill_items (bill_id, medicine_name, manufacturer, batch_number, expiry_date, quantity, mrp, taxable_rate, gst_rate, cgst_percent, sgst_percent, cgst_amount, sgst_amount, total_amount)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                """, (p_bill_id, item['medicine_name'], item['manufacturer'], item['batch_number'], item['expiry_date'], item['quantity'], item['mrp'], item['taxable_rate'], item['gst_rate'], item['cgst_percent'], item['sgst_percent'], item['cgst_amount'], item['sgst_amount'], item['total_amount']), commit=True)

            meds_str = ", ".join(medicine_names_dispensed)
            bill_id = get_db().query("""
                INSERT INTO bills (patient_id, item_category, description, amount, created_by, bill_date)
                VALUES (%s, 'Pharmacy', %s, %s, %s, NOW())
            """, (patient_id, f"Medicines issued: {meds_str} (Receipt: {bill_number})", pharmacy_charge, session.get('username', 'pharmacy')), commit=True)
            
            tid = get_db().query("""
                INSERT INTO payments (patient_id, bill_id, amount_paid, payment_method, received_by, remarks, payment_date)
                VALUES (%s, %s, %s, %s, %s, 'Pharmacy Counter Payment', NOW())
            """, (patient_id, bill_id, pharmacy_charge, payment_method, session.get('username', 'pharmacy')), commit=True)
            
            recalculate_patient_billing(patient_id)
            
        log_action(f"Dispensed medicines for {patient_id}", None, f"Medicines: {', '.join(medicine_names_dispensed)}, Billed Charge: ₹{pharmacy_charge:.2f}, Method: {payment_method}")
        return jsonify({'success': True, 'message': 'Medicines marked as Issued/Dispensed!', 'transaction_id': tid})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# GET Export Pharmacy Stock template and inventory as CSV
@app.route('/api/pharmacy/export_stock_csv')
@role_required(['Pharmacy', 'Admin'])
def api_pharmacy_export_stock_csv():
    try:
        import csv
        import io
        from flask import make_response
        
        # Query current stock list
        stock = get_db().query("SELECT medicine_name, batch_number, stock_quantity, purchase_price, gst_rate, sale_price, expiry_date, supplier_company FROM pharmacy_stock ORDER BY medicine_name ASC")
        
        output = io.StringIO()
        writer = csv.writer(output)
        
        # Write headers (Quantity is ignored by Current Stock, Quantity to Add maps to Qty)
        writer.writerow([
            'Medicine Name', 'Batch Number', 'Current Stock', 'Quantity to Add',
            'Purchase Price', 'GST Rate', 'Sale Price', 'Expiry Date (YYYY-MM-DD)', 'Supplier Company'
        ])
        
        if stock:
            for item in stock:
                writer.writerow([
                    item['medicine_name'],
                    item['batch_number'],
                    item['stock_quantity'],
                    0,  # Default quantity to add is 0
                    item['purchase_price'],
                    item['gst_rate'],
                    item['sale_price'],
                    item['expiry_date'],
                    item['supplier_company']
                ])
        else:
            # Write a placeholder example if empty
            writer.writerow([
                'Dolo - 650mg', 'B-101', 0, 50, 1.20, 12.00, 2.00, '2028-12-31', 'Sagar Pharmacy Distributors'
            ])
            
        csv_data = output.getvalue()
        output.close()
        
        response = make_response(csv_data)
        response.headers['Content-Disposition'] = 'attachment; filename=pharmacy_stock_inventory.csv'
        response.headers['Content-Type'] = 'text/csv'
        return response
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# GET Pharmacy Stock List
@app.route('/api/pharmacy/stock')
@role_required(['Pharmacy', 'Admin', 'Doctor'])
def api_pharmacy_stock():
    try:
        stock = get_db().query("SELECT * FROM pharmacy_stock ORDER BY medicine_name ASC, expiry_date ASC")
        return jsonify(stock)
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# POST Bulk Upload Stock (CSV, PDF, or Image uploads, or raw CSV text paste)
@app.route('/api/pharmacy/bulk_upload_stock', methods=['POST'])
@role_required(['Pharmacy', 'Admin'])
def api_pharmacy_bulk_upload_stock():
    try:
        import csv
        import io
        import datetime
        import os
        import re
        import pdfplumber
        try:
            import easyocr
        except ImportError:
            easyocr = None
        
        rows = []
        filename = ""
        
        if 'file' in request.files and request.files['file'].filename != '':
            file = request.files['file']
            filename = file.filename
            file_bytes = file.read()
            ext = os.path.splitext(filename)[1].lower()
            
            if ext == '.csv':
                text_data = file_bytes.decode('utf-8', errors='ignore')
                reader = csv.reader(io.StringIO(text_data))
                rows = [r for r in reader if r]
                
            elif ext == '.xlsx':
                import openpyxl
                wb = openpyxl.load_workbook(io.BytesIO(file_bytes), data_only=True)
                sheet = wb.active
                for r in sheet.iter_rows(values_only=True):
                    if r and any(cell is not None for cell in r):
                        rows.append([str(cell if cell is not None else '').strip() for cell in r])
                        
            elif ext == '.pdf':
                with pdfplumber.open(io.BytesIO(file_bytes)) as pdf:
                    for page in pdf.pages:
                        tables = page.extract_tables()
                        if tables:
                            for table in tables:
                                for row in table:
                                    if row and any(row):
                                        rows.append([str(cell or '').strip() for cell in row])
                        else:
                            text = page.extract_text()
                            if text:
                                for line in text.split('\n'):
                                    parts = [p.strip() for p in re.split(r'\t|\s{2,}', line) if p.strip()]
                                    if len(parts) > 1:
                                        rows.append(parts)
                                        
            elif ext in ['.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.webp']:
                if easyocr is None:
                    return jsonify({
                        'success': False,
                        'message': 'Image OCR upload is disabled in this environment due to platform bundle size limits. Please upload CSV or Excel files instead.'
                    }), 400
                try:
                    reader = easyocr.Reader(['en'], gpu=False, download_enabled=True)
                    result = reader.readtext(file_bytes, paragraph=False)
                    if result:
                        # Sort by y_center
                        result_sorted = sorted(result, key=lambda r: (r[0][0][1] + r[0][2][1]) / 2)
                        
                        # Find table bounds
                        all_x = []
                        for bbox, text, conf in result_sorted:
                            all_x.extend([bbox[0][0], bbox[1][0], bbox[2][0], bbox[3][0]])
                        min_x = min(all_x) if all_x else 0
                        max_x = max(all_x) if all_x else 1000
                        W = max(1, max_x - min_x)
                        
                        # Group by y_center
                        rows_dict = {}
                        for bbox, text, conf in result_sorted:
                            y_center = (bbox[0][1] + bbox[2][1]) / 2
                            found_row = None
                            min_y_diff = 15
                            for y_key in rows_dict.keys():
                                diff = abs(y_center - y_key)
                                if diff < min_y_diff:
                                    min_y_diff = diff
                                    found_row = y_key
                            if found_row is not None:
                                rows_dict[found_row].append((bbox, text))
                            else:
                                rows_dict[y_center] = [(bbox, text)]
                                
                        col_starts = [0.0, 0.08, 0.16, 0.32, 0.38, 0.49, 0.56, 0.61, 0.65, 0.75, 0.84, 0.92, 0.96]
                        
                        def classify_x_start(x_val):
                            ratio = (x_val - min_x) / W
                            closest_col = 0
                            min_diff = 999
                            for idx, start_val in enumerate(col_starts):
                                diff = abs(ratio - start_val)
                                if diff < min_diff:
                                    min_diff = diff
                                    closest_col = idx
                            return closest_col
                            
                        for y_key in sorted(rows_dict.keys()):
                            row_bboxes = rows_dict[y_key]
                            row_bboxes_sorted = sorted(row_bboxes, key=lambda item: item[0][0][0])
                            
                            row_data = [""] * 13
                            for bbox, text in row_bboxes_sorted:
                                x_start = bbox[0][0]
                                x_end = bbox[2][0]
                                base_col = classify_x_start(x_start)
                                
                                # Split sequential parts
                                parts = [p.strip() for p in re.split(r'[|/]+', text) if p.strip()]
                                if len(parts) == 1:
                                    ratio_span = (x_end - x_start) / W
                                    if ratio_span > 0.15 and ' ' in text:
                                        words = text.split()
                                        parts = []
                                        current_part = []
                                        for w in words:
                                            if (re.match(r'^[A-Z]{3,}\d+[A-Z]*$', w) or 
                                                re.match(r'^\d{2}/\d{2}$', w) or 
                                                re.match(r'^\d+(\.\d+)?$', w) or 
                                                w.endswith('ML') or w.endswith('S')):
                                                if current_part:
                                                    parts.append(" ".join(current_part))
                                                    current_part = []
                                                parts.append(w)
                                            else:
                                                current_part.append(w)
                                        if current_part:
                                            parts.append(" ".join(current_part))
                                            
                                for offset, part in enumerate(parts):
                                    target_col = base_col + offset
                                    if target_col < 13:
                                        row_data[target_col] = part
                            rows.append(row_data)
                except Exception as e:
                    return jsonify({
                        'success': False, 
                        'message': f"Image OCR extraction failed: {e}. Please ensure you have internet access on the first run to download the OCR model, or upload as CSV/PDF."
                    }), 500
            else:
                return jsonify({'success': False, 'message': 'Unsupported file format. Please upload CSV, Excel (.xlsx), PDF, or Image.'}), 400
                
        elif 'csv_text' in request.form:
            csv_text = request.form['csv_text']
            if csv_text.strip():
                delimiter = ','
                lines = [line.strip() for line in csv_text.split('\n') if line.strip()]
                if lines:
                    if '\t' in lines[0]:
                        delimiter = '\t'
                    elif ';' in lines[0]:
                        delimiter = ';'
                reader = csv.reader(io.StringIO(csv_text), delimiter=delimiter)
                rows = [r for r in reader if r]
                
        if not rows:
            return jsonify({'success': False, 'message': 'No structured stock data found in input.'}), 400
            
        headers = [h.strip().lower() for h in rows[0]]
        
        has_headers = False
        name_idx = 0
        batch_idx = -1
        exp_idx = -1
        purch_idx = -1
        gst_idx = -1
        rate_idx = -1
        qty_idx = -1
        sup_idx = -1
        
        # Extended invoice column indexes
        mfg_idx = -1
        hsn_idx = -1
        pack_idx = -1
        free_idx = -1
        amount_idx = -1
        discount_idx = -1
        
        # Check if 'mrp' or 'm.r.p' is in headers to distinguish 'rate'
        has_mrp_header = any('mrp' in h or 'm.r.p' in h for h in headers)
        
        for idx, cell in enumerate(headers):
            c_clean = cell.lower().strip()
            if any(term in c_clean for term in ['mfg', 'manufacturer', 'supplier', 'supplier company', 'supplier_company', 'company', 'vendor']):
                mfg_idx = idx
                sup_idx = idx
                has_headers = True
            elif any(term in c_clean for term in ['hsn', 'hsn code', 'hsn_code']):
                hsn_idx = idx
                has_headers = True
            elif any(term in c_clean for term in ['product name', 'product_name', 'item name', 'medicine name', 'item_name', 'medicine_name', 'name']):
                name_idx = idx
                has_headers = True
            elif any(term in c_clean for term in ['pack', 'packaging', 'packing']):
                pack_idx = idx
                has_headers = True
            elif any(term in c_clean for term in ['batch', 'batch number', 'batch_number', 'batch no', 'batch_no']):
                batch_idx = idx
                has_headers = True
            elif any(term in c_clean for term in ['exp', 'expiry date', 'expiry_date', 'exp date', 'exp_date', 'expiry']):
                exp_idx = idx
                has_headers = True
            elif any(term in c_clean for term in ['qty', 'quantity', 'stock quantity', 'stock_quantity', 'quant']):
                qty_idx = idx
                has_headers = True
            elif any(term in c_clean for term in ['free', 'free qty', 'free_qty', 'free quantity', 'free_quantity']):
                free_idx = idx
                has_headers = True
            elif c_clean == 'rate':
                if has_mrp_header:
                    purch_idx = idx
                else:
                    rate_idx = idx
                has_headers = True
            elif any(term in c_clean for term in ['purchase rate', 'purchase_rate', 'p rate', 'p_rate', 'purchase price', 'purchase_price', 'purchase']):
                purch_idx = idx
                has_headers = True
            elif any(term in c_clean for term in ['amount', 'purchase amount', 'purchase_amount', 'total amount', 'total_amount']):
                amount_idx = idx
                has_headers = True
            elif any(term in c_clean for term in ['m.r.p', 'mrp', 'sale price', 'selling price', 'sale_price', 'selling_price', 's rate', 's_rate', 'value']):
                rate_idx = idx
                has_headers = True
            elif any(term in c_clean for term in ['gst%', 'gst %', 'gst rate', 'gst_rate', 'gst']):
                gst_idx = idx
                has_headers = True
            elif any(term in c_clean for term in ['di', 'dis%', 'discount%', 'discount', 'disc%']):
                discount_idx = idx
                has_headers = True

        if has_headers:
            data_rows = rows[1:]
        else:
            data_rows = rows
            name_idx = 0
            qty_idx = 1 if len(rows[0]) > 1 else -1
            rate_idx = 2 if len(rows[0]) > 2 else -1
            
            for col_idx, cell_val in enumerate(rows[0]):
                val_clean = cell_val.strip()
                if col_idx == 0:
                    continue
                if re.search(r'\d{2,4}[-/]\d{2}[-/]\d{2,4}', val_clean) or any(m in val_clean.lower() for m in ['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec']):
                    exp_idx = col_idx
                elif val_clean.isdigit():
                    qty_idx = col_idx
                else:
                    try:
                        float(val_clean.replace(',', ''))
                        if rate_idx == -1 or rate_idx == 1:
                            rate_idx = col_idx
                        else:
                            purch_idx = col_idx
                    except ValueError:
                        if any(char.isdigit() for char in val_clean) and len(val_clean) < 15:
                            batch_idx = col_idx
                        else:
                            sup_idx = col_idx
                            
        def validate_field(field_name, value):
            val = str(value).strip()
            if not val:
                return "warning", "Field is missing - please fill in."
                
            status = "valid"
            msg = ""
            
            if field_name == 'medicine_name':
                if val.lower() in ['item name', 'medicine name', 'item_name', 'name', 'item']:
                    status = "warning"
                    msg = "Medicine name is required or matches header."
                    
            elif field_name == 'batch_number':
                if val == 'B-GEN':
                    status = "warning"
                    msg = "Batch number missing or defaulted."
                    
            elif field_name == 'stock_quantity':
                try:
                    qty = int(float(val.replace(',', '').strip()))
                    if qty <= 0:
                        status = "warning"
                        msg = "Quantity should be greater than zero."
                except:
                    status = "warning"
                    msg = "Invalid quantity format."
                    
            elif field_name in ['purchase_price', 'sale_price']:
                try:
                    price = float(val.replace('₹', '').replace(',', '').strip())
                    if price <= 0.0:
                        status = "warning"
                        msg = "Price/rate should be greater than zero."
                except:
                    status = "warning"
                    msg = "Invalid numeric price format."
                    
            elif field_name == 'gst_rate':
                try:
                    rate = float(val.replace('%', '').strip())
                    if rate not in [5.0, 12.0, 18.0, 28.0, 0.0]:
                        status = "warning"
                        msg = f"Non-standard GST rate ({rate}%)."
                except:
                    status = "warning"
                    msg = "Invalid GST format."
                    
            elif field_name == 'expiry_date':
                matched = False
                for fmt in ('%Y-%m-%d', '%d-%m-%Y', '%d/%m/%Y', '%m/%d/%Y', '%b/%y', '%B/%Y', '%m/%y'):
                    try:
                        dt = datetime.datetime.strptime(val, fmt)
                        if dt.date() < datetime.date.today():
                            status = "warning"
                            msg = "Expiry date is in the past."
                        matched = True
                        break
                    except ValueError:
                        pass
                if not matched:
                    status = "warning"
                    msg = "Invalid expiry date format."
                    
            elif field_name == 'supplier_company':
                if val == "Sagar Pharmacy Distributors":
                    status = "warning"
                    msg = "Supplier company missing or defaulted."
                    
            return status, msg

        parsed_rows = []
        for row in data_rows:
            if not row or len(row) <= name_idx:
                continue
                
            raw_name = row[name_idx].strip()
            if not raw_name:
                continue
                
            raw_mfg = row[mfg_idx].strip() if mfg_idx >= 0 and mfg_idx < len(row) else ""
            raw_hsn = row[hsn_idx].strip() if hsn_idx >= 0 and hsn_idx < len(row) else ""
            raw_pack = row[pack_idx].strip() if pack_idx >= 0 and pack_idx < len(row) else ""
            raw_batch = row[batch_idx].strip() if batch_idx >= 0 and batch_idx < len(row) else ""
            raw_exp = row[exp_idx].strip() if exp_idx >= 0 and exp_idx < len(row) else ""
            raw_qty = row[qty_idx].strip() if qty_idx >= 0 and qty_idx < len(row) else ""
            raw_free = row[free_idx].strip() if free_idx >= 0 and free_idx < len(row) else ""
            raw_purch_rate = row[purch_idx].strip() if purch_idx >= 0 and purch_idx < len(row) else ""
            raw_amount = row[amount_idx].strip() if amount_idx >= 0 and amount_idx < len(row) else ""
            raw_mrp = row[rate_idx].strip() if rate_idx >= 0 and rate_idx < len(row) else ""
            raw_gst = row[gst_idx].strip() if gst_idx >= 0 and gst_idx < len(row) else ""
            raw_discount = row[discount_idx].strip() if discount_idx >= 0 and discount_idx < len(row) else ""
            
            # Formatting and fallback logic
            mfg = raw_mfg if raw_mfg else "GEN"
            hsn = raw_hsn if raw_hsn else ""
            pack = raw_pack if raw_pack else ""
            batch = raw_batch if raw_batch else "B-GEN"
            
            qty = 0.0
            if raw_qty:
                try:
                    qty = float(raw_qty.replace(',', '').strip())
                except:
                    qty = raw_qty
                    
            free = 0.0
            if raw_free:
                try:
                    free = float(raw_free.replace(',', '').strip())
                except:
                    free = raw_free
                    
            rate = 0.0
            if raw_purch_rate:
                try:
                    rate = float(raw_purch_rate.replace('₹', '').replace(',', '').strip())
                except:
                    rate = raw_purch_rate
                    
            amount = 0.0
            if raw_amount:
                try:
                    amount = float(raw_amount.replace('₹', '').replace(',', '').strip())
                except:
                    amount = raw_amount
            elif rate != "" and qty != "":
                try:
                    amount = round(float(rate) * float(qty), 2)
                except:
                    pass
                    
            mrp = 0.0
            if raw_mrp:
                try:
                    mrp = float(raw_mrp.replace('₹', '').replace(',', '').strip())
                except:
                    mrp = raw_mrp
                    
            gst = 12.0
            if raw_gst:
                try:
                    gst = float(raw_gst.replace('%', '').strip())
                except:
                    gst = raw_gst
                    
            discount = 0.0
            if raw_discount:
                try:
                    discount = float(raw_discount.replace('%', '').strip())
                except:
                    discount = raw_discount
                    
            exp = ""
            if raw_exp:
                for fmt in ('%Y-%m-%d', '%d-%m-%Y', '%d/%m/%Y', '%m/%d/%Y', '%b/%y', '%B/%Y', '%m/%y', '%m/%d/%y', '%d/%m/%y'):
                    try:
                        dt = datetime.datetime.strptime(raw_exp.strip(), fmt)
                        exp = dt.strftime('%Y-%m-%d')
                        break
                    except ValueError:
                        pass
                if not exp:
                    exp = raw_exp
            
            name_status, name_msg = validate_field('medicine_name', raw_name)
            qty_status, qty_msg = validate_field('stock_quantity', qty)
            rate_status, rate_msg = validate_field('purchase_price', rate)
            mrp_status, mrp_msg = validate_field('sale_price', mrp)
            gst_status, gst_msg = validate_field('gst_rate', gst)
            exp_status, exp_msg = validate_field('expiry_date', exp)
            batch_status, batch_msg = validate_field('batch_number', batch)
            mfg_status, mfg_msg = validate_field('supplier_company', mfg)
            
            parsed_rows.append({
                'supplier_company': {'value': mfg, 'status': mfg_status, 'msg': mfg_msg},
                'hsn': {'value': hsn, 'status': 'valid', 'msg': ''},
                'medicine_name': {'value': raw_name, 'status': name_status, 'msg': name_msg},
                'pack': {'value': pack, 'status': 'valid', 'msg': ''},
                'batch_number': {'value': batch, 'status': batch_status, 'msg': batch_msg},
                'expiry_date': {'value': exp, 'status': exp_status, 'msg': exp_msg},
                'stock_quantity': {'value': qty, 'status': qty_status, 'msg': qty_msg},
                'free_quantity': {'value': free, 'status': 'valid', 'msg': ''},
                'purchase_rate': {'value': rate, 'status': rate_status, 'msg': rate_msg},
                'purchase_price': {'value': rate, 'status': rate_status, 'msg': rate_msg},
                'purchase_amount': {'value': amount, 'status': 'valid', 'msg': ''},
                'sale_price': {'value': mrp, 'status': mrp_status, 'msg': mrp_msg},
                'gst_rate': {'value': gst, 'status': gst_status, 'msg': gst_msg},
                'discount_percent': {'value': discount, 'status': 'valid', 'msg': ''}
            })
            
        return jsonify({
            'success': True,
            'rows': parsed_rows
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# POST Finalize Bulk Import
@app.route('/api/pharmacy/finalize_bulk_import', methods=['POST'])
@role_required(['Pharmacy', 'Admin'])
def api_pharmacy_finalize_bulk_import():
    try:
        import json
        data = request.get_json()
        if not data or 'rows' not in data:
            return jsonify({'success': False, 'message': 'Invalid payload.'}), 400
            
        rows = data['rows']
        inserted = 0
        updated = 0
        db = get_db()
        
        for r in rows:
            med_name = r.get('medicine_name', '').strip()
            if not med_name:
                continue
                
            batch_number = r.get('batch_number', '').strip()
            if not batch_number:
                batch_number = 'B-GEN'
                
            try:
                qty = int(float(str(r.get('stock_quantity', 0)).replace(',', '').strip()))
            except:
                qty = 0
                
            try:
                free_qty = int(float(str(r.get('free_quantity', 0)).replace(',', '').strip()))
            except:
                free_qty = 0
                
            total_qty = qty + free_qty
                
            try:
                sale_price = float(str(r.get('sale_price', 0.00)).replace('₹', '').replace(',', '').strip())
            except:
                sale_price = 0.00
                
            purchase_price = None
            if 'purchase_rate' in r and str(r['purchase_rate']).strip() not in ('', '0', '0.0', '0.00', '0.000'):
                try:
                    purchase_price = float(str(r['purchase_rate']).replace('₹', '').replace(',', '').strip())
                except:
                    pass
            if purchase_price is None:
                try:
                    purchase_price = float(str(r.get('purchase_price', 0.00)).replace('₹', '').replace(',', '').strip())
                except:
                    purchase_price = round(sale_price * 0.70, 2)
                
            try:
                gst_rate = float(str(r.get('gst_rate', 12.00)).replace('%', '').strip())
            except:
                gst_rate = 12.00
                
            expiry_date = r.get('expiry_date', '').strip()
            if not expiry_date:
                import datetime
                expiry_date = (datetime.date.today() + datetime.timedelta(days=730)).strftime('%Y-%m-%d')
                
            supplier_company = r.get('supplier_company', '').strip()
            if not supplier_company:
                supplier_company = 'Sagar Pharmacy Distributors'
                
            existing = db.query("SELECT * FROM pharmacy_stock WHERE LOWER(medicine_name) = LOWER(%s) AND LOWER(batch_number) = LOWER(%s)", (med_name, batch_number), one=True)
            if existing:
                new_qty = existing['stock_quantity'] + total_qty
                db.query("""
                    UPDATE pharmacy_stock 
                    SET purchase_price = %s, gst_rate = %s, sale_price = %s, expiry_date = %s, stock_quantity = %s, supplier_company = %s
                    WHERE medicine_id = %s
                """, (purchase_price, gst_rate, sale_price, expiry_date, new_qty, supplier_company, existing['medicine_id']), commit=True)
                updated += 1
            else:
                db.query("""
                    INSERT INTO pharmacy_stock (medicine_name, batch_number, purchase_price, gst_rate, sale_price, expiry_date, stock_quantity, supplier_company)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                """, (med_name, batch_number, purchase_price, gst_rate, sale_price, expiry_date, total_qty, supplier_company), commit=True)
                inserted += 1
                
        return jsonify({
            'success': True,
            'message': f'Bulk stock ingestion complete! Inserted {inserted} new items, updated {updated} existing items.'
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# Estimate prescription cost
@app.route('/api/pharmacy/estimate_price/<string:prescription_ids>')
@role_required(['Pharmacy'])
def api_pharmacy_estimate_price(prescription_ids):
    try:
        id_list = [int(x.strip()) for x in prescription_ids.split(',') if x.strip()]
        if not id_list:
            return jsonify({'success': False, 'message': 'No prescription IDs provided'}), 400
            
        db = get_db()
        placeholders = ','.join(['%s'] * len(id_list))
        prescs = db.query(f"SELECT * FROM prescriptions WHERE prescription_id IN ({placeholders})", tuple(id_list))
        
        if not prescs:
            return jsonify({'success': False, 'message': 'Prescriptions not found'}), 404
            
        items = []
        overall_grand_total = 0.0
        
        for presc in prescs:
            med_name = presc['medicine_name']
            duration = presc['duration_days']
            
            daily_freq = (1 if presc['morning'] else 0) + (1 if presc['afternoon'] else 0) + (1 if presc['night'] else 0)
            if daily_freq == 0:
                daily_freq = 1
                
            total_qty = daily_freq * duration
            
            # Find matching stock item
            match = db.query("SELECT * FROM pharmacy_stock WHERE LOWER(medicine_name) = LOWER(%s) LIMIT 1", (med_name,), one=True)
            if not match:
                match = db.query("SELECT * FROM pharmacy_stock WHERE LOWER(medicine_name) LIKE LOWER(%s) LIMIT 1", (f"%{med_name}%",), one=True)
            if not match:
                import re
                norm_presc = re.sub(r'[^a-zA-Z0-9]', '', med_name).lower()
                stock_items = db.query("SELECT * FROM pharmacy_stock")
                for item in stock_items:
                    norm_stock = re.sub(r'[^a-zA-Z0-9]', '', item['medicine_name']).lower()
                    if norm_stock in norm_presc or norm_presc in norm_stock:
                        match = item
                        break
                        
            unit_price = 10.00
            gst_rate = 12.00
            stock_qty = 0
            matched_name = med_name
            supplier = "Sagar Pharmacy Distributors"
            is_matched = False
            
            if match:
                matched_name = match['medicine_name']
                is_matched = True
                
                qty_res = db.query("SELECT SUM(stock_quantity) as total FROM pharmacy_stock WHERE LOWER(medicine_name) = LOWER(%s)", (matched_name,), one=True)
                stock_qty = int(qty_res['total']) if qty_res and qty_res['total'] is not None else 0
                
                batch = db.query("""
                    SELECT sale_price, gst_rate, supplier_company 
                    FROM pharmacy_stock 
                    WHERE LOWER(medicine_name) = LOWER(%s) AND stock_quantity > 0 
                    ORDER BY expiry_date ASC LIMIT 1
                """, (matched_name,), one=True)
                if not batch:
                    batch = db.query("""
                        SELECT sale_price, gst_rate, supplier_company 
                        FROM pharmacy_stock 
                        WHERE LOWER(medicine_name) = LOWER(%s) 
                        ORDER BY expiry_date ASC LIMIT 1
                    """, (matched_name,), one=True)
                    
                if batch:
                    unit_price = float(batch['sale_price'])
                    gst_rate = float(batch['gst_rate'])
                    supplier = batch['supplier_company']
                
            subtotal = round(total_qty * unit_price, 2)
            gst_amount = round(subtotal * (gst_rate / 100.0), 2)
            grand_total = round(subtotal + gst_amount, 2)
            
            is_sufficient = stock_qty >= total_qty
            
            items.append({
                'prescription_id': presc['prescription_id'],
                'prescribed_name': med_name,
                'matched_name': matched_name,
                'matched': is_matched,
                'daily_frequency': daily_freq,
                'duration_days': duration,
                'total_qty': total_qty,
                'unit_price': unit_price,
                'gst_rate': gst_rate,
                'gst_amount': gst_amount,
                'subtotal': subtotal,
                'grand_total': grand_total,
                'stock_quantity': stock_qty,
                'is_sufficient': is_sufficient,
                'supplier_company': supplier
            })
            overall_grand_total += grand_total
            
        response_data = {
            'success': True,
            'items': items,
            'grand_total': round(overall_grand_total, 2)
        }
        if len(items) == 1:
            response_data.update(items[0])
            
        return jsonify(response_data)
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# Delete individual stock item
@app.route('/api/pharmacy/delete_stock/<int:medicine_id>', methods=['POST'])
@role_required(['Pharmacy', 'Admin'])
def api_pharmacy_delete_stock(medicine_id):
    try:
        get_db().query("DELETE FROM pharmacy_stock WHERE medicine_id = %s", (medicine_id,), commit=True)
        return jsonify({'success': True, 'message': 'Medicine stock item deleted.'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

# Clear entire pharmacy stock
@app.route('/api/pharmacy/clear_stock', methods=['POST'])
@role_required(['Pharmacy', 'Admin'])
def api_pharmacy_clear_stock():
    try:
        get_db().query("DELETE FROM pharmacy_stock", commit=True)
        return jsonify({'success': True, 'message': 'Pharmacy inventory fully cleared.'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500


# Pharmacy billing report endpoint
@app.route('/api/pharmacy/billing_report')
@role_required(['Pharmacy', 'Admin'])
def api_pharmacy_billing_report():
    try:
        start_date = request.args.get('start_date')
        end_date = request.args.get('end_date')
        
        if not start_date or not end_date:
            return jsonify({'success': False, 'message': 'Missing date range parameters'}), 400
            
        db = get_db()
        start_dt = f"{start_date} 00:00:00"
        end_dt = f"{end_date} 23:59:59"
        
        # 1. Fetch bills in range
        bills = db.query("""
            SELECT pb.*, p.patient_name
            FROM pharmacy_bills pb
            LEFT JOIN patients p ON pb.patient_id = p.patient_id
            WHERE pb.created_at >= %s AND pb.created_at <= %s
            ORDER BY pb.created_at DESC
        """, (start_dt, end_dt))
        
        # 2. Fetch distinct medicines and total quantity sold
        summary_stats = db.query("""
            SELECT 
                COUNT(DISTINCT pbi.medicine_name) as distinct_medicines,
                SUM(pbi.quantity) as total_qty_sold
            FROM pharmacy_bill_items pbi
            JOIN pharmacy_bills pb ON pbi.bill_id = pb.bill_id
            WHERE pb.created_at >= %s AND pb.created_at <= %s
        """, (start_dt, end_dt), one=True)
        
        distinct_medicines = summary_stats['distinct_medicines'] if summary_stats and summary_stats['distinct_medicines'] is not None else 0
        total_qty_sold = summary_stats['total_qty_sold'] if summary_stats and summary_stats['total_qty_sold'] is not None else 0.0
        
        total_billing = 0.0
        total_bills = len(bills)
        total_discounts = 0.0
        total_tax = 0.0
        
        payment_methods = {}
        
        if bills:
            bill_ids = [b['bill_id'] for b in bills]
            placeholders = ','.join(['%s'] * len(bill_ids))
            all_items = db.query(f"""
                SELECT bill_id, medicine_name, quantity, total_amount
                FROM pharmacy_bill_items
                WHERE bill_id IN ({placeholders})
            """, tuple(bill_ids))
            
            items_by_bill = {}
            for item in all_items:
                b_id = item['bill_id']
                if b_id not in items_by_bill:
                    items_by_bill[b_id] = []
                items_by_bill[b_id].append(item)
                
            for b in bills:
                total_billing += float(b['final_total'] or 0.0)
                total_discounts += float(b['discount'] or 0.0)
                total_tax += float(b['cgst'] or 0.0) + float(b['sgst'] or 0.0)
                
                pay_method = b['payment_method'] or 'Cash'
                if pay_method not in payment_methods:
                    payment_methods[pay_method] = {'count': 0, 'total': 0.0}
                payment_methods[pay_method]['count'] += 1
                payment_methods[pay_method]['total'] += float(b['final_total'] or 0.0)
                
                b['items'] = items_by_bill.get(b['bill_id'], [])
                
                # Fetch matching payment transaction_id for receipt printing
                pay_match = db.query("""
                    SELECT pay.transaction_id 
                    FROM payments pay 
                    JOIN bills b ON pay.bill_id = b.bill_id 
                    WHERE b.item_category = 'Pharmacy' AND b.patient_id = %s AND b.description LIKE %s 
                    LIMIT 1
                """, (b['patient_id'], f"%{b['bill_number']}%"), one=True)
                b['transaction_id'] = pay_match['transaction_id'] if pay_match else None
        else:
            payment_methods = {}
            
        return jsonify({
            'success': True,
            'summary': {
                'total_billing': round(total_billing, 2),
                'total_bills': total_bills,
                'distinct_medicines': distinct_medicines,
                'total_qty_sold': round(total_qty_sold, 2),
                'total_discounts': round(total_discounts, 2),
                'total_tax': round(total_tax, 2)
            },
            'payment_method_breakdown': payment_methods,
            'bills': bills
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500



# ==================================================
# PATIENT CLINICAL HISTORY CUSTOM SECTIONS REST APIS
# ==================================================
@app.route('/api/doctor/custom_sections')
@role_required(['Doctor', 'Admin'])
def api_doctor_get_custom_sections():
    patient_id = request.args.get('patient_id')
    consultation_id = request.args.get('consultation_id')
    if not patient_id:
        return jsonify({'success': False, 'message': 'Missing patient_id'}), 400
        
    db = get_db()
    if consultation_id and consultation_id.strip() and consultation_id != 'undefined':
        sections = db.query("""
            SELECT * FROM patient_custom_sections 
            WHERE patient_id = %s AND consultation_id = %s AND is_deleted = 0 
            ORDER BY display_order ASC
        """, (patient_id, int(consultation_id)))
    else:
        sections = db.query("""
            SELECT * FROM patient_custom_sections 
            WHERE patient_id = %s AND (consultation_id IS NULL OR consultation_id = 0) AND is_deleted = 0 
            ORDER BY display_order ASC
        """, (patient_id,))
        
    return jsonify({'success': True, 'sections': sections})

@app.route('/api/doctor/custom_sections/create', methods=['POST'])
@role_required(['Doctor', 'Admin'])
def api_doctor_create_custom_section():
    try:
        patient_id = request.form.get('patient_id')
        consultation_id = request.form.get('consultation_id')
        title = request.form.get('title')
        content = request.form.get('content', '')
        created_by = session.get('username', 'doctor')
        
        if not patient_id or not title:
            return jsonify({'success': False, 'message': 'Missing required fields'}), 400
            
        db = get_db()
        # Get next display order
        if consultation_id and consultation_id.strip() and consultation_id != 'undefined':
            order_row = db.query("""
                SELECT MAX(display_order) as max_order 
                FROM patient_custom_sections 
                WHERE patient_id = %s AND consultation_id = %s
            """, (patient_id, int(consultation_id)), one=True)
        else:
            order_row = db.query("""
                SELECT MAX(display_order) as max_order 
                FROM patient_custom_sections 
                WHERE patient_id = %s AND (consultation_id IS NULL OR consultation_id = 0)
            """, (patient_id,), one=True)
            
        max_order = order_row['max_order'] if order_row and order_row['max_order'] is not None else -1
        next_order = max_order + 1
        
        c_id = int(consultation_id) if (consultation_id and consultation_id.strip() and consultation_id != 'undefined') else None
        
        section_id = db.query("""
            INSERT INTO patient_custom_sections 
            (patient_id, consultation_id, section_title, section_content, display_order, created_by)
            VALUES (%s, %s, %s, %s, %s, %s)
        """, (patient_id, c_id, title, content, next_order, created_by), commit=True)
        
        log_action(f"Created custom section: {title}", None, None)
        
        return jsonify({
            'success': True, 
            'section': {
                'id': section_id,
                'patient_id': patient_id,
                'consultation_id': c_id,
                'section_title': title,
                'section_content': content,
                'display_order': next_order,
                'is_deleted': 0,
                'is_important': 0,
                'updated_at': datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            }
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/doctor/custom_sections/update', methods=['POST'])
@role_required(['Doctor', 'Admin'])
def api_doctor_update_custom_section():
    try:
        section_id = request.form.get('section_id')
        if not section_id:
            return jsonify({'success': False, 'message': 'Missing section_id'}), 400
            
        title = request.form.get('title')
        content = request.form.get('content')
        is_important = request.form.get('is_important')
        is_deleted = request.form.get('is_deleted')
        
        db = get_db()
        current = db.query("SELECT * FROM patient_custom_sections WHERE id = %s", (int(section_id),), one=True)
        if not current:
            return jsonify({'success': False, 'message': 'Section not found'}), 404
            
        fields = []
        args = []
        
        if title is not None:
            fields.append("section_title = %s")
            args.append(title)
        if content is not None:
            fields.append("section_content = %s")
            args.append(content)
        if is_important is not None:
            fields.append("is_important = %s")
            args.append(int(is_important))
        if is_deleted is not None:
            fields.append("is_deleted = %s")
            args.append(int(is_deleted))
            
        fields.append("updated_at = datetime('now', 'localtime')")
        args.append(int(section_id))
        
        sql = f"UPDATE patient_custom_sections SET {', '.join(fields)} WHERE id = %s"
        db.query(sql, tuple(args), commit=True)
        
        updated = db.query("SELECT * FROM patient_custom_sections WHERE id = %s", (int(section_id),), one=True)
        log_action(f"Updated custom section {section_id}", None, None)
        
        return jsonify({'success': True, 'section': updated})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/doctor/custom_sections/duplicate', methods=['POST'])
@role_required(['Doctor', 'Admin'])
def api_doctor_duplicate_custom_section():
    try:
        section_id = request.form.get('section_id')
        if not section_id:
            return jsonify({'success': False, 'message': 'Missing section_id'}), 400
            
        db = get_db()
        current = db.query("SELECT * FROM patient_custom_sections WHERE id = %s", (int(section_id),), one=True)
        if not current:
            return jsonify({'success': False, 'message': 'Section not found'}), 404
            
        c_id = current['consultation_id']
        p_id = current['patient_id']
        
        if c_id:
            order_row = db.query("""
                SELECT MAX(display_order) as max_order 
                FROM patient_custom_sections 
                WHERE patient_id = %s AND consultation_id = %s
            """, (p_id, c_id), one=True)
        else:
            order_row = db.query("""
                SELECT MAX(display_order) as max_order 
                FROM patient_custom_sections 
                WHERE patient_id = %s AND (consultation_id IS NULL OR consultation_id = 0)
            """, (p_id,), one=True)
            
        max_order = order_row['max_order'] if order_row and order_row['max_order'] is not None else current['display_order']
        next_order = max_order + 1
        
        dup_title = f"{current['section_title']} (Copy)"
        created_by = session.get('username', 'doctor')
        
        new_id = db.query("""
            INSERT INTO patient_custom_sections 
            (patient_id, consultation_id, section_title, section_content, display_order, created_by, is_important)
            VALUES (%s, %s, %s, %s, %s, %s, %s)
        """, (p_id, c_id, dup_title, current['section_content'], next_order, created_by, current['is_important']), commit=True)
        
        new_row = db.query("SELECT * FROM patient_custom_sections WHERE id = %s", (new_id,), one=True)
        log_action(f"Duplicated custom section {section_id}", None, None)
        
        return jsonify({'success': True, 'section': new_row})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/doctor/custom_sections/reorder', methods=['POST'])
@role_required(['Doctor', 'Admin'])
def api_doctor_reorder_custom_sections():
    try:
        payload = request.json
        if not payload or 'order' not in payload:
            return jsonify({'success': False, 'message': 'Missing order list'}), 400
            
        order_list = payload['order']
        db = get_db()
        for index, s_id in enumerate(order_list):
            db.query("""
                UPDATE patient_custom_sections 
                SET display_order = %s 
                WHERE id = %s
            """, (index, int(s_id)), commit=True)
            
        log_action("Reordered custom sections", None, None)
        return jsonify({'success': True, 'message': 'Order updated successfully'})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

if __name__ == '__main__':
    import os
    env = os.environ.get('FLASK_ENV', 'production')
    if env == 'development':
        print("Starting Flask development server...")
        app.run(debug=True, host='127.0.0.1', port=5000)
    else:
        try:
            from waitress import serve
            print("Starting production WSGI server (Waitress) on http://0.0.0.0:5000 ...")
            print("Access locally via: http://127.0.0.1:5000/ or http://localhost:5000/")
            serve(app, host='0.0.0.0', port=5000)
        except ImportError:
            print("Waitress not installed. Falling back to Flask development server...")
            app.run(debug=True, host='127.0.0.1', port=5000)

