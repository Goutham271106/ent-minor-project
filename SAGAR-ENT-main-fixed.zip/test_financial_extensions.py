import unittest
import os
import json
import datetime
from flask import session
from app import app, get_db, recalculate_patient_billing, log_action

class TestFinancialExtensions(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        db = get_db()
        cls.original_sqlite_path = db.sqlite_path
        cls.test_sqlite_path = os.path.join(os.path.dirname(__file__), "test_financial_db.sqlite")
        db.sqlite_path = cls.test_sqlite_path
        
        # Recreate test database file cleanly
        if os.path.exists(cls.test_sqlite_path):
            try:
                os.remove(cls.test_sqlite_path)
            except:
                pass
        db.init_sqlite()

    @classmethod
    def tearDownClass(cls):
        db = get_db()
        db.sqlite_path = cls.original_sqlite_path
        if os.path.exists(cls.test_sqlite_path):
            try:
                os.remove(cls.test_sqlite_path)
            except:
                pass

    def setUp(self):
        # Configure app for testing
        app.config['TESTING'] = True
        app.config['SECRET_KEY'] = 'test-secret-key'
        self.client = app.test_client()
        
        # Setup session for testing by bypassing login checks or setting session
        with self.client.session_transaction() as sess:
            sess['logged_in'] = True
            sess['username'] = 'admin'
            sess['role'] = 'Admin'

    def tearDown(self):
        pass

    def test_database_seeding(self):
        """Verify standard ENT investigations are seeded"""
        db = get_db()
        res = db.query("SELECT COUNT(*) as count FROM investigations_list")
        self.assertGreater(res[0]['count'], 0)
        
        # Check specific seeded investigations
        pta = db.query("SELECT * FROM investigations_list WHERE name = 'PTA Impedance'", one=True)
        self.assertIsNotNone(pta)
        self.assertEqual(float(pta['default_fee']), 1000.0)
        self.assertEqual(pta['category'], 'Endoscopy & ENT Procedures')

    def test_investigation_billing_calculations(self):
        """Verify the multi-item checkout calculations for investigation bills"""
        db = get_db()
        
        # Override session role for Receptionist endpoint
        with self.client.session_transaction() as sess:
            sess['role'] = 'Reception'
            
        # Register a test patient first
        patient_id = "PAT-TEST-01"
        db.query("DELETE FROM patients WHERE patient_id = %s", (patient_id,), commit=True)
        
        # Create user
        db.query("""
            INSERT INTO patients (
                patient_id, patient_name, gender, age, address, phone1, 
                occupation, consultation_fee, discount_percent, final_amount, payment_mode, registration_date,
                total_bill, total_paid, remaining_balance, payment_status
            ) VALUES (%s, 'Test Patient', 'Male', 30, 'Test Address', '1234567890',
                      'Tester', 500, 0, 500, 'Cash', date('now'), 500, 500, 0, 'Paid')
        """, (patient_id,), commit=True)
        
        # Calculate subtotal for FLP Endoscopy (800) and PTA/Imp (700) = 1500
        # Discount = 10% of 1500 = 150
        # Taxable = 1350
        # GST (18% of 1350) = 243
        # Final Total = 1593
        payload = {
            "patient_id": patient_id,
            "investigations": ["FLP Endoscopy", "PTA Impedance"],
            "discount_type": "percent",
            "discount_value": 10.0,
            "gst_enabled": True,
            "payment_method": "Cash",
            "payment_status": "Paid"
        }
        
        res = self.client.post('/api/reception/add_investigation_bill', 
                               data=json.dumps(payload),
                               content_type='application/json')
        
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)
        self.assertTrue(data['success'])
        
        # Check database entry
        bill = db.query("SELECT * FROM investigation_bills WHERE patient_id = %s", (patient_id,), one=True)
        self.assertIsNotNone(bill)
        self.assertAlmostEqual(float(bill['subtotal']), 3000.0)
        self.assertAlmostEqual(float(bill['discount']), 300.0)
        self.assertAlmostEqual(float(bill['gst']), 486.0)
        self.assertAlmostEqual(float(bill['final_total']), 3186.0)
        
        # Clean up
        db.query("DELETE FROM investigation_bill_items WHERE bill_id = %s", (bill['bill_id'],), commit=True)
        db.query("DELETE FROM investigation_bills WHERE patient_id = %s", (patient_id,), commit=True)
        db.query("DELETE FROM patients WHERE patient_id = %s", (patient_id,), commit=True)

    def test_expense_logging_and_variance(self):
        """Verify registering hospital expenses and calculating statistics/ledger entries"""
        db = get_db()
        
        # Delete dummy expenses if any
        db.query("DELETE FROM hospital_expenses WHERE item_name = 'Test Utility Refill'", commit=True)
        
        # Log custom expense
        res = self.client.post('/api/admin/add_expense', data={
            "category": "Oxygen Cylinders",
            "item_name": "Test Utility Refill",
            "quantity": "2",
            "unit_price": "1200",
            "vendor": "Test Vendor Corp",
            "invoice_number": "INV-TEST-009",
            "payment_method": "UPI",
            "description": "Oxygen refills for testing",
            "remarks": "N/A"
        })
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)
        self.assertTrue(data['success'])
        
        # Verify db entry
        exp = db.query("SELECT * FROM hospital_expenses WHERE item_name = 'Test Utility Refill'", one=True)
        self.assertIsNotNone(exp)
        self.assertEqual(int(exp['quantity']), 2)
        self.assertEqual(float(exp['unit_price']), 1200.0)
        self.assertEqual(float(exp['amount']), 2400.0)
        
        # Verify ledger report fetches it as an outflow using search key 'Utility Refill'
        ledger_res = self.client.get('/api/admin/ledger?filter_type=all&search=utility+refill')
        self.assertEqual(ledger_res.status_code, 200)
        ledger_data = json.loads(ledger_res.data)
        self.assertGreater(len(ledger_data['ledger']), 0)
        self.assertEqual(float(ledger_data['ledger'][0]['expense']), 2400.0)
        
        # Clean up
        db.query("DELETE FROM hospital_expenses WHERE item_name = 'Test Utility Refill'", commit=True)

    def test_audit_logs_engine(self):
        """Verify actions are appended to audit logs"""
        db = get_db()
        db.query("DELETE FROM audit_logs WHERE username = 'test_audit_user'", commit=True)
        
        # Record session for audit trail logging inside request context
        with app.test_request_context():
            session['username'] = 'test_audit_user'
            session['role'] = 'Admin'
            log_action("Test audit message", "Old state text", "New state text")
        
        # Fetch log from DB
        log = db.query("SELECT * FROM audit_logs WHERE username = 'test_audit_user'", one=True)
        self.assertIsNotNone(log)
        self.assertEqual(log['action'], "Test audit message")
        self.assertEqual(log['old_value'], "Old state text")
        self.assertEqual(log['new_value'], "New state text")
        
        # Clean up
        db.query("DELETE FROM audit_logs WHERE username = 'test_audit_user'", commit=True)

    def test_symptom_checklist_json_storage(self):
        """Verify dynamic structured symptoms JSON is stored and retrieved correctly"""
        db = get_db()
        
        # Override session role for Doctor endpoint
        with self.client.session_transaction() as sess:
            sess['role'] = 'Doctor'
            sess['username'] = 'doctor'
            
        patient_id = "PAT-TEST-02"
        db.query("DELETE FROM patients WHERE patient_id = %s", (patient_id,), commit=True)
        
        # Create a test patient
        db.query("""
            INSERT INTO patients (
                patient_id, patient_name, gender, age, address, phone1, 
                occupation, consultation_fee, discount_percent, final_amount, payment_mode, registration_date,
                total_bill, total_paid, remaining_balance, payment_status
            ) VALUES (%s, 'Test Patient 2', 'Female', 28, 'Test Address 2', '0987654321',
                      'Tester', 500, 0, 500, 'Online', date('now'), 500, 500, 0, 'Paid')
        """, (patient_id,), commit=True)
        
        # Structured complaints payload
        complaints_list = [
            {"category": "Ear", "complaint": "Ear Pain", "duration_value": 3, "duration_unit": "Months"},
            {"category": "Nose", "complaint": "Congestion", "duration_value": 5, "duration_unit": "Days"}
        ]
        
        payload = {
            "patient_id": patient_id,
            "present_illness": "Onset since 2 days",
            "past_history": "N/A",
            "treatment_history": "N/A",
            "family_history": "N/A",
            "personal_history": "N/A",
            "examination": "Swelling in canal",
            "provisional_diagnosis": "Otitis externa",
            "surgery_eligible": "No",
            "complaints_json": json.dumps(complaints_list),
            "investigations[]": ["FLP Endoscopy"]
        }
        
        res = self.client.post('/api/doctor/add_consultation', data=payload)
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)
        self.assertTrue(data['success'])
        
        # Fetch consultation from DB and check complaints JSON content
        consult = db.query("SELECT * FROM consultations WHERE patient_id = %s ORDER BY consultation_date DESC LIMIT 1", (patient_id,), one=True)
        self.assertIsNotNone(consult)
        self.assertIn('"complaint": "Ear Pain"', consult['complaints'])
        self.assertIn('"duration_value": 3', consult['complaints'])
        
        # Clean up
        db.query("DELETE FROM consultations WHERE patient_id = %s", (patient_id,), commit=True)
        db.query("DELETE FROM patients WHERE patient_id = %s", (patient_id,), commit=True)

    def test_scribe_session_endpoints(self):
        """Verify AI Scribe process API, session creation and secure recording download"""
        db = get_db()
        
        # Override session role for Doctor endpoint
        with self.client.session_transaction() as sess:
            sess['role'] = 'Doctor'
            sess['username'] = 'doctor'
            
        # Post a scenario process request
        res = self.client.post('/api/doctor/scribe_process', data={
            "scenario_id": "otitis",
            "patient_id": "P1001"
        })
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)
        self.assertTrue(data['success'])
        self.assertIsNotNone(data['session_id'])
        self.assertIn("ear pain", data['transcript'].lower())
        
        session_id = data['session_id']
        
        # Verify scribe session is saved in database and can be decrypted/retrieved via secure API
        get_res = self.client.get(f'/api/doctor/scribe_get/{session_id}')
        self.assertEqual(get_res.status_code, 200)
        get_data = json.loads(get_res.data)
        self.assertTrue(get_data['success'])
        self.assertEqual(get_data['patient_id'], 'P1001')
        self.assertEqual(get_data['doctor_username'], 'doctor')
        self.assertIn("Otitis Externa", json.dumps(get_data['clinical_summary']))
        
        # Verify role-based auth restriction: Receptionist should be blocked (redirected)
        with self.client.session_transaction() as sess:
            sess['role'] = 'Reception'
            sess['username'] = 'receptionist'
            sess['logged_in'] = True
        blocked_res = self.client.get(f'/api/doctor/scribe_get/{session_id}')
        self.assertEqual(blocked_res.status_code, 302)
        
        # Restore doctor session
        with self.client.session_transaction() as sess:
            sess['role'] = 'Doctor'
            sess['username'] = 'doctor'
            
        # Verify scribe editing and re-extraction
        save_res = self.client.post('/api/doctor/scribe_save', data={
            "session_id": session_id,
            "transcript": "Doctor:\nWhat symptoms do you have?\n\nPatient:\nI have had cough since 3 days.",
            "translated": "Doctor:\nWhat symptoms do you have?\n\nPatient:\nI have had cough since 3 days."
        })
        self.assertEqual(save_res.status_code, 200)
        save_data = json.loads(save_res.data)
        self.assertTrue(save_data['success'])
        symptom_names = [s['complaint'] for s in save_data['clinical_summary']['symptoms']]
        self.assertIn("Cough", symptom_names)
        
        # Verify secure recording endpoint returns 404 or audio
        rec_res = self.client.get(f'/api/doctor/recording/{session_id}')
        self.assertIn(rec_res.status_code, [404, 200])
        
        # Post a multilingual Telugu transcript process request
        res_te = self.client.post('/api/doctor/scribe_process', data={
            "transcript": "gontu noppi undi and దగ్గు",
            "patient_id": "P1001"
        })
        self.assertEqual(res_te.status_code, 200)
        data_te = json.loads(res_te.data)
        self.assertTrue(data_te['success'])
        self.assertIn("sore throat", data_te['translated'].lower())
        self.assertIn("cough", data_te['translated'].lower())
        
        # Verify the symptoms list inside clinical_summary
        summary_te = data_te['clinical_summary']
        symptom_names_te = [s['complaint'] for s in summary_te['symptoms']]
        self.assertIn("Sore Throat", symptom_names_te)
        self.assertIn("Cough", symptom_names_te)
        
        # Clean up
        db.query("DELETE FROM scribe_sessions WHERE session_id = %s", (session_id,), commit=True)
        db.query("DELETE FROM scribe_sessions WHERE session_id = %s", (data_te['session_id'],), commit=True)


    def test_custom_clinical_sections(self):
        """Verify dynamic custom clinical sections CRUD, duplication, reordering and consultation binding"""
        db = get_db()
        
        with self.client.session_transaction() as sess:
            sess['role'] = 'Doctor'
            sess['username'] = 'doctor'
            
        # 1. Create Custom Section
        res_create = self.client.post('/api/doctor/custom_sections/create', data={
            "patient_id": "P1001",
            "title": "Sinus Complaints",
            "content": "Pain in forehead and nose."
        })
        self.assertEqual(res_create.status_code, 200)
        data_create = json.loads(res_create.data)
        self.assertTrue(data_create['success'])
        sec_id = data_create['section']['id']
        
        # 2. Get All Custom Sections
        res_get = self.client.get('/api/doctor/custom_sections?patient_id=P1001')
        self.assertEqual(res_get.status_code, 200)
        data_get = json.loads(res_get.data)
        self.assertTrue(data_get['success'])
        self.assertTrue(any(s['id'] == sec_id and s['section_title'] == "Sinus Complaints" for s in data_get['sections']))
        
        # 3. Update Custom Section
        res_update = self.client.post('/api/doctor/custom_sections/update', data={
            "section_id": sec_id,
            "title": "Severe Sinus Complaints",
            "content": "Updated nasal blockage details.",
            "is_important": 1
        })
        self.assertEqual(res_update.status_code, 200)
        data_update = json.loads(res_update.data)
        self.assertTrue(data_update['success'])
        self.assertEqual(data_update['section']['section_title'], "Severe Sinus Complaints")
        self.assertEqual(data_update['section']['is_important'], 1)
        
        # 4. Duplicate Section
        res_dup = self.client.post('/api/doctor/custom_sections/duplicate', data={
            "section_id": sec_id
        })
        self.assertEqual(res_dup.status_code, 200)
        data_dup = json.loads(res_dup.data)
        self.assertTrue(data_dup['success'])
        dup_id = data_dup['section']['id']
        self.assertEqual(data_dup['section']['section_title'], "Severe Sinus Complaints (Copy)")
        
        # 5. Reorder Sections
        res_reorder = self.client.post('/api/doctor/custom_sections/reorder', 
            data=json.dumps({"order": [dup_id, sec_id]}),
            content_type='application/json'
        )
        self.assertEqual(res_reorder.status_code, 200)
        data_reorder = json.loads(res_reorder.data)
        self.assertTrue(data_reorder['success'])
        
        # Verify order in DB
        sec_db1 = db.query("SELECT * FROM patient_custom_sections WHERE id = %s", (sec_id,), one=True)
        sec_db2 = db.query("SELECT * FROM patient_custom_sections WHERE id = %s", (dup_id,), one=True)
        self.assertEqual(sec_db1['display_order'], 1)
        self.assertEqual(sec_db2['display_order'], 0)
        
        # 6. Save Consultation and verify linking
        res_consult = self.client.post('/api/doctor/add_consultation', data={
            "patient_id": "P1001",
            "present_illness": "Chronic cough.",
            "past_history": "None",
            "treatment_history": "None",
            "family_history": "None",
            "personal_history": "None",
            "examination": "Normal ENT",
            "provisional_diagnosis": "Cough assess",
            "surgery_eligible": "No"
        })
        self.assertEqual(res_consult.status_code, 200)
        
        # Get the latest consultation ID
        consult_row = db.query("SELECT MAX(consultation_id) as max_id FROM consultations WHERE patient_id = %s", ("P1001",), one=True)
        self.assertIsNotNone(consult_row)
        max_consult_id = consult_row['max_id']
        
        # Verify custom sections are now linked to this consultation ID
        sec_linked = db.query("SELECT * FROM patient_custom_sections WHERE id = %s", (sec_id,), one=True)
        self.assertEqual(sec_linked['consultation_id'], max_consult_id)
        
        # Clean up
        db.query("DELETE FROM patient_custom_sections WHERE id IN (%s, %s)", (sec_id, dup_id), commit=True)
        db.query("DELETE FROM consultations WHERE consultation_id = %s", (max_consult_id,), commit=True)

    def test_admin_user_management(self):
        """Verify Admin User Management API (Create, List, Update, Delete with security safeguards)"""
        db = get_db()
        
        # 1. Access by Doctor should be blocked
        with self.client.session_transaction() as sess:
            sess['role'] = 'Doctor'
            sess['username'] = 'doctor'
            sess['logged_in'] = True
            sess['user_id'] = 2
            
        res_blocked = self.client.get('/api/admin/users')
        self.assertIn(res_blocked.status_code, [302, 403])
        
        # 2. Access as Admin
        with self.client.session_transaction() as sess:
            sess['role'] = 'Admin'
            sess['username'] = 'admin'
            sess['logged_in'] = True
            sess['user_id'] = 1
            
        # 3. Create User
        res_create = self.client.post('/api/admin/users/create', data={
            "username": "test_doctor_user",
            "password": "testpassword123",
            "role": "Doctor"
        })
        self.assertEqual(res_create.status_code, 200)
        self.assertTrue(json.loads(res_create.data)['success'])
        
        # Get created user details
        created_user = db.query("SELECT * FROM users WHERE username = %s", ("test_doctor_user",), one=True)
        self.assertIsNotNone(created_user)
        user_id = created_user['user_id']
        
        # 4. List Users
        res_list = self.client.get('/api/admin/users')
        self.assertEqual(res_list.status_code, 200)
        data_list = json.loads(res_list.data)
        self.assertTrue(data_list['success'])
        self.assertTrue(any(u['username'] == 'test_doctor_user' for u in data_list['users']))
        
        # 5. Update User (Change Role & Password)
        res_update = self.client.post('/api/admin/users/update', data={
            "user_id": user_id,
            "role": "Reception",
            "password": "newpassword123"
        })
        self.assertEqual(res_update.status_code, 200)
        self.assertTrue(json.loads(res_update.data)['success'])
        
        # Verify in DB
        updated_user = db.query("SELECT * FROM users WHERE user_id = %s", (user_id,), one=True)
        self.assertEqual(updated_user['role'], 'Reception')
        self.assertEqual(updated_user['password'], 'newpassword123')
        
        # 6. Delete self lock test
        res_del_self = self.client.post('/api/admin/users/delete', data={"user_id": 1})
        self.assertEqual(res_del_self.status_code, 400)
        self.assertFalse(json.loads(res_del_self.data)['success'])
        
        # 7. Delete User
        res_del = self.client.post('/api/admin/users/delete', data={"user_id": user_id})
        self.assertEqual(res_del.status_code, 200)
        self.assertTrue(json.loads(res_del.data)['success'])
        
        # Verify deletion
        deleted_user = db.query("SELECT * FROM users WHERE user_id = %s", (user_id,), one=True)
        self.assertIsNone(deleted_user)

    def test_scribe_live_sync(self):
        """Verify real-time AI Scribe live synchronization, multilingual parsing, segregation of investigations and custom sections extraction"""
        with self.client.session_transaction() as sess:
            sess['role'] = 'Doctor'
            sess['username'] = 'doctor'
            sess['logged_in'] = True
            
        res = self.client.post('/api/doctor/scribe_live_sync', data={
            "transcript": "gontu noppi undi, difficulty swallowing, ear pain since 3 days, had a knee surgery in 2021",
            "patient_id": "P1001"
        })
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)
        self.assertTrue(data['success'])
        
        # Verify translation & speaker turns
        self.assertIn("sore throat", data['translated'].lower())
        self.assertIn("difficulty swallowing", data['translated'].lower())
        self.assertIn("ear pain", data['translated'].lower())
        
        # Verify symptoms extraction
        summary = data['clinical_summary']
        symptoms = [s['complaint'] for s in summary['symptoms']]
        self.assertIn("Sore Throat", symptoms)
        self.assertIn("Difficulty Swallowing", symptoms)
        self.assertIn("Ear Pain", symptoms)
        
        # Verify suggested investigations segregation
        suggested = summary['suggested_investigations']
        self.assertIn("Throat Swab", suggested)
        self.assertIn("Pure Tone Audiometry", suggested)
        self.assertNotIn("Throat Swab", summary.get('investigations', []))
        
        # Verify custom section extraction
        custom_sections = summary['custom_sections']
        self.assertTrue(any(cs['heading'] == 'Surgical History' and 'knee surgery' in cs['value'].lower() for cs in custom_sections))

    def test_doctor_waiting_list_and_reception_pending_investigations(self):
        """Verify doctor's patient queue and reception investigation billing workflow integration"""
        db = get_db()
        
        # 1. Create a patient
        db.query("""
            INSERT INTO patients (patient_id, patient_name, phone1, gender, age, address, final_amount, payment_mode)
            VALUES ('PAT-Q100', 'Queue Patient', '9988776655', 'Female', 28, 'Test Address', 500.00, 'Cash')
        """, commit=True)
        
        # 2. Simulate visit registration (patient entry)
        db.query("""
            INSERT INTO patient_visits (patient_id, fee_charged, visit_date)
            VALUES ('PAT-Q100', 500.00, datetime('now'))
        """, commit=True)
        
        # 3. Verify waiting list endpoint returns the patient
        with self.client.session_transaction() as sess:
            sess['role'] = 'Doctor'
            sess['username'] = 'doctor'
            sess['logged_in'] = True
            
        res_queue = self.client.get('/api/doctor/waiting_list')
        self.assertEqual(res_queue.status_code, 200)
        queue_data = json.loads(res_queue.data)
        patient_ids = [p['patient_id'] for p in queue_data]
        self.assertIn('PAT-Q100', patient_ids)
        
        # Verify details
        target_pat = [p for p in queue_data if p['patient_id'] == 'PAT-Q100'][0]
        self.assertEqual(target_pat['patient_name'], 'Queue Patient')
        self.assertEqual(target_pat['phone1'], '9988776655')
        
        # 4. Save consultation with investigations
        res_save = self.client.post('/api/doctor/add_consultation', data={
            "patient_id": "PAT-Q100",
            "present_illness": "Symptom logs",
            "provisional_diagnosis": "Acute infection",
            "investigations[]": ["FLP Endoscopy", "PTA Impedance"]
        })
        self.assertEqual(res_save.status_code, 200)
        
        # 5. Check if it appears in reception's pending investigations list
        with self.client.session_transaction() as sess:
            sess['role'] = 'Reception'
            sess['username'] = 'reception'
            
        res_pending = self.client.get('/api/reception/pending_investigations')
        self.assertEqual(res_pending.status_code, 200)
        pending_data = json.loads(res_pending.data)
        pending_pats = [p['patient_id'] for p in pending_data]
        self.assertIn('PAT-Q100', pending_pats)
        
        target_pending = [p for p in pending_data if p['patient_id'] == 'PAT-Q100'][0]
        self.assertEqual(target_pending['investigation_details'], 'FLP Endoscopy;PTA Impedance')
        
        # 6. Generate the investigation bill from reception
        res_bill = self.client.post('/api/reception/add_investigation_bill', 
                                   data=json.dumps({
                                       "patient_id": "PAT-Q100",
                                       "investigations": ["FLP Endoscopy", "PTA Impedance"],
                                       "discount_type": "percent",
                                       "discount_value": 0,
                                       "gst_enabled": False,
                                       "payment_method": "Cash",
                                       "payment_status": "Paid"
                                   }), 
                                   content_type='application/json')
        self.assertEqual(res_bill.status_code, 200)
        
        # 7. Check that the patient is removed from pending investigations list
        res_pending_after = self.client.get('/api/reception/pending_investigations')
        pending_data_after = json.loads(res_pending_after.data)
        pending_pats_after = [p['patient_id'] for p in pending_data_after]
        self.assertNotIn('PAT-Q100', pending_pats_after)

    def test_admin_financial_summary_today_metrics(self):
        """Verify admin financial summary API returns today's gross, discount, net, and category breakdowns"""
        with self.client.session_transaction() as sess:
            sess['role'] = 'Admin'
            sess['username'] = 'admin'
            sess['logged_in'] = True
            
        res = self.client.get('/api/admin/financial_summary')
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)
        
        # Verify the presence of all required today's metric keys
        required_keys = [
            'today_revenue', 'today_expenses', 'today_profit',
            'today_gross', 'today_discount', 'today_net',
            'today_consultation', 'today_investigation',
            'today_pharmacy', 'today_other'
        ]
        for key in required_keys:
            self.assertIn(key, data)
            self.assertIsInstance(data[key], (int, float))

if __name__ == '__main__':
    unittest.main()
