// TriSense Health ERP Frontend Logic
document.addEventListener("DOMContentLoaded", function () {
    // --------------------------------------------------
    // 1. Sidebar & Mobile Toggle
    // --------------------------------------------------
    const menuToggle = document.querySelector(".menu-toggle");
    const sidebar = document.querySelector(".app-sidebar");
    
    if (menuToggle && sidebar) {
        menuToggle.addEventListener("click", function () {
            sidebar.classList.toggle("show");
        });
    }

    // Close mobile sidebar on clicking outside
    document.addEventListener("click", function (event) {
        if (sidebar && sidebar.classList.contains("show") && 
            !sidebar.contains(event.target) && 
            menuToggle && !menuToggle.contains(event.target)) {
            sidebar.classList.remove("show");
        }
    });

    // --------------------------------------------------
    // 2. Tab Navigation System
    // --------------------------------------------------
    const tabButtons = document.querySelectorAll(".tab-btn");
    const tabContents = document.querySelectorAll(".tab-content");

    tabButtons.forEach(button => {
        button.addEventListener("click", function () {
            const targetTab = this.getAttribute("data-tab");

            // Deactivate all buttons & contents
            tabButtons.forEach(btn => btn.classList.remove("active"));
            tabContents.forEach(content => content.classList.remove("active"));

            // Activate current
            this.classList.add("active");
            const targetEl = document.getElementById(targetTab);
            if (targetEl) targetEl.classList.add("active");
        });
    });

    // --------------------------------------------------
    // 3. Export to CSV Utility
    // --------------------------------------------------
    window.exportTableToCSV = function(tableId, filename) {
        const table = document.getElementById(tableId);
        if (!table) return;

        let csv = [];
        const rows = table.querySelectorAll("tr");
        
        for (let i = 0; i < rows.length; i++) {
            // Ignore hidden rows
            if (rows[i].style.display === "none") continue;
            
            let row = [];
            const cols = rows[i].querySelectorAll("td, th");
            
            for (let j = 0; j < cols.length; j++) {
                // Remove commas and clean text
                let data = cols[j].innerText.replace(/(\r\n|\n|\r)/gm, "").replace(/(\s\s+)/g, ' ');
                data = data.replace(/"/g, '""');
                row.push('"' + data + '"');
            }
            csv.push(row.join(","));
        }

        const csvString = csv.join("\n");
        const blob = new Blob([csvString], { type: "text/csv;charset=utf-8;" });
        const link = document.createElement("a");
        
        if (link.download !== undefined) {
            const url = URL.createObjectURL(blob);
            link.setAttribute("href", url);
            link.setAttribute("download", filename);
            link.style.visibility = 'hidden';
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
        }
    };

    // --------------------------------------------------
    // 4. Export Table/Ledger to PDF (Print Window)
    // --------------------------------------------------
    window.printLedger = function(elementId, title) {
        const element = document.getElementById(elementId);
        if (!element) return;

        const printWindow = window.open("", "_blank");
        printWindow.document.write(`
            <html>
            <head>
                <title>${title}</title>
                <style>
                    body { font-family: 'Plus Jakarta Sans', sans-serif; padding: 30px; color: #0f172a; }
                    .header { text-align: center; margin-bottom: 30px; border-bottom: 2px solid #e2e8f0; padding-bottom: 20px; }
                    .header h1 { font-family: 'Outfit', sans-serif; margin: 0; color: #2563eb; font-size: 24px; }
                    .header p { margin: 5px 0 0 0; color: #64748b; font-size: 14px; }
                    table { width: 100%; border-collapse: collapse; margin-top: 20px; }
                    th, td { border: 1px solid #cbd5e1; padding: 10px; text-align: left; font-size: 12px; }
                    th { background-color: #f1f5f9; font-weight: bold; text-transform: uppercase; }
                    .footer { margin-top: 40px; text-align: right; font-size: 11px; color: #94a3b8; }
                </style>
            </head>
            <body>
                <div class="header">
                    <h1>Sagar ENT- Head and Neck Superspeciality Center</h1>
                    <p>Sagar ENT Super Speciality Center - System Generated Report</p>
                    <p>Generated on: ${new Date().toLocaleString()}</p>
                </div>
                <h3>${title}</h3>
                ${element.innerHTML}
                <div class="footer">
                    <p>Powered by Sagar ENT- Head and Neck Superspeciality Center &copy; 2026</p>
                </div>
                <script>
                    window.onload = function() { window.print(); window.close(); }
                </script>
            </body>
            </html>
        `);
        printWindow.document.close();
    };
});
