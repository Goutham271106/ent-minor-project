import unittest
import json
import os
import io
import datetime
from app import app, get_db
from database import DBWrapper

class TestClinicalDashboard(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        db = get_db()
        cls.original_sqlite_path = db.sqlite_path
        cls.test_sqlite_path = os.path.join(os.path.dirname(__file__), "test_clinical_db.sqlite")
        db.sqlite_path = cls.test_sqlite_path
        
        # Recreate test database file cleanly
        if os.path.exists(cls.test_sqlite_path):
            try:
                os.remove(cls.test_sqlite_path)
            except:
                pass
        db.init_sqlite()

    @classmethod
    def tearDownClass(cls):
        db = get_db()
        db.sqlite_path = cls.original_sqlite_path
        if os.path.exists(cls.test_sqlite_path):
            try:
                os.remove(cls.test_sqlite_path)
            except:
                pass

    def setUp(self):
        self.app = app.test_client()
        self.app.testing = True
        
        # Log in as Doctor
        with self.app.session_transaction() as sess:
            sess['logged_in'] = True
            sess['username'] = 'doctor'
            sess['role'] = 'Doctor'
            
        # Clean clinical tables in test db
        db = get_db()
        db.query("DELETE FROM patient_documents", commit=True)
        db.query("DELETE FROM prescriptions", commit=True)
        db.query("DELETE FROM consultations", commit=True)
        db.query("DELETE FROM patient_visits", commit=True)
        db.query("DELETE FROM patients WHERE patient_id = 'PAT-TEST-CLINICAL'", commit=True)
        
        # Seed test patient
        db.query("""
            INSERT INTO patients (patient_id, patient_name, gender, age, address, phone1, final_amount, payment_mode)
            VALUES ('PAT-TEST-CLINICAL', 'Test Patient Clinical', 'Female', 35, 'Address ENT', '1234567890', 500.00, 'Cash')
        """, commit=True)

    def tearDown(self):
        db = get_db()
        try:
            db.query("DELETE FROM patient_documents", commit=True)
            db.query("DELETE FROM prescriptions", commit=True)
            db.query("DELETE FROM consultations", commit=True)
            db.query("DELETE FROM patient_visits", commit=True)
            db.query("DELETE FROM patients WHERE patient_id = 'PAT-TEST-CLINICAL'", commit=True)
        except:
            pass

    def test_document_upload_and_management(self):
        # 1. Upload document
        file_content = b"Mock scan report content."
        res = self.app.post('/api/doctor/upload_document', data={
            'patient_id': 'PAT-TEST-CLINICAL',
            'description': 'Endoscopy Scan Report',
            'file': (io.BytesIO(file_content), 'endoscopy.txt')
        }, content_type='multipart/form-data')
        if res.status_code != 200:
            print("UPLOAD DOC ERROR:", res.status_code, res.data)
        self.assertEqual(res.status_code, 200)
        self.assertTrue(json.loads(res.data)['success'])
        
        # 2. List documents
        res_list = self.app.get('/api/doctor/list_documents/PAT-TEST-CLINICAL')
        self.assertEqual(res_list.status_code, 200)
        docs = json.loads(res_list.data)
        self.assertEqual(len(docs), 1)
        self.assertEqual(docs[0]['filename'], 'endoscopy.txt')
        self.assertEqual(docs[0]['description'], 'Endoscopy Scan Report')
        doc_id = docs[0]['document_id']
        
        # 3. Download document
        res_dl = self.app.get(f'/api/doctor/download_document/{doc_id}')
        self.assertEqual(res_dl.status_code, 200)
        self.assertEqual(res_dl.data, file_content)
        res_dl.close()
        
        # 4. Delete document
        res_del = self.app.post(f'/api/doctor/delete_document/{doc_id}')
        self.assertEqual(res_del.status_code, 200)
        self.assertTrue(json.loads(res_del.data)['success'])
        
        # 5. Verify deleted from list
        res_list2 = self.app.get('/api/doctor/list_documents/PAT-TEST-CLINICAL')
        self.assertEqual(len(json.loads(res_list2.data)), 0)

    def test_waiting_list_rollover_logic(self):
        db = get_db()
        
        # Visit A: Today, viewed=0
        db.query("""
            INSERT INTO patient_visits (patient_id, fee_charged, visit_date, viewed)
            VALUES ('PAT-TEST-CLINICAL', 500.00, datetime('now'), 0)
        """, commit=True)
        
        # Visit B: Yesterday (date -1 day), viewed=0 (carry over!)
        db.query("""
            INSERT INTO patient_visits (patient_id, fee_charged, visit_date, viewed)
            VALUES ('PAT-TEST-CLINICAL', 500.00, datetime('now', '-1 day'), 0)
        """, commit=True)
        
        # Visit C: Yesterday (date -1 day), viewed=1 (remove!)
        db.query("""
            INSERT INTO patient_visits (patient_id, fee_charged, visit_date, viewed)
            VALUES ('PAT-TEST-CLINICAL', 500.00, datetime('now', '-1 day'), 1)
        """, commit=True)
        
        # Get waiting list
        res = self.app.get('/api/doctor/waiting_list')
        self.assertEqual(res.status_code, 200)
        queue = json.loads(res.data)
        
        # Should have 2 entries: Visit A (today) and Visit B (yesterday unviewed)
        # Visit C should be excluded
        self.assertEqual(len(queue), 2)
        
        # Let's mark them viewed by calling profile
        self.app.get('/api/doctor/patient_profile/PAT-TEST-CLINICAL')
        
        # All visits for patient should now be viewed = 1 in database
        res_check = db.query("SELECT COUNT(*) as cnt FROM patient_visits WHERE patient_id = 'PAT-TEST-CLINICAL' AND viewed = 0", one=True)
        self.assertEqual(res_check['cnt'], 0)

    def test_consultation_save_and_pdf_generation(self):
        db = get_db()
        
        # Upload a report first to test attachment inclusion in PDF
        self.app.post('/api/doctor/upload_document', data={
            'patient_id': 'PAT-TEST-CLINICAL',
            'description': 'Mock Scan',
            'file': (io.BytesIO(b"Fake report body"), 'report.txt')
        }, content_type='multipart/form-data')
        
        # Save consultation
        res = self.app.post('/api/doctor/add_consultation', data={
            'patient_id': 'PAT-TEST-CLINICAL',
            'present_illness': 'Severe throat pain for 3 days',
            'past_history': 'No HTN/DM',
            'treatment_history': 'Took paracetamol',
            'family_history': 'None significant',
            'personal_history': 'Non-smoker',
            'examination': 'Congestion in tonsils',
            'provisional_diagnosis': 'Acute Tonsillitis',
            'surgery_eligible': 'No',
            'investigations[]': ['Blood Test', 'Throat Swab'],
            'medicine_name[]': ['Amoxicillin 500mg', 'Paracetamol 650mg'],
            'duration_days[]': ['5', '3'],
            'morning[]': ['1', '1'],
            'afternoon[]': ['1', '0'],
            'night[]': ['1', '1']
        })
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)
        self.assertTrue(data['success'])
        self.assertIsNotNone(data['pdf_url'])
        
        # Verify PDF file created
        pdf_relative_path = data['pdf_url']
        static_pdf_path = os.path.join(app.root_path, pdf_relative_path.lstrip('/'))
        self.assertTrue(os.path.exists(static_pdf_path))
        self.assertTrue(os.path.getsize(static_pdf_path) > 0)
        
        # Verify prescriptions are linked to the newly created consultation_id
        consult = db.query("SELECT consultation_id FROM consultations WHERE patient_id = 'PAT-TEST-CLINICAL' ORDER BY consultation_id DESC LIMIT 1", one=True)
        self.assertIsNotNone(consult)
        
        presc = db.query("SELECT * FROM prescriptions WHERE patient_id = 'PAT-TEST-CLINICAL'")
        self.assertEqual(len(presc), 2)
        for p in presc:
            self.assertEqual(p['consultation_id'], consult['consultation_id'])
            
        # Cleanup generated file
        if os.path.exists(static_pdf_path):
            try:
                os.remove(static_pdf_path)
            except:
                pass

if __name__ == '__main__':
    unittest.main()
