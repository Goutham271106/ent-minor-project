import unittest
import json
import os
from app import app, get_db
from database import DBWrapper

class TestReceptionLedger(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        db = get_db()
        cls.original_sqlite_path = db.sqlite_path
        cls.test_sqlite_path = os.path.join(os.path.dirname(__file__), "test_reception_db.sqlite")
        db.sqlite_path = cls.test_sqlite_path
        
        # Recreate test database file cleanly
        if os.path.exists(cls.test_sqlite_path):
            try:
                os.remove(cls.test_sqlite_path)
            except:
                pass
        db.init_sqlite()

    @classmethod
    def tearDownClass(cls):
        db = get_db()
        db.sqlite_path = cls.original_sqlite_path
        if os.path.exists(cls.test_sqlite_path):
            try:
                os.remove(cls.test_sqlite_path)
            except:
                pass

    def setUp(self):
        self.app = app.test_client()
        self.app.testing = True
        
        # Log in as Reception
        with self.app.session_transaction() as sess:
            sess['logged_in'] = True
            sess['username'] = 'reception'
            sess['role'] = 'Reception'
            
        # Clean financial tables inside test db
        db = get_db()
        db.query("DELETE FROM payments", commit=True)
        db.query("DELETE FROM bills", commit=True)
        db.query("DELETE FROM patients WHERE patient_id IN ('PAT-LEDG-1', 'PAT-LEDG-2')", commit=True)
        
        # Seed test patients
        db.query("""
            INSERT INTO patients (patient_id, patient_name, gender, age, address, phone1, final_amount, payment_mode)
            VALUES ('PAT-LEDG-1', 'Ledger Patient One', 'Male', 40, 'Address A', '1111111111', 0.00, 'Cash')
        """, commit=True)
        db.query("""
            INSERT INTO patients (patient_id, patient_name, gender, age, address, phone1, final_amount, payment_mode)
            VALUES ('PAT-LEDG-2', 'Ledger Patient Two', 'Female', 30, 'Address B', '2222222222', 0.00, 'Cash')
        """, commit=True)
        
        # Seed test bills and payments
        # 1. Consultation paid in cash (today)
        b1_id = db.query("""
            INSERT INTO bills (patient_id, item_category, description, amount, created_by, bill_date)
            VALUES ('PAT-LEDG-1', 'Consultation', 'Subsequent Consultation Fee', 500.00, 'reception', '2026-07-09 10:00:00')
        """, commit=True)
        db.query("""
            INSERT INTO payments (patient_id, bill_id, amount_paid, payment_method, received_by, remarks, payment_date)
            VALUES ('PAT-LEDG-1', %s, 500.00, 'Cash', 'reception', 'Paid consultation', '2026-07-09 10:05:00')
        """, (b1_id,), commit=True)
        
        # 2. Investigation paid online via UPI (yesterday)
        b2_id = db.query("""
            INSERT INTO bills (patient_id, item_category, description, amount, created_by, bill_date)
            VALUES ('PAT-LEDG-2', 'Lab', 'Blood Test', 1200.00, 'reception', '2026-07-08 12:00:00')
        """, commit=True)
        db.query("""
            INSERT INTO payments (patient_id, bill_id, amount_paid, payment_method, received_by, remarks, payment_date)
            VALUES ('PAT-LEDG-2', %s, 1200.00, 'UPI', 'reception', 'Paid lab receipt', '2026-07-08 12:05:00')
        """, (b2_id,), commit=True)
        
        # 3. Other charge paid online via Card (last month)
        b3_id = db.query("""
            INSERT INTO bills (patient_id, item_category, description, amount, created_by, bill_date)
            VALUES ('PAT-LEDG-1', 'Room', 'Ward Room 3 Days', 3000.00, 'reception', '2026-06-15 14:00:00')
        """, commit=True)
        db.query("""
            INSERT INTO payments (patient_id, bill_id, amount_paid, payment_method, received_by, remarks, payment_date)
            VALUES ('PAT-LEDG-1', %s, 3000.00, 'Card', 'reception', 'Paid ward charges', '2026-06-15 14:05:00')
        """, (b3_id,), commit=True)

    def tearDown(self):
        db = get_db()
        try:
            db.query("DELETE FROM payments", commit=True)
            db.query("DELETE FROM bills", commit=True)
            db.query("DELETE FROM patients WHERE patient_id IN ('PAT-LEDG-1', 'PAT-LEDG-2')", commit=True)
        except:
            pass

    def test_global_ledger_all(self):
        res = self.app.get('/api/reception/global_ledger')
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)
        
        self.assertEqual(len(data['ledger']), 3)
        summary = data['summary']
        self.assertEqual(summary['subtotal_consultation'], 500.0)
        self.assertEqual(summary['subtotal_investigation'], 1200.0)
        self.assertEqual(summary['subtotal_other'], 3000.0)
        self.assertEqual(summary['total_cash'], 500.0)
        self.assertEqual(summary['total_online'], 4200.0)
        self.assertEqual(summary['overall_total'], 4700.0)

    def test_global_ledger_filter_billing_type(self):
        # Consultation only
        res = self.app.get('/api/reception/global_ledger?billing_type=consultation')
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)
        self.assertEqual(len(data['ledger']), 1)
        self.assertEqual(data['ledger'][0]['billing_type'], 'consultation')
        
        # Investigation only
        res2 = self.app.get('/api/reception/global_ledger?billing_type=investigation')
        self.assertEqual(res2.status_code, 200)
        data2 = json.loads(res2.data)
        self.assertEqual(len(data2['ledger']), 1)
        self.assertEqual(data2['ledger'][0]['billing_type'], 'investigation')

    def test_global_ledger_filter_date(self):
        # Specific Day
        res = self.app.get('/api/reception/global_ledger?date_type=day&date_value=2026-07-09')
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)
        self.assertEqual(len(data['ledger']), 1)
        self.assertEqual(data['ledger'][0]['patient_id'], 'PAT-LEDG-1')
        
        # Specific Month
        res2 = self.app.get('/api/reception/global_ledger?date_type=month&date_value=2026-07')
        self.assertEqual(res2.status_code, 200)
        data2 = json.loads(res2.data)
        self.assertEqual(len(data2['ledger']), 2) # 2026-07-09 and 2026-07-08
        
        # Specific Year
        res3 = self.app.get('/api/reception/global_ledger?date_type=year&date_value=2026')
        self.assertEqual(res3.status_code, 200)
        data3 = json.loads(res3.data)
        self.assertEqual(len(data3['ledger']), 3)

    def test_global_ledger_search(self):
        # Search by patient name
        res = self.app.get('/api/reception/global_ledger?search=Patient+Two')
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)
        self.assertEqual(len(data['ledger']), 1)
        self.assertEqual(data['ledger'][0]['patient_name'], 'Ledger Patient Two')
        
        # Search by patient ID
        res2 = self.app.get('/api/reception/global_ledger?search=PAT-LEDG-1')
        self.assertEqual(res2.status_code, 200)
        data2 = json.loads(res2.data)
        self.assertEqual(len(data2['ledger']), 2)

    def test_register_patient_optional_fields(self):
        # Register a patient with only required fields (ID, Name, Phone1)
        res = self.app.post('/api/reception/register_patient', data={
            'patient_id': 'PAT-OPT-TEST',
            'patient_name': 'Optional Fields Patient',
            'phone1': '5555555555',
            'gender': '',
            'age': '',
            'address': '',
            'occupation': '',
            'phone2': ''
        })
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)
        self.assertTrue(data['success'])
        
        # Verify the database contains the registered patient with empty/default optional fields
        db = get_db()
        pat = db.query("SELECT * FROM patients WHERE patient_id = 'PAT-OPT-TEST'", one=True)
        self.assertIsNotNone(pat)
        self.assertEqual(pat['patient_name'], 'Optional Fields Patient')
        self.assertEqual(pat['phone1'], '5555555555')
        self.assertEqual(pat['gender'], '')
        self.assertEqual(pat['age'], 0)
        self.assertEqual(pat['address'], '')
        self.assertEqual(pat['occupation'], '')
        self.assertEqual(pat['phone2'], '')

    def test_register_patient_validation_missing_required(self):
        # 1. Missing patient_id
        res = self.app.post('/api/reception/register_patient', data={
            'patient_id': '',
            'patient_name': 'No ID Patient',
            'phone1': '5555555555'
        })
        self.assertEqual(res.status_code, 400)
        
        # 2. Missing patient_name
        res = self.app.post('/api/reception/register_patient', data={
            'patient_id': 'PAT-NO-NAME',
            'patient_name': '   ',
            'phone1': '5555555555'
        })
        self.assertEqual(res.status_code, 400)
        
        # 3. Missing phone1
        res = self.app.post('/api/reception/register_patient', data={
            'patient_id': 'PAT-NO-PHONE',
            'patient_name': 'No Phone Patient',
            'phone1': ''
        })
        self.assertEqual(res.status_code, 400)

    def test_update_patient_optional_fields(self):
        # Update existing patient to have empty fields
        res = self.app.post('/api/reception/update_patient/PAT-LEDG-1', data={
            'patient_name': 'Updated Ledger Patient One',
            'phone1': '9999999999',
            'age': '',
            'address': '',
            'occupation': '',
            'phone2': ''
        })
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)
        self.assertTrue(data['success'])
        
        # Verify db updates
        db = get_db()
        pat = db.query("SELECT * FROM patients WHERE patient_id = 'PAT-LEDG-1'", one=True)
        self.assertIsNotNone(pat)
        self.assertEqual(pat['patient_name'], 'Updated Ledger Patient One')
        self.assertEqual(pat['age'], 0)
        self.assertEqual(pat['address'], '')
        self.assertEqual(pat['phone1'], '9999999999')
        self.assertEqual(pat['occupation'], '')
        self.assertEqual(pat['phone2'], '')

    def test_update_patient_validation_missing_required(self):
        # Missing required patient_name
        res = self.app.post('/api/reception/update_patient/PAT-LEDG-1', data={
            'patient_name': '',
            'phone1': '9999999999'
        })
        self.assertEqual(res.status_code, 400)

if __name__ == '__main__':
    unittest.main()
