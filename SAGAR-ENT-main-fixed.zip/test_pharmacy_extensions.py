import unittest
import json
import os
from app import app, get_db
from database import DBWrapper

class TestPharmacyExtensions(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        db = get_db()
        cls.original_sqlite_path = db.sqlite_path
        cls.test_sqlite_path = os.path.join(os.path.dirname(__file__), "test_pharmacy_db.sqlite")
        db.sqlite_path = cls.test_sqlite_path
        
        # Recreate test database file cleanly
        if os.path.exists(cls.test_sqlite_path):
            try:
                os.remove(cls.test_sqlite_path)
            except:
                pass
        db.init_sqlite()

    @classmethod
    def tearDownClass(cls):
        db = get_db()
        db.sqlite_path = cls.original_sqlite_path
        if os.path.exists(cls.test_sqlite_path):
            try:
                os.remove(cls.test_sqlite_path)
            except:
                pass

    def setUp(self):
        self.app = app.test_client()
        self.app.testing = True
        
        with self.app.session_transaction() as sess:
            sess['logged_in'] = True
            sess['username'] = 'pharmacy'
            sess['role'] = 'Pharmacy'
            
        # Clean test stock items and prescriptions inside test db
        db = get_db()
        db.query("DELETE FROM pharmacy_stock", commit=True)
        db.query("DELETE FROM prescriptions", commit=True)
        db.query("DELETE FROM patients WHERE patient_id = 'PAT-TEST'", commit=True)
        
        # Seed test patient
        db.query("""
            INSERT INTO patients (patient_id, patient_name, gender, age, address, phone1, final_amount, payment_mode)
            VALUES ('PAT-TEST', 'Test Patient', 'Male', 30, 'Test Address', '1234567890', 0.00, 'Cash')
        """, commit=True)

    def tearDown(self):
        db = get_db()
        try:
            db.query("DELETE FROM pharmacy_stock", commit=True)
            db.query("DELETE FROM prescriptions", commit=True)
            db.query("DELETE FROM patients WHERE patient_id = 'PAT-TEST'", commit=True)
        except:
            pass

    def test_bulk_upload_tsv_paste(self):
        # Test copy-pasted Tab Separated Values (TSV) typical of Excel sheet pastes
        tsv_data = (
            "ITEM NAME\tQTY\tRATE\tPURCHASE PRICE\tGST RATE\tEXPIRY DATE\tSUPPLIER COMPANY\n"
            "DOLO - 650MG\t200\t1.50\t1.05\t12%\t2028-06-30\tSagar Pharmacy Ltd\n"
            "AMOXICILLIN 500MG\t100\t4.50\t3.15\t18%\t2028-12-31\tSagar Pharmacy Ltd\n"
        )
        
        res = self.app.post('/api/pharmacy/bulk_upload_stock', data={
            'csv_text': tsv_data
        })
        self.assertEqual(res.status_code, 200)
        
        data = json.loads(res.data)
        self.assertTrue(data['success'])
        
        # Finalize the import
        finalize_rows = []
        for r in data['rows']:
            finalize_rows.append({
                'medicine_name': r['medicine_name']['value'],
                'batch_number': r['batch_number']['value'],
                'stock_quantity': r['stock_quantity']['value'],
                'sale_price': r['sale_price']['value'],
                'purchase_price': r['purchase_price']['value'],
                'gst_rate': r['gst_rate']['value'],
                'expiry_date': r['expiry_date']['value'],
                'supplier_company': r['supplier_company']['value']
            })
            
        res_fin = self.app.post('/api/pharmacy/finalize_bulk_import', 
                                data=json.dumps({'rows': finalize_rows}), 
                                content_type='application/json')
        self.assertEqual(res_fin.status_code, 200)
        
        # Verify inserted into database
        db = get_db()
        items = db.query("SELECT * FROM pharmacy_stock ORDER BY medicine_name ASC")
        self.assertEqual(len(items), 2)
        
        # Item 1: Amoxicillin
        self.assertEqual(items[0]['medicine_name'], 'AMOXICILLIN 500MG')
        self.assertEqual(int(items[0]['stock_quantity']), 100)
        self.assertEqual(float(items[0]['sale_price']), 4.50)
        self.assertEqual(float(items[0]['purchase_price']), 3.15)
        self.assertEqual(float(items[0]['gst_rate']), 18.0)
        self.assertEqual(items[0]['supplier_company'], 'Sagar Pharmacy Ltd')
        
        # Item 2: Dolo
        self.assertEqual(items[1]['medicine_name'], 'DOLO - 650MG')
        self.assertEqual(int(items[1]['stock_quantity']), 200)
        self.assertEqual(float(items[1]['sale_price']), 1.50)
        self.assertEqual(float(items[1]['purchase_price']), 1.05)
        self.assertEqual(float(items[1]['gst_rate']), 12.0)

    def test_estimate_price_and_dispense_flow(self):
        tsv_data = (
            "ITEM NAME\tQTY\tRATE\tPURCHASE PRICE\tGST RATE\tEXPIRY DATE\tSUPPLIER COMPANY\n"
            "DOLO - 650MG\t200\t1.50\t1.05\t12%\t2028-06-30\tSagar Pharmacy Ltd\n"
        )
        res_upload = self.app.post('/api/pharmacy/bulk_upload_stock', data={'csv_text': tsv_data})
        self.assertEqual(res_upload.status_code, 200)
        data = json.loads(res_upload.data)
        finalize_rows = []
        for r in data['rows']:
            finalize_rows.append({
                'medicine_name': r['medicine_name']['value'],
                'batch_number': r['batch_number']['value'],
                'stock_quantity': r['stock_quantity']['value'],
                'sale_price': r['sale_price']['value'],
                'purchase_price': r['purchase_price']['value'],
                'gst_rate': r['gst_rate']['value'],
                'expiry_date': r['expiry_date']['value'],
                'supplier_company': r['supplier_company']['value']
            })
        self.app.post('/api/pharmacy/finalize_bulk_import', 
                      data=json.dumps({'rows': finalize_rows}), 
                      content_type='application/json')
        
        # 2. Add prescription (morning + night = twice a day, for 10 days = 20 tablets)
        db = get_db()
        prescription_id = db.query("""
            INSERT INTO prescriptions (patient_id, medicine_name, duration_days, morning, afternoon, night, dispensed)
            VALUES ('PAT-TEST', 'Dolo 650mg', 10, 1, 0, 1, 'No')
        """, commit=True)
        
        # 3. Get estimate
        res_est = self.app.get(f'/api/pharmacy/estimate_price/{prescription_id}')
        self.assertEqual(res_est.status_code, 200)
        est = json.loads(res_est.data)
        
        self.assertTrue(est['success'])
        self.assertEqual(est['total_qty'], 20)
        self.assertEqual(est['unit_price'], 1.50)
        self.assertEqual(est['subtotal'], 30.00)
        self.assertEqual(est['gst_rate'], 12.00)
        self.assertEqual(est['gst_amount'], 3.60)
        self.assertEqual(est['grand_total'], 33.60)
        self.assertTrue(est['matched'])
        self.assertEqual(est['stock_quantity'], 200)
        
        # 4. Dispense
        res_disp = self.app.post(f'/api/pharmacy/dispense/{prescription_id}', data={
            'pharmacy_charge': 33.60,
            'payment_method': 'Cash'
        })
        self.assertEqual(res_disp.status_code, 200)
        disp = json.loads(res_disp.data)
        self.assertTrue(disp['success'])
        # 5. Verify stock deduction
        stock = db.query("SELECT stock_quantity FROM pharmacy_stock WHERE medicine_name = 'DOLO - 650MG'", one=True)
        self.assertEqual(stock['stock_quantity'], 180) # 200 - 20 = 180
        
        # 6. Verify ledger bill insertion
        bill = db.query("SELECT * FROM bills WHERE patient_id = 'PAT-TEST' AND item_category = 'Pharmacy'", one=True)
        self.assertIsNotNone(bill)
        self.assertEqual(float(bill['amount']), 33.60)
        
        # 7. Verify ledger payment transaction insertion
        payment = db.query("SELECT * FROM payments WHERE patient_id = 'PAT-TEST' AND bill_id = %s", (bill['bill_id'],), one=True)
        self.assertIsNotNone(payment)
        self.assertEqual(float(payment['amount_paid']), 33.60)

    def test_bulk_upload_pdf_mock(self):
        from unittest.mock import patch, MagicMock
        import io
        
        mock_pdf = MagicMock()
        mock_pdf.__enter__.return_value = mock_pdf
        mock_page = MagicMock()
        mock_page.extract_tables.return_value = [
            [
                ["ITEM NAME", "BATCH NUMBER", "QTY", "RATE", "PURCHASE PRICE", "GST RATE", "EXPIRY DATE", "SUPPLIER COMPANY"],
                ["PAN - 40MG", "B-PAN99", "150", "3.20", "2.24", "12%", "2028-10-31", "Sagar Pharmacy Ltd"]
            ]
        ]
        mock_pdf.pages = [mock_page]
        
        with patch('pdfplumber.open', return_value=mock_pdf):
            res = self.app.post('/api/pharmacy/bulk_upload_stock', data={
                'file': (io.BytesIO(b'%PDF-1.4...'), 'stock.pdf')
            }, content_type='multipart/form-data')
            self.assertEqual(res.status_code, 200)
            data = json.loads(res.data)
            finalize_rows = []
            for r in data['rows']:
                finalize_rows.append({
                    'medicine_name': r['medicine_name']['value'],
                    'batch_number': r['batch_number']['value'],
                    'stock_quantity': r['stock_quantity']['value'],
                    'sale_price': r['sale_price']['value'],
                    'purchase_price': r['purchase_price']['value'],
                    'gst_rate': r['gst_rate']['value'],
                    'expiry_date': r['expiry_date']['value'],
                    'supplier_company': r['supplier_company']['value']
                })
            self.app.post('/api/pharmacy/finalize_bulk_import', 
                          data=json.dumps({'rows': finalize_rows}), 
                          content_type='application/json')
            
        db = get_db()
        item = db.query("SELECT * FROM pharmacy_stock WHERE medicine_name = 'PAN - 40MG'", one=True)
        self.assertIsNotNone(item)
        self.assertEqual(item['batch_number'], 'B-PAN99')
        self.assertEqual(int(item['stock_quantity']), 150)

    def test_bulk_upload_image_ocr_mock(self):
        from unittest.mock import patch, MagicMock
        import io
        
        mock_ocr_result = [
            ([[10, 10], [50, 10], [50, 25], [10, 25]], "ITEM NAME", 0.99),
            ([[70, 10], [120, 10], [120, 25], [70, 25]], "BATCH NUMBER", 0.99),
            ([[140, 10], [170, 10], [170, 25], [140, 25]], "QTY", 0.99),
            ([[190, 10], [220, 10], [220, 25], [190, 25]], "RATE", 0.99),
            ([[240, 10], [270, 10], [270, 25], [240, 25]], "EXPIRY DATE", 0.99),
            
            ([[10, 40], [50, 40], [50, 55], [10, 55]], "MOCK-MED", 0.99),
            ([[70, 40], [120, 40], [120, 55], [70, 55]], "B-MOCK77", 0.99),
            ([[140, 40], [170, 40], [170, 55], [140, 55]], "250", 0.99),
            ([[190, 40], [220, 40], [220, 55], [190, 55]], "5.50", 0.99),
            ([[240, 40], [270, 40], [270, 55], [240, 55]], "2029-05-15", 0.99),
        ]
        
        mock_reader = MagicMock()
        mock_reader.readtext.return_value = mock_ocr_result
        
        with patch('easyocr.Reader', return_value=mock_reader):
            res = self.app.post('/api/pharmacy/bulk_upload_stock', data={
                'file': (io.BytesIO(b'fake-image-bytes'), 'invoice.png')
            }, content_type='multipart/form-data')
            self.assertEqual(res.status_code, 200)
            data = json.loads(res.data)
            finalize_rows = []
            for r in data['rows']:
                finalize_rows.append({
                    'medicine_name': r['medicine_name']['value'],
                    'batch_number': r['batch_number']['value'],
                    'stock_quantity': r['stock_quantity']['value'],
                    'sale_price': r['sale_price']['value'],
                    'purchase_price': r['purchase_price']['value'],
                    'gst_rate': r['gst_rate']['value'],
                    'expiry_date': r['expiry_date']['value'],
                    'supplier_company': r['supplier_company']['value']
                })
            self.app.post('/api/pharmacy/finalize_bulk_import', 
                          data=json.dumps({'rows': finalize_rows}), 
                          content_type='application/json')
            
        db = get_db()
        item = db.query("SELECT * FROM pharmacy_stock WHERE medicine_name = 'MOCK-MED'", one=True)
        self.assertIsNotNone(item)
        self.assertEqual(item['batch_number'], 'B-MOCK77')
        self.assertEqual(int(item['stock_quantity']), 250)
        self.assertEqual(float(item['sale_price']), 5.50)

    def test_fifo_multiple_batch_deduction(self):
        db = get_db()
        db.query("""
            INSERT INTO pharmacy_stock (medicine_name, batch_number, purchase_price, gst_rate, sale_price, expiry_date, stock_quantity, supplier_company)
            VALUES ('FIFO-MED', 'BATCH-OLD', 10.00, 12.0, 15.00, '2027-01-01', 50, 'Sagar Pharmacy Ltd')
        """, commit=True)
        db.query("""
            INSERT INTO pharmacy_stock (medicine_name, batch_number, purchase_price, gst_rate, sale_price, expiry_date, stock_quantity, supplier_company)
            VALUES ('FIFO-MED', 'BATCH-NEW', 10.00, 12.0, 15.00, '2028-01-01', 100, 'Sagar Pharmacy Ltd')
        """, commit=True)
        
        prescription_id = db.query("""
            INSERT INTO prescriptions (patient_id, medicine_name, duration_days, morning, afternoon, night, dispensed)
            VALUES ('PAT-TEST', 'FIFO-MED', 20, 1, 1, 1, 'No')
        """, commit=True)
        
        res_est = self.app.get(f'/api/pharmacy/estimate_price/{prescription_id}')
        self.assertEqual(res_est.status_code, 200)
        est = json.loads(res_est.data)
        self.assertEqual(est['total_qty'], 60)
        self.assertEqual(est['stock_quantity'], 150)
        self.assertEqual(est['unit_price'], 15.00)
        
        res_disp = self.app.post(f'/api/pharmacy/dispense/{prescription_id}', data={
            'pharmacy_charge': est['grand_total'],
            'payment_method': 'UPI'
        })
        self.assertEqual(res_disp.status_code, 200)
        old_batch = db.query("SELECT stock_quantity FROM pharmacy_stock WHERE batch_number = 'BATCH-OLD'", one=True)
        new_batch = db.query("SELECT stock_quantity FROM pharmacy_stock WHERE batch_number = 'BATCH-NEW'", one=True)
        self.assertEqual(old_batch['stock_quantity'], 0)
        self.assertEqual(new_batch['stock_quantity'], 90)

        # Verify receipt printing output contains Sagar Pharmacy layout tokens
        tx_id = json.loads(res_disp.data)['transaction_id']
        res_print = self.app.get(f'/print_receipt/{tx_id}')
        self.assertEqual(res_print.status_code, 200)
        print_html = res_print.data.decode()
        self.assertIn("SAGAR PHARMACY", print_html)
        self.assertIn("AP/06/03/2017-142466", print_html)
        self.assertIn("37AMCPG5565G1Z1", print_html)
        self.assertIn("MODE :", print_html)
        self.assertIn("TAXABLE", print_html)

    def test_export_stock_csv(self):
        # Insert a medicine item
        db = get_db()
        db.query("DELETE FROM pharmacy_stock WHERE medicine_name = 'EXPORT-TEST'", commit=True)
        db.query("""
            INSERT INTO pharmacy_stock (medicine_name, batch_number, purchase_price, gst_rate, sale_price, expiry_date, stock_quantity, supplier_company)
            VALUES ('EXPORT-TEST', 'B-EXP', 1.50, 18.0, 2.50, '2029-01-01', 200, 'Test Supplier')
        """, commit=True)
        
        # Test download endpoint
        response = self.app.get('/api/pharmacy/export_stock_csv')
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.content_type, 'text/csv')
        
        csv_text = response.data.decode('utf-8')
        self.assertIn('Medicine Name,Batch Number,Current Stock,Quantity to Add,Purchase Price,GST Rate,Sale Price,Expiry Date (YYYY-MM-DD),Supplier Company', csv_text)
        self.assertIn('EXPORT-TEST,B-EXP,200,0,1.5,18,2.5,2029-01-01,Test Supplier', csv_text)

    def test_bulk_upload_xlsx(self):
        import openpyxl
        import io
        
        # Create in-memory workbook
        wb = openpyxl.Workbook()
        ws = wb.active
        
        # Write headers
        ws.append([
            'Medicine Name', 'Batch Number', 'Current Stock', 'Quantity to Add',
            'Purchase Price', 'GST Rate', 'Sale Price', 'Expiry Date (YYYY-MM-DD)', 'Supplier Company'
        ])
        # Write test stock item
        ws.append([
            'XLSX-TEST-MED', 'B-XLSX', 10, 150, 2.00, 12.0, 3.00, '2030-05-20', 'Excel Pharma'
        ])
        
        out = io.BytesIO()
        wb.save(out)
        out.seek(0)
        
        # POST Excel file
        data = {
            'file': (out, 'stock_entry.xlsx')
        }
        res = self.app.post('/api/pharmacy/bulk_upload_stock', data=data, content_type='multipart/form-data')
        self.assertEqual(res.status_code, 200)
        
        res_data = json.loads(res.data)
        self.assertTrue(res_data['success'])
        self.assertGreater(len(res_data['rows']), 0)
        
        # Check first parsed item
        first_row = res_data['rows'][0]
        self.assertEqual(first_row['medicine_name']['value'], 'XLSX-TEST-MED')
        self.assertEqual(first_row['batch_number']['value'], 'B-XLSX')
        self.assertEqual(first_row['stock_quantity']['value'], 150)

if __name__ == '__main__':
    unittest.main()
