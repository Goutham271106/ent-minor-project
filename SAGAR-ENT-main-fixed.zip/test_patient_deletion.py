import unittest
import json
import os
import io
from app import app, get_db

class TestPatientDeletion(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        db = get_db()
        cls.original_sqlite_path = db.sqlite_path
        cls.test_sqlite_path = os.path.join(os.path.dirname(__file__), "test_deletion_db.sqlite")
        db.sqlite_path = cls.test_sqlite_path
        
        # Clean recreate of test DB
        if os.path.exists(cls.test_sqlite_path):
            try:
                os.remove(cls.test_sqlite_path)
            except:
                pass
        db.init_sqlite()

    @classmethod
    def tearDownClass(cls):
        db = get_db()
        db.sqlite_path = cls.original_sqlite_path
        if os.path.exists(cls.test_sqlite_path):
            try:
                os.remove(cls.test_sqlite_path)
            except:
                pass

    def setUp(self):
        self.app = app.test_client()
        self.app.testing = True
        
        # Log in as Admin
        with self.app.session_transaction() as sess:
            sess['logged_in'] = True
            sess['username'] = 'admin'
            sess['role'] = 'Admin'
            
        # Clear tables
        self.db = get_db()
        self.patient_id = 'PAT-TEST-DEL'
        
        self.clean_database()
        self.seed_database()

    def tearDown(self):
        self.clean_database()

    def clean_database(self):
        db = self.db
        p_id = self.patient_id
        try:
            db.query("DELETE FROM pharmacy_bill_items WHERE bill_id IN (SELECT bill_id FROM pharmacy_bills WHERE patient_id = %s)", (p_id,), commit=True)
            db.query("DELETE FROM pharmacy_bills WHERE patient_id = %s", (p_id,), commit=True)
            db.query("DELETE FROM investigation_bill_items WHERE bill_id IN (SELECT bill_id FROM investigation_bills WHERE patient_id = %s)", (p_id,), commit=True)
            db.query("DELETE FROM investigation_bills WHERE patient_id = %s", (p_id,), commit=True)
            db.query("DELETE FROM scribe_sessions WHERE patient_id = %s", (p_id,), commit=True)
            db.query("DELETE FROM patient_custom_sections WHERE patient_id = %s", (p_id,), commit=True)
            db.query("DELETE FROM patient_documents WHERE patient_id = %s", (p_id,), commit=True)
            db.query("DELETE FROM prescriptions WHERE patient_id = %s", (p_id,), commit=True)
            db.query("DELETE FROM consultations WHERE patient_id = %s", (p_id,), commit=True)
            db.query("DELETE FROM payments WHERE patient_id = %s", (p_id,), commit=True)
            db.query("DELETE FROM bills WHERE patient_id = %s", (p_id,), commit=True)
            db.query("DELETE FROM patient_visits WHERE patient_id = %s", (p_id,), commit=True)
            db.query("DELETE FROM patients WHERE patient_id = %s", (p_id,), commit=True)
        except Exception as e:
            print("Cleanup warning:", e)

    def seed_database(self):
        db = self.db
        p_id = self.patient_id
        
        # 1. Patients
        db.query("""
            INSERT INTO patients (patient_id, patient_name, gender, age, address, phone1, final_amount, payment_mode)
            VALUES (%s, 'Test Deletion Patient', 'Male', 40, 'Delete St 1', '9999999999', 500.00, 'Cash')
        """, (p_id,), commit=True)
        
        # 2. Visits
        db.query("INSERT INTO patient_visits (patient_id, fee_charged) VALUES (%s, 500.00)", (p_id,), commit=True)
        
        # 3. Consultations
        c_id = db.query("""
            INSERT INTO consultations (patient_id, complaints, examination, provisional_diagnosis)
            VALUES (%s, 'Test complaint', 'Test exam', 'Test diagnosis')
        """, (p_id,), commit=True)
        
        # 4. Scribe sessions
        db.query("""
            INSERT INTO scribe_sessions (consultation_id, audio_filename, transcript, translated_transcript, clinical_summary, patient_id)
            VALUES (%s, 'audio.wav', 'text', 'text', 'summary', %s)
        """, (c_id, p_id), commit=True)
        
        # 5. Prescriptions
        db.query("INSERT INTO prescriptions (patient_id, medicine_name, duration_days) VALUES (%s, 'Med A', 5)", (p_id,), commit=True)
        
        # 6. General Bills
        b_id = db.query("""
            INSERT INTO bills (patient_id, item_category, description, amount, created_by)
            VALUES (%s, 'Consultation', 'Consultation fee', 500.00, 'reception')
        """, (p_id,), commit=True)
        
        # 7. Payments
        db.query("""
            INSERT INTO payments (patient_id, bill_id, amount_paid, payment_method, received_by)
            VALUES (%s, %s, 500.00, 'Cash', 'reception')
        """, (p_id, b_id), commit=True)
        
        # 8. Investigation Bills and Items
        inv_bill_id = db.query("""
            INSERT INTO investigation_bills (patient_id, subtotal, final_total, payment_status, payment_method, receipt_number)
            VALUES (%s, 400.00, 400.00, 'Paid', 'UPI', 'REC-DEL-01')
        """, (p_id,), commit=True)
        db.query("""
            INSERT INTO investigation_bill_items (bill_id, investigation_name, fee)
            VALUES (%s, 'PTA', 400.00)
        """, (inv_bill_id,), commit=True)
        
        # 9. Pharmacy Bills and Items
        ph_bill_id = db.query("""
            INSERT INTO pharmacy_bills (patient_id, subtotal, final_total, payment_method, payment_status, bill_number)
            VALUES (%s, 150.00, 150.00, 'Cash', 'Paid', 'PH-DEL-01')
        """, (p_id,), commit=True)
        db.query("""
            INSERT INTO pharmacy_bill_items (bill_id, medicine_name, mrp, taxable_rate, total_amount)
            VALUES (%s, 'Med A', 15.00, 13.00, 150.00)
        """, (ph_bill_id,), commit=True)
        
        # 10. Patient custom sections
        db.query("""
            INSERT INTO patient_custom_sections (patient_id, section_title, section_content, display_order, created_by)
            VALUES (%s, 'Custom Sec', 'Content test', 1, 'doctor')
        """, (p_id,), commit=True)
        
        # 11. Patient Documents (mock file on disk)
        self.mock_filepath = os.path.join(os.path.dirname(__file__), "test_doc_delete_temp.txt")
        with open(self.mock_filepath, "w") as f:
            f.write("Mock file content")
            
        db.query("""
            INSERT INTO patient_documents (patient_id, filename, filepath, description)
            VALUES (%s, 'test_doc_delete_temp.txt', %s, 'Temp doc to test deletion')
        """, (p_id, self.mock_filepath), commit=True)

    def test_admin_search_and_profile_access(self):
        # Verify Admin can search
        res = self.app.get(f'/api/doctor/search_patient?query={self.patient_id}')
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)
        self.assertEqual(len(data), 1)
        self.assertEqual(data[0]['patient_id'], self.patient_id)
        
        # Verify Admin can access profile
        res_profile = self.app.get(f'/api/doctor/patient_profile/{self.patient_id}')
        self.assertEqual(res_profile.status_code, 200)
        data_profile = json.loads(res_profile.data)
        self.assertEqual(data_profile['patient']['patient_id'], self.patient_id)

    def test_cascading_patient_deletion(self):
        # Run patient deletion route
        res = self.app.post(f'/api/admin/patients/delete/{self.patient_id}')
        self.assertEqual(res.status_code, 200)
        res_data = json.loads(res.data)
        self.assertTrue(res_data['success'])
        
        db = self.db
        p_id = self.patient_id
        
        # Verify patient records are deleted across all tables
        self.assertIsNone(db.query("SELECT * FROM patients WHERE patient_id = %s", (p_id,), one=True))
        self.assertEqual(len(db.query("SELECT * FROM patient_visits WHERE patient_id = %s", (p_id,))), 0)
        self.assertEqual(len(db.query("SELECT * FROM consultations WHERE patient_id = %s", (p_id,))), 0)
        self.assertEqual(len(db.query("SELECT * FROM scribe_sessions WHERE patient_id = %s", (p_id,))), 0)
        self.assertEqual(len(db.query("SELECT * FROM prescriptions WHERE patient_id = %s", (p_id,))), 0)
        self.assertEqual(len(db.query("SELECT * FROM bills WHERE patient_id = %s", (p_id,))), 0)
        self.assertEqual(len(db.query("SELECT * FROM payments WHERE patient_id = %s", (p_id,))), 0)
        self.assertEqual(len(db.query("SELECT * FROM investigation_bills WHERE patient_id = %s", (p_id,))), 0)
        self.assertEqual(len(db.query("SELECT * FROM pharmacy_bills WHERE patient_id = %s", (p_id,))), 0)
        self.assertEqual(len(db.query("SELECT * FROM patient_custom_sections WHERE patient_id = %s", (p_id,))), 0)
        self.assertEqual(len(db.query("SELECT * FROM patient_documents WHERE patient_id = %s", (p_id,))), 0)
        
        # Verify file is deleted from disk
        self.assertFalse(os.path.exists(self.mock_filepath))

if __name__ == '__main__':
    unittest.main()
