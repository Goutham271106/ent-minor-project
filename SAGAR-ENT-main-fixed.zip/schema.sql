-- Create Database
CREATE DATABASE IF NOT EXISTS trisense_db;
USE trisense_db;

-- 1. Users Table
CREATE TABLE IF NOT EXISTS users (
    user_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role ENUM('Admin', 'Doctor', 'Reception', 'Pharmacy') NOT NULL
);

-- 2. Patients Table
CREATE TABLE IF NOT EXISTS patients (
    patient_id VARCHAR(50) PRIMARY KEY,
    patient_name VARCHAR(100) NOT NULL,
    gender VARCHAR(10) NOT NULL,
    age INT NOT NULL,
    address TEXT NOT NULL,
    phone1 VARCHAR(15) NOT NULL,
    phone2 VARCHAR(15),
    occupation VARCHAR(50),
    consultation_fee DECIMAL(10, 2) DEFAULT 500.00,
    discount_percent DECIMAL(5, 2) DEFAULT 0.00,
    final_amount DECIMAL(10, 2) NOT NULL,
    payment_mode ENUM('Cash', 'Online') NOT NULL,
    registration_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    -- Enhanced Billing Summaries
    total_bill DECIMAL(10, 2) DEFAULT 0.00,
    total_paid DECIMAL(10, 2) DEFAULT 0.00,
    remaining_balance DECIMAL(10, 2) DEFAULT 0.00,
    payment_status VARCHAR(20) DEFAULT 'Pending'
);

-- 3. Patient Visits Table
CREATE TABLE IF NOT EXISTS patient_visits (
    visit_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id VARCHAR(50) NOT NULL,
    visit_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    fee_charged DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE
);

-- 4. Consultations Table
CREATE TABLE IF NOT EXISTS consultations (
    consultation_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id VARCHAR(50) NOT NULL,
    consultation_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    present_illness TEXT,
    past_history TEXT,
    treatment_history TEXT,
    family_history TEXT,
    personal_history TEXT,
    examination TEXT,
    provisional_diagnosis TEXT,
    complaints TEXT,
    investigation_details TEXT,
    surgery_eligible ENUM('Yes', 'No') DEFAULT 'No',
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE
);

-- 5. Prescriptions Table
CREATE TABLE IF NOT EXISTS prescriptions (
    prescription_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id VARCHAR(50) NOT NULL,
    medicine_name VARCHAR(100) NOT NULL,
    duration_days INT NOT NULL,
    morning BOOLEAN DEFAULT FALSE,
    afternoon BOOLEAN DEFAULT FALSE,
    night BOOLEAN DEFAULT FALSE,
    dispensed ENUM('Yes', 'No') DEFAULT 'No',
    food_relation VARCHAR(20) DEFAULT 'After Food',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE
);

-- 6. Standard Investigations List (Reference)
CREATE TABLE IF NOT EXISTS investigations_list (
    investigation_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) UNIQUE NOT NULL,
    default_fee DECIMAL(10, 2) NOT NULL,
    category VARCHAR(100) NOT NULL DEFAULT 'Other'
);

-- 7. Investigation Bills Table
CREATE TABLE IF NOT EXISTS investigation_bills (
    bill_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id VARCHAR(50) NOT NULL,
    subtotal DECIMAL(10, 2) NOT NULL,
    discount DECIMAL(10, 2) DEFAULT 0.00,
    gst DECIMAL(10, 2) DEFAULT 0.00,
    final_total DECIMAL(10, 2) NOT NULL,
    payment_status VARCHAR(20) NOT NULL, -- 'Paid', 'Pending'
    payment_method VARCHAR(50) NOT NULL, -- 'Cash', 'UPI', 'Card', 'Bank Transfer', 'Insurance'
    receipt_number VARCHAR(50) UNIQUE NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE
);

-- 8. Investigation Bill Items Table
CREATE TABLE IF NOT EXISTS investigation_bill_items (
    item_id INT AUTO_INCREMENT PRIMARY KEY,
    bill_id INT NOT NULL,
    investigation_name VARCHAR(100) NOT NULL,
    fee DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (bill_id) REFERENCES investigation_bills(bill_id) ON DELETE CASCADE
);

-- 9. Bills Table (Enhanced Billing Ledger)
CREATE TABLE IF NOT EXISTS bills (
    bill_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id VARCHAR(50) NOT NULL,
    bill_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    item_category VARCHAR(50) NOT NULL, -- 'Consultation', 'Follow-up Consultation', 'Surgery', 'Room', 'Lab', 'Pharmacy', 'Procedure', 'Registration', 'Other'
    description VARCHAR(255) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    created_by VARCHAR(50) NOT NULL,
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE
);

-- 10. Payments Table (Immutable Payment Transactions)
CREATE TABLE IF NOT EXISTS payments (
    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id VARCHAR(50) NOT NULL,
    bill_id INT NULL,
    payment_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    amount_paid DECIMAL(10, 2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL, -- 'Cash', 'UPI', 'Card', 'Bank Transfer', 'Insurance'
    received_by VARCHAR(50) NOT NULL,
    remarks TEXT,
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE,
    FOREIGN KEY (bill_id) REFERENCES bills(bill_id) ON DELETE SET NULL
);

-- 11. Enhanced Hospital Expenses Table
CREATE TABLE IF NOT EXISTS hospital_expenses (
    expense_id INT AUTO_INCREMENT PRIMARY KEY,
    expense_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    category VARCHAR(50) NOT NULL, -- 'Staff Salary', 'Electricity', 'Water', 'Internet', 'Oxygen Cylinders', 'Nitrogen Cylinders', 'Medical Equipment', 'Medicines Purchase', 'Laboratory Materials', 'Cleaning Supplies', 'Stationery', 'Building Maintenance', 'Ambulance Fuel', 'Miscellaneous'
    item_name VARCHAR(100) NOT NULL,
    vendor VARCHAR(100) NOT NULL,
    description VARCHAR(255) NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL, -- quantity * unit_price
    payment_method VARCHAR(50) NOT NULL,
    invoice_number VARCHAR(50),
    created_by VARCHAR(50) NOT NULL,
    remarks TEXT,
    attachment_path VARCHAR(255)
);

-- 12. Audit Logs Table
CREATE TABLE IF NOT EXISTS audit_logs (
    log_id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL,
    action TEXT NOT NULL,
    log_date DATE NOT NULL,
    log_time TIME NOT NULL,
    old_value TEXT,
    new_value TEXT
);

-- ==================================================
-- SEED DATA
-- ==================================================

-- Insert Default Users
INSERT INTO users (username, password, role) VALUES
('admin', 'admin123', 'Admin'),
('doctor', 'doctor123', 'Doctor'),
('reception', 'reception123', 'Reception'),
('pharmacy', 'pharmacy123', 'Pharmacy')
ON DUPLICATE KEY UPDATE role=VALUES(role);

-- Seed Reference Investigations
INSERT INTO investigations_list (name, default_fee) VALUES
('FLP', 400.00),
('FLB', 500.00),
('VFT', 300.00),
('Blood Test', 250.00),
('Audiometry', 600.00),
('PTA', 500.00),
('Impedance', 400.00),
('Speech Audiometry', 500.00),
('OAE', 600.00),
('BERA', 1200.00),
('CT', 2500.00),
('MRI', 5000.00),
('X-Ray', 400.00),
('Ultrasound', 800.00)
ON DUPLICATE KEY UPDATE default_fee=VALUES(default_fee);

-- Seed Expenses
INSERT INTO hospital_expenses (category, item_name, vendor, description, quantity, unit_price, amount, expense_date, payment_method, invoice_number, created_by, remarks) VALUES
('Laboratory Materials', 'Surgical gloves and masks', 'Medipus Supplies', 'Replenishment for ENT clinic', 5, 250.00, 1250.00, NOW(), 'Cash', 'INV-2026-001', 'admin', 'Urgent stock needed'),
('Medical Equipment', 'EUA maintenance kit', 'ENT Tech Solutions', 'ENT equipment maintenance service', 1, 4500.00, 4500.00, NOW() - INTERVAL 1 DAY, 'Bank Transfer', 'INV-2026-002', 'admin', 'Annual service contract'),
('Internet', 'Broadband subscription', 'Airtel Broadband', 'Internet connection subscription', 1, 999.00, 999.00, NOW() - INTERVAL 2 DAY, 'Card', 'INV-2026-003', 'admin', 'Monthly billing'),
('Stationery', 'Prescription pads', 'Lotus Stationers', 'Registers and prescription pads', 10, 75.00, 750.00, NOW(), 'Cash', 'INV-2026-004', 'admin', ''),
('Staff Salary', 'Salary Receptionist', 'Receptionist Staff', 'Salary June', 1, 15000.00, 15000.00, NOW() - INTERVAL 15 DAY, 'Bank Transfer', 'SAL-2026-06', 'admin', 'Full month salary');

-- Seed Sample Patient 1 (Follow-up Expired)
INSERT INTO patients (patient_id, patient_name, gender, age, address, phone1, phone2, occupation, consultation_fee, discount_percent, final_amount, payment_mode, registration_date, total_bill, total_paid, remaining_balance, payment_status) VALUES
('PAT-001', 'John Doe', 'Male', 45, '12 Baker Street, London', '9876543210', '9876543211', 'Engineer', 500.00, 10.00, 450.00, 'Cash', NOW() - INTERVAL 20 DAY, 450.00, 450.00, 0.00, 'Paid');

INSERT INTO patient_visits (patient_id, visit_date, fee_charged) VALUES
('PAT-001', NOW() - INTERVAL 20 DAY, 450.00);

INSERT INTO consultations (patient_id, consultation_date, present_illness, past_history, treatment_history, family_history, personal_history, examination, provisional_diagnosis, complaints, investigation_details, surgery_eligible) VALUES
('PAT-001', NOW() - INTERVAL 20 DAY, 'Slight throat irritation', 'None', 'None', 'None', 'Normal', 'Congestion in throat', 'Pharyngitis', 'Sore Throat;Cough', 'Blood Test', 'No');

INSERT INTO prescriptions (patient_id, medicine_name, duration_days, morning, afternoon, night, dispensed, created_at) VALUES
('PAT-001', 'Amoxicillin 500mg', 5, TRUE, TRUE, TRUE, 'Yes', NOW() - INTERVAL 20 DAY),
('PAT-001', 'Paracetamol 650mg', 3, TRUE, FALSE, TRUE, 'Yes', NOW() - INTERVAL 20 DAY);

INSERT INTO bills (bill_id, patient_id, bill_date, item_category, description, amount, created_by) VALUES
(1, 'PAT-001', NOW() - INTERVAL 20 DAY, 'Consultation', 'Initial Consultation Fee (10% Discount applied)', 450.00, 'reception');

INSERT INTO payments (transaction_id, patient_id, bill_id, payment_date, amount_paid, payment_method, received_by, remarks) VALUES
(1, 'PAT-001', 1, NOW() - INTERVAL 20 DAY, 450.00, 'Cash', 'reception', 'Initial registration payment');


-- Seed Sample Patient 2 (Follow-up Valid, has 1 visit registered, registered 3 days ago)
INSERT INTO patients (patient_id, patient_name, gender, age, address, phone1, phone2, occupation, consultation_fee, discount_percent, final_amount, payment_mode, registration_date, total_bill, total_paid, remaining_balance, payment_status) VALUES
('PAT-002', 'Jane Smith', 'Female', 29, '45 Ring Road, Bangalore', '8887776665', '', 'Teacher', 500.00, 0.00, 500.00, 'Online', NOW() - INTERVAL 3 DAY, 500.00, 500.00, 0.00, 'Paid');

INSERT INTO patient_visits (patient_id, visit_date, fee_charged) VALUES
('PAT-002', NOW() - INTERVAL 3 DAY, 500.00);

INSERT INTO consultations (patient_id, consultation_date, present_illness, past_history, treatment_history, family_history, personal_history, examination, provisional_diagnosis, complaints, investigation_details, surgery_eligible) VALUES
('PAT-002', NOW() - INTERVAL 3 DAY, 'Nose bleed at night', 'Hypertension', 'On amlodipine', 'None', 'Normal', 'Dry nasal mucosa with crusting', 'Epistaxis', 'Nose Bleeding;Nasal Blockage', 'Blood Test;CT', 'No');

INSERT INTO prescriptions (patient_id, medicine_name, duration_days, morning, afternoon, night, dispensed, created_at) VALUES
('PAT-002', 'Nasal Moisturing Spray', 10, TRUE, TRUE, TRUE, 'No', NOW() - INTERVAL 3 DAY);

INSERT INTO bills (bill_id, patient_id, bill_date, item_category, description, amount, created_by) VALUES
(2, 'PAT-002', NOW() - INTERVAL 3 DAY, 'Consultation', 'Initial Consultation Fee', 500.00, 'reception');

INSERT INTO payments (transaction_id, patient_id, bill_id, payment_date, amount_paid, payment_method, received_by, remarks) VALUES
(2, 'PAT-002', 2, NOW() - INTERVAL 3 DAY, 500.00, 'UPI', 'reception', 'Paid online at registration');


-- Seed Sample Patient 3 (Follow-up Limit Exceeded, 2 visits registered, registered 5 days ago)
INSERT INTO patients (patient_id, patient_name, gender, age, address, phone1, phone2, occupation, consultation_fee, discount_percent, final_amount, payment_mode, registration_date, total_bill, total_paid, remaining_balance, payment_status) VALUES
('PAT-003', 'Robert C.', 'Male', 52, '88 Residency Heights, Delhi', '9998887776', '9998887777', 'Business Owner', 500.00, 0.00, 500.00, 'Online', NOW() - INTERVAL 5 DAY, 500.00, 500.00, 0.00, 'Paid');

INSERT INTO patient_visits (patient_id, visit_date, fee_charged) VALUES
('PAT-003', NOW() - INTERVAL 5 DAY, 500.00),
('PAT-003', NOW() - INTERVAL 3 DAY, 0.00); 

INSERT INTO consultations (patient_id, consultation_date, present_illness, past_history, treatment_history, family_history, personal_history, examination, provisional_diagnosis, complaints, investigation_details, surgery_eligible) VALUES
('PAT-003', NOW() - INTERVAL 5 DAY, 'Tinnitus in left ear', 'Diabetes', 'Metformin', 'None', 'Normal', 'Retracted tympanic membrane', 'Eustachian Tube Dysfunction', 'Ear Pain;Tinnitus;Ear Block', 'Audiometry;PTA;Impedance', 'Yes');

INSERT INTO bills (bill_id, patient_id, bill_date, item_category, description, amount, created_by) VALUES
(3, 'PAT-003', NOW() - INTERVAL 5 DAY, 'Consultation', 'Initial Consultation Fee', 500.00, 'reception'),
(4, 'PAT-003', NOW() - INTERVAL 3 DAY, 'Follow-up Consultation', 'Follow-up (Free Visit 2 of 2)', 0.00, 'reception');

INSERT INTO payments (transaction_id, patient_id, bill_id, payment_date, amount_paid, payment_method, received_by, remarks) VALUES
(3, 'PAT-003', 3, NOW() - INTERVAL 5 DAY, 500.00, 'UPI', 'reception', 'Paid online at registration');


-- Seed Sample Patient 4 (Partially Paid / Outstanding balance for tests and rooms)
INSERT INTO patients (patient_id, patient_name, gender, age, address, phone1, phone2, occupation, consultation_fee, discount_percent, final_amount, payment_mode, registration_date, total_bill, total_paid, remaining_balance, payment_status) VALUES
('PAT-004', 'Mary Cooper', 'Female', 63, '34 Baker St, London', '7776665554', '', 'Retired', 500.00, 0.00, 500.00, 'Cash', NOW() - INTERVAL 2 DAY, 5500.00, 2500.00, 3000.00, 'Partially Paid');

INSERT INTO patient_visits (patient_id, visit_date, fee_charged) VALUES
('PAT-004', NOW() - INTERVAL 2 DAY, 500.00);

INSERT INTO consultations (patient_id, consultation_date, present_illness, past_history, treatment_history, family_history, personal_history, examination, provisional_diagnosis, complaints, investigation_details, surgery_eligible) VALUES
('PAT-004', NOW() - INTERVAL 2 DAY, 'Difficulty swallowing', 'Heart disease', 'Aspirin', 'None', 'Normal', 'Redness and swelling in pharynx', 'Tonsillitis', 'Sore Throat;Difficulty Swallowing', 'Blood Test', 'Yes');

INSERT INTO bills (bill_id, patient_id, bill_date, item_category, description, amount, created_by) VALUES
(5, 'PAT-004', NOW() - INTERVAL 2 DAY, 'Consultation', 'Initial Consultation Fee', 500.00, 'reception'),
(6, 'PAT-004', NOW() - INTERVAL 2 DAY, 'Surgery', 'Tonsillectomy Surgery Charge', 4000.00, 'doctor'),
(7, 'PAT-004', NOW() - INTERVAL 2 DAY, 'Room', 'Daycare Recovery Ward Room Rent', 1000.00, 'reception');

INSERT INTO payments (transaction_id, patient_id, bill_id, payment_date, amount_paid, payment_method, received_by, remarks) VALUES
(4, 'PAT-004', 5, NOW() - INTERVAL 2 DAY, 500.00, 'Cash', 'reception', 'Paid for consultation'),
(5, 'PAT-004', 6, NOW() - INTERVAL 1 DAY, 2000.00, 'Bank Transfer', 'reception', 'Partial advance for surgery');

-- Seed Standard Audit Logs
INSERT INTO audit_logs (username, action, log_date, log_time, old_value, new_value) VALUES
('admin', 'Seeded default clinic values and database indexes', CURRENT_DATE(), '10:00:00', NULL, 'Database Schema V2 initialized');

-- 15. Pharmacy Stock Table
CREATE TABLE IF NOT EXISTS pharmacy_stock (
    medicine_id INT AUTO_INCREMENT PRIMARY KEY,
    medicine_name VARCHAR(255) NOT NULL,
    batch_number VARCHAR(100) NOT NULL DEFAULT 'B-GEN',
    purchase_price DECIMAL(10, 2) NOT NULL,
    gst_rate DECIMAL(5, 2) NOT NULL DEFAULT 12.00,
    sale_price DECIMAL(10, 2) NOT NULL,
    expiry_date DATE NOT NULL,
    stock_quantity INT NOT NULL DEFAULT 0,
    supplier_company VARCHAR(255) NOT NULL,
    UNIQUE(medicine_name, batch_number)
);
