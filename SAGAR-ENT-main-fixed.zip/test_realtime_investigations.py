import unittest
import json
import os
import queue
from app import app, get_db, reception_listeners, notify_reception_update

class TestRealtimeInvestigations(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        db = get_db()
        cls.original_sqlite_path = db.sqlite_path
        cls.test_sqlite_path = os.path.join(os.path.dirname(__file__), "test_realtime_investigations_db.sqlite")
        db.sqlite_path = cls.test_sqlite_path
        
        # Clean recreate of test DB
        if os.path.exists(cls.test_sqlite_path):
            try:
                os.remove(cls.test_sqlite_path)
            except:
                pass
        db.init_sqlite()

    @classmethod
    def tearDownClass(cls):
        db = get_db()
        db.sqlite_path = cls.original_sqlite_path
        if os.path.exists(cls.test_sqlite_path):
            try:
                os.remove(cls.test_sqlite_path)
            except:
                pass

    def setUp(self):
        self.app = app.test_client()
        self.app.testing = True
        
        # Log in as admin to have access to doctor/reception endpoints
        with self.app.session_transaction() as sess:
            sess['logged_in'] = True
            sess['username'] = 'admin'
            sess['role'] = 'Admin'
            
        db = get_db()
        db.query("DELETE FROM payments", commit=True)
        db.query("DELETE FROM bills", commit=True)
        db.query("DELETE FROM prescriptions", commit=True)
        db.query("DELETE FROM consultations", commit=True)
        db.query("DELETE FROM patient_visits", commit=True)
        db.query("DELETE FROM patients WHERE patient_id = 'PAT-RT-TEST'", commit=True)
        
        # Seed standard investigations list
        db.query("DELETE FROM investigations_list", commit=True)
        db.query("INSERT INTO investigations_list (name, default_fee) VALUES ('Blood Test', 250.00)", commit=True)
        db.query("INSERT INTO investigations_list (name, default_fee) VALUES ('CT Scan', 1500.00)", commit=True)
        
        # Seed a test patient
        db.query("""
            INSERT INTO patients (patient_id, patient_name, gender, age, address, phone1, final_amount, payment_mode)
            VALUES ('PAT-RT-TEST', 'Realtime Test Patient', 'Male', 28, 'Registry Road', '9999999999', 500.00, 'Cash')
        """, commit=True)

    def tearDown(self):
        db = get_db()
        try:
            db.query("DELETE FROM payments", commit=True)
            db.query("DELETE FROM bills", commit=True)
            db.query("DELETE FROM prescriptions", commit=True)
            db.query("DELETE FROM consultations", commit=True)
            db.query("DELETE FROM patient_visits", commit=True)
            db.query("DELETE FROM patients WHERE patient_id = 'PAT-RT-TEST'", commit=True)
        except:
            pass

    def test_pending_investigation_lifecycle(self):
        # 1. Verify initially no pending investigations
        res = self.app.get('/api/reception/pending_investigations')
        self.assertEqual(res.status_code, 200)
        data = json.loads(res.data)
        self.assertEqual(len(data), 0)
        
        # 2. Add consultation with investigations as doctor
        # We need doctor session first
        with self.app.session_transaction() as sess:
            sess['role'] = 'Doctor'
            sess['username'] = 'doctor'
            
        res_add = self.app.post('/api/doctor/add_consultation', data={
            'patient_id': 'PAT-RT-TEST',
            'present_illness': 'Fever',
            'examination': 'Temperature high',
            'provisional_diagnosis': 'Viral Fever',
            'surgery_eligible': 'No',
            'investigations[]': ['Blood Test', 'CT Scan']
        })
        self.assertEqual(res_add.status_code, 200)
        self.assertTrue(json.loads(res_add.data)['success'])
        
        # 3. Retrieve pending investigations in reception (must now have the test patient)
        with self.app.session_transaction() as sess:
            sess['role'] = 'Reception'
            sess['username'] = 'reception'
            
        res_pending = self.app.get('/api/reception/pending_investigations')
        self.assertEqual(res_pending.status_code, 200)
        pending_data = json.loads(res_pending.data)
        self.assertEqual(len(pending_data), 1)
        self.assertEqual(pending_data[0]['patient_id'], 'PAT-RT-TEST')
        self.assertEqual(pending_data[0]['investigation_details'], 'Blood Test;CT Scan')
        
        # 4. Bill the investigations as reception
        bill_res = self.app.post('/api/reception/add_investigation_bill', json={
            'patient_id': 'PAT-RT-TEST',
            'investigations': ['Blood Test', 'CT Scan'],
            'discount_type': 'percent',
            'discount_value': 0,
            'gst_enabled': False,
            'payment_status': 'Paid',
            'payment_method': 'Cash'
        })
        self.assertEqual(bill_res.status_code, 200)
        self.assertTrue(json.loads(bill_res.data)['success'])
        
        # 5. Retrieve pending investigations (must be 0 now since they are billed)
        res_pending2 = self.app.get('/api/reception/pending_investigations')
        self.assertEqual(res_pending2.status_code, 200)
        pending_data2 = json.loads(res_pending2.data)
        self.assertEqual(len(pending_data2), 0)

    def test_sse_stream_and_listener_notification(self):
        # 1. Test stream endpoint initial state
        res_stream = self.app.get('/api/reception/pending_investigations_stream')
        self.assertEqual(res_stream.status_code, 200)
        self.assertEqual(res_stream.mimetype, 'text/event-stream')
        
        # Verify it yielded initial payload
        stream_iter = res_stream.response
        first_event = next(stream_iter)
        self.assertTrue(first_event.startswith(b"data: "))
        initial_data = json.loads(first_event.decode('utf-8').replace("data: ", "").strip())
        self.assertEqual(len(initial_data), 0)
        
        # 2. Test in-memory listener notification
        test_q = queue.Queue()
        reception_listeners.append(test_q)
        
        try:
            # Seed a consultation to make sure data changes
            db = get_db()
            db.query("""
                INSERT INTO consultations (patient_id, investigation_details, consultation_date, surgery_eligible)
                VALUES ('PAT-RT-TEST', 'Blood Test', NOW(), 'No')
            """, commit=True)
            
            # Trigger notifier
            notify_reception_update()
            
            # Fetch from queue (must succeed and have 1 item)
            notified_data_str = test_q.get(timeout=2)
            notified_data = json.loads(notified_data_str)
            self.assertEqual(len(notified_data), 1)
            self.assertEqual(notified_data[0]['patient_id'], 'PAT-RT-TEST')
            self.assertEqual(notified_data[0]['investigation_details'], 'Blood Test')
        finally:
            reception_listeners.remove(test_q)

if __name__ == '__main__':
    unittest.main()
