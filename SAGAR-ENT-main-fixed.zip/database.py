import os
import sqlite3
import datetime
from flask import current_app, g

# SQLite schema equivalent to schema.sql
SQLITE_SCHEMA = """
-- 1. Users Table
CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL
);

-- 2. Patients Table
CREATE TABLE IF NOT EXISTS patients (
    patient_id VARCHAR(50) PRIMARY KEY,
    patient_name VARCHAR(100) NOT NULL,
    gender VARCHAR(10) NOT NULL,
    age INT NOT NULL,
    address TEXT NOT NULL,
    phone1 VARCHAR(15) NOT NULL,
    phone2 VARCHAR(15),
    occupation VARCHAR(50),
    consultation_fee DECIMAL(10, 2) DEFAULT 500.00,
    discount_percent DECIMAL(5, 2) DEFAULT 0.00,
    final_amount DECIMAL(10, 2) NOT NULL,
    payment_mode VARCHAR(20) NOT NULL,
    registration_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    
    total_bill DECIMAL(10, 2) DEFAULT 0.00,
    total_paid DECIMAL(10, 2) DEFAULT 0.00,
    remaining_balance DECIMAL(10, 2) DEFAULT 0.00,
    payment_status VARCHAR(20) DEFAULT 'Pending'
);

-- 3. Patient Visits Table
CREATE TABLE IF NOT EXISTS patient_visits (
    visit_id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id VARCHAR(50) NOT NULL,
    visit_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    fee_charged DECIMAL(10, 2) NOT NULL,
    viewed BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE
);

-- 4. Consultations Table
CREATE TABLE IF NOT EXISTS consultations (
    consultation_id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id VARCHAR(50) NOT NULL,
    consultation_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    present_illness TEXT,
    past_history TEXT,
    treatment_history TEXT,
    family_history TEXT,
    personal_history TEXT,
    examination TEXT,
    provisional_diagnosis TEXT,
    complaints TEXT,
    investigation_details TEXT,
    surgery_eligible VARCHAR(5) DEFAULT 'No',
    investigation_billed INTEGER DEFAULT 0,
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE
);

-- 5. Prescriptions Table
CREATE TABLE IF NOT EXISTS prescriptions (
    prescription_id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id VARCHAR(50) NOT NULL,
    consultation_id INTEGER,
    medicine_name VARCHAR(100) NOT NULL,
    duration_days INT NOT NULL,
    morning BOOLEAN DEFAULT FALSE,
    afternoon BOOLEAN DEFAULT FALSE,
    night BOOLEAN DEFAULT FALSE,
    dispensed VARCHAR(5) DEFAULT 'No',
    dispensed_at DATETIME,
    food_relation VARCHAR(20) DEFAULT 'After Food',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE
);

-- 6. Standard Investigations List (Reference)
CREATE TABLE IF NOT EXISTS investigations_list (
    investigation_id INTEGER PRIMARY KEY AUTOINCREMENT,
    name VARCHAR(100) UNIQUE NOT NULL,
    default_fee DECIMAL(10, 2) NOT NULL,
    category VARCHAR(100) NOT NULL DEFAULT 'Other'
);

-- 7. Investigation Bills Table
CREATE TABLE IF NOT EXISTS investigation_bills (
    bill_id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id VARCHAR(50) NOT NULL,
    subtotal DECIMAL(10, 2) NOT NULL,
    discount DECIMAL(10, 2) DEFAULT 0.00,
    gst DECIMAL(10, 2) DEFAULT 0.00,
    final_total DECIMAL(10, 2) NOT NULL,
    payment_status VARCHAR(20) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    receipt_number VARCHAR(50) UNIQUE NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE
);

-- 8. Investigation Bill Items Table
CREATE TABLE IF NOT EXISTS investigation_bill_items (
    item_id INTEGER PRIMARY KEY AUTOINCREMENT,
    bill_id INTEGER NOT NULL,
    investigation_name VARCHAR(100) NOT NULL,
    fee DECIMAL(10, 2) NOT NULL,
    FOREIGN KEY (bill_id) REFERENCES investigation_bills(bill_id) ON DELETE CASCADE
);

-- 9. Bills Table (Enhanced Billing Ledger)
CREATE TABLE IF NOT EXISTS bills (
    bill_id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id VARCHAR(50) NOT NULL,
    bill_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    item_category VARCHAR(50) NOT NULL,
    description VARCHAR(255) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    created_by VARCHAR(50) NOT NULL,
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE
);

-- 10. Payments Table (Immutable Payment Transactions)
CREATE TABLE IF NOT EXISTS payments (
    transaction_id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id VARCHAR(50) NOT NULL,
    bill_id INTEGER,
    payment_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    amount_paid DECIMAL(10, 2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    received_by VARCHAR(50) NOT NULL,
    remarks TEXT,
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE,
    FOREIGN KEY (bill_id) REFERENCES bills(bill_id) ON DELETE SET NULL
);

-- 11. Enhanced Hospital Expenses Table
CREATE TABLE IF NOT EXISTS hospital_expenses (
    expense_id INTEGER PRIMARY KEY AUTOINCREMENT,
    expense_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    category VARCHAR(50) NOT NULL,
    item_name VARCHAR(100) NOT NULL,
    vendor VARCHAR(100) NOT NULL,
    description VARCHAR(255) NOT NULL,
    quantity INT NOT NULL,
    unit_price DECIMAL(10, 2) NOT NULL,
    amount DECIMAL(10, 2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL,
    invoice_number VARCHAR(50),
    created_by VARCHAR(50) NOT NULL,
    remarks TEXT,
    attachment_path VARCHAR(255)
);

-- 12. Audit Logs Table
CREATE TABLE IF NOT EXISTS audit_logs (
    log_id INTEGER PRIMARY KEY AUTOINCREMENT,
    username VARCHAR(50) NOT NULL,
    action TEXT NOT NULL,
    log_date DATE NOT NULL,
    log_time TIME NOT NULL,
    old_value TEXT,
    new_value TEXT
);

-- 13. Scribe Sessions Table
CREATE TABLE IF NOT EXISTS scribe_sessions (
    session_id INTEGER PRIMARY KEY AUTOINCREMENT,
    consultation_id INTEGER,
    audio_filename VARCHAR(255),
    transcript TEXT NOT NULL,
    translated_transcript TEXT NOT NULL,
    clinical_summary TEXT NOT NULL,
    patient_id VARCHAR(50),
    doctor_username VARCHAR(50),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (consultation_id) REFERENCES consultations(consultation_id) ON DELETE CASCADE
);

-- 14. Patient Custom Sections Table
CREATE TABLE IF NOT EXISTS patient_custom_sections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id VARCHAR(50) NOT NULL,
    consultation_id INTEGER,
    section_title VARCHAR(255) NOT NULL,
    section_content TEXT,
    display_order INTEGER NOT NULL,
    created_by VARCHAR(50) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    is_deleted INTEGER DEFAULT 0,
    is_important INTEGER DEFAULT 0,
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id),
    FOREIGN KEY (consultation_id) REFERENCES consultations(consultation_id) ON DELETE CASCADE
);

-- 15. Pharmacy Stock Table
CREATE TABLE IF NOT EXISTS pharmacy_stock (
    medicine_id INTEGER PRIMARY KEY AUTOINCREMENT,
    medicine_name VARCHAR(255) NOT NULL,
    batch_number VARCHAR(100) NOT NULL DEFAULT 'B-GEN',
    purchase_price DECIMAL(10, 2) NOT NULL,
    gst_rate DECIMAL(5, 2) NOT NULL DEFAULT 12.00,
    sale_price DECIMAL(10, 2) NOT NULL,
    expiry_date DATE NOT NULL,
    stock_quantity INTEGER NOT NULL DEFAULT 0,
    supplier_company VARCHAR(255) NOT NULL,
    UNIQUE(medicine_name, batch_number)
);

-- 16. Pharmacy Bills Table
CREATE TABLE IF NOT EXISTS pharmacy_bills (
    bill_id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id VARCHAR(50) NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    discount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    cgst DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    sgst DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    final_total DECIMAL(10,2) NOT NULL,
    payment_method VARCHAR(50) NOT NULL DEFAULT 'Cash',
    payment_status VARCHAR(50) NOT NULL DEFAULT 'Paid',
    bill_number VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(100)
);

-- 17. Pharmacy Bill Items Table
CREATE TABLE IF NOT EXISTS pharmacy_bill_items (
    item_id INTEGER PRIMARY KEY AUTOINCREMENT,
    bill_id INTEGER NOT NULL,
    medicine_name VARCHAR(255) NOT NULL,
    manufacturer VARCHAR(100) DEFAULT 'GEN',
    batch_number VARCHAR(100) DEFAULT 'B-GEN',
    expiry_date VARCHAR(50),
    quantity DECIMAL(10,2) NOT NULL DEFAULT 1.0,
    mrp DECIMAL(10,2) NOT NULL,
    taxable_rate DECIMAL(10,2) NOT NULL,
    discount_percent DECIMAL(5,2) DEFAULT 0.0,
    gst_rate DECIMAL(5,2) DEFAULT 12.0,
    cgst_percent DECIMAL(5,2) DEFAULT 6.0,
    sgst_percent DECIMAL(5,2) DEFAULT 6.0,
    cgst_amount DECIMAL(10,2) DEFAULT 0.00,
    sgst_amount DECIMAL(10,2) DEFAULT 0.00,
    total_amount DECIMAL(10,2) NOT NULL
);

-- 18. Patient Documents Table
CREATE TABLE IF NOT EXISTS patient_documents (
    document_id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id VARCHAR(50) NOT NULL,
    filename VARCHAR(255) NOT NULL,
    filepath VARCHAR(500) NOT NULL,
    description VARCHAR(255),
    uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE
);
"""

def dict_factory(cursor, row):
    d = {}
    for idx, col in enumerate(cursor.description):
        d[col[0]] = row[idx]
    return d

class DBWrapper:
    _investigations_synced = False

    def _connect_sqlite(self):
        return sqlite3.connect(self.sqlite_path, timeout=30.0)

    def __init__(self, mysql_instance=None):
        self.mysql = mysql_instance
        self.use_sqlite = False
        
        is_vercel = (
            os.environ.get('VERCEL') == '1' or 
            os.environ.get('VERCEL_ENV') is not None or
            'AWS_LAMBDA_FUNCTION_NAME' in os.environ or
            os.environ.get('LAMBDA_TASK_ROOT') is not None or
            os.path.exists('/var/task')
        )
        if is_vercel:
            self.sqlite_path = "/tmp/trisense_db.sqlite"
            original_db_path = os.path.join(os.path.dirname(__file__), "trisense_db.sqlite")
            
            # Atomic copy to prevent race conditions during concurrent cold starts
            if not os.path.exists(self.sqlite_path):
                if os.path.exists(original_db_path):
                    import shutil
                    import tempfile
                    try:
                        fd, temp_path = tempfile.mkstemp(dir="/tmp", prefix="trisense_db_", suffix=".tmp")
                        os.close(fd)
                        shutil.copy2(original_db_path, temp_path)
                        os.replace(temp_path, self.sqlite_path)
                    except Exception as e:
                        print("Failed to copy database to /tmp:", e)
        else:
            self.sqlite_path = os.path.join(os.path.dirname(__file__), "trisense_db.sqlite")
        
        # Test if MySQL can be used; if not, we use SQLite
        if not self.mysql:
            self.use_sqlite = True

            # Check if sqlite file needs initialization or migrations
            need_init = True
            mig_conn = None
            try:
                if os.path.exists(self.sqlite_path):
                    mig_conn = self._connect_sqlite()
                    mig_cursor = mig_conn.cursor()
                    try:
                        mig_cursor.execute("SELECT COUNT(*) FROM users")
                        need_init = False
                    except Exception:
                        pass
            except Exception:
                pass

            if need_init:
                if mig_conn:
                    try:
                        mig_conn.close()
                    except Exception:
                        pass
                    mig_conn = None
                # Database is invalid or missing, delete file and initialize it fresh
                try:
                    if os.path.exists(self.sqlite_path):
                        os.remove(self.sqlite_path)
                except Exception:
                    pass
                self.init_sqlite()
            else:
                # Run local migrations and synchronization in a single connection to avoid locks
                try:
                    mig_cursor = mig_conn.cursor()
                    
                    # 1. Category migration check
                    mig_cursor.execute("PRAGMA table_info(investigations_list)")
                    cols = [col[1] for col in mig_cursor.fetchall()]
                    if 'category' not in cols:
                        mig_cursor.execute("ALTER TABLE investigations_list ADD COLUMN category VARCHAR(100) NOT NULL DEFAULT 'Other'")
                    
                    # 2. Scribe Sessions table check
                    mig_cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='scribe_sessions'")
                    if not mig_cursor.fetchone():
                        mig_cursor.execute("""
                            CREATE TABLE IF NOT EXISTS scribe_sessions (
                                session_id INTEGER PRIMARY KEY AUTOINCREMENT,
                                consultation_id INTEGER,
                                audio_filename VARCHAR(255),
                                transcript TEXT NOT NULL,
                                translated_transcript TEXT NOT NULL,
                                clinical_summary TEXT NOT NULL,
                                patient_id VARCHAR(50),
                                doctor_username VARCHAR(50),
                                created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                                FOREIGN KEY (consultation_id) REFERENCES consultations(consultation_id) ON DELETE CASCADE
                            );
                        """)
                    else:
                        mig_cursor.execute("PRAGMA table_info(scribe_sessions)")
                        cols_scribe = [col[1] for col in mig_cursor.fetchall()]
                        if 'patient_id' not in cols_scribe:
                            mig_cursor.execute("ALTER TABLE scribe_sessions ADD COLUMN patient_id VARCHAR(50)")
                        if 'doctor_username' not in cols_scribe:
                            mig_cursor.execute("ALTER TABLE scribe_sessions ADD COLUMN doctor_username VARCHAR(50)")

                    # 3. Prescriptions table check
                    mig_cursor.execute("PRAGMA table_info(prescriptions)")
                    cols_presc = [col[1] for col in mig_cursor.fetchall()]
                    if 'dispensed_at' not in cols_presc:
                        mig_cursor.execute("ALTER TABLE prescriptions ADD COLUMN dispensed_at DATETIME")
                    if 'food_relation' not in cols_presc:
                        mig_cursor.execute("ALTER TABLE prescriptions ADD COLUMN food_relation VARCHAR(20) DEFAULT 'After Food'")

                    # 4. Pharmacy Stock table check
                    mig_cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='pharmacy_stock'")
                    if not mig_cursor.fetchone():
                        mig_cursor.execute("""
                            CREATE TABLE IF NOT EXISTS pharmacy_stock (
                                medicine_id INTEGER PRIMARY KEY AUTOINCREMENT,
                                medicine_name VARCHAR(255) NOT NULL,
                                batch_number VARCHAR(100) NOT NULL DEFAULT 'B-GEN',
                                purchase_price DECIMAL(10, 2) NOT NULL,
                                gst_rate DECIMAL(5, 2) NOT NULL DEFAULT 12.00,
                                sale_price DECIMAL(10, 2) NOT NULL,
                                expiry_date DATE NOT NULL,
                                stock_quantity INTEGER NOT NULL DEFAULT 0,
                                supplier_company VARCHAR(255) NOT NULL,
                                UNIQUE(medicine_name, batch_number)
                            );
                        """)
                    else:
                        mig_cursor.execute("PRAGMA table_info(pharmacy_stock)")
                        cols_stock = [col[1] for col in mig_cursor.fetchall()]
                        if 'batch_number' not in cols_stock:
                            mig_cursor.execute("ALTER TABLE pharmacy_stock ADD COLUMN batch_number VARCHAR(100) NOT NULL DEFAULT 'B-GEN'")

                    # 5. Consultations table check
                    mig_cursor.execute("PRAGMA table_info(consultations)")
                    cols_cons = [col[1] for col in mig_cursor.fetchall()]
                    if 'investigation_billed' not in cols_cons:
                        mig_cursor.execute("ALTER TABLE consultations ADD COLUMN investigation_billed INTEGER DEFAULT 0")

                    # 6. Pharmacy Bills table check
                    mig_cursor.execute("""
                    CREATE TABLE IF NOT EXISTS pharmacy_bills (
                        bill_id INTEGER PRIMARY KEY AUTOINCREMENT,
                        patient_id VARCHAR(50) NOT NULL,
                        subtotal DECIMAL(10,2) NOT NULL,
                        discount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                        cgst DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                        sgst DECIMAL(10,2) NOT NULL DEFAULT 0.00,
                        final_total DECIMAL(10,2) NOT NULL,
                        payment_method VARCHAR(50) NOT NULL DEFAULT 'Cash',
                        payment_status VARCHAR(50) NOT NULL DEFAULT 'Paid',
                        bill_number VARCHAR(100) NOT NULL,
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                        created_by VARCHAR(100)
                    )
                    """)

                    # 7. Pharmacy Bill Items table check
                    mig_cursor.execute("""
                    CREATE TABLE IF NOT EXISTS pharmacy_bill_items (
                        item_id INTEGER PRIMARY KEY AUTOINCREMENT,
                        bill_id INTEGER NOT NULL,
                        medicine_name VARCHAR(255) NOT NULL,
                        manufacturer VARCHAR(100) DEFAULT 'GEN',
                        batch_number VARCHAR(100) DEFAULT 'B-GEN',
                        expiry_date VARCHAR(50),
                        quantity DECIMAL(10,2) NOT NULL DEFAULT 1.0,
                        mrp DECIMAL(10,2) NOT NULL,
                        taxable_rate DECIMAL(10,2) NOT NULL,
                        discount_percent DECIMAL(5,2) DEFAULT 0.0,
                        gst_rate DECIMAL(5,2) DEFAULT 12.0,
                        cgst_percent DECIMAL(5,2) DEFAULT 6.0,
                        sgst_percent DECIMAL(5,2) DEFAULT 6.0,
                        cgst_amount DECIMAL(10,2) DEFAULT 0.00,
                        sgst_amount DECIMAL(10,2) DEFAULT 0.00,
                        total_amount DECIMAL(10,2) NOT NULL
                    )
                    """)

                    # 8. Patient Visits table check
                    mig_cursor.execute("PRAGMA table_info(patient_visits)")
                    cols_visits = [col[1] for col in mig_cursor.fetchall()]
                    if 'viewed' not in cols_visits:
                        mig_cursor.execute("ALTER TABLE patient_visits ADD COLUMN viewed BOOLEAN DEFAULT 0")

                    # 9. Patient Documents table check
                    mig_cursor.execute("""
                    CREATE TABLE IF NOT EXISTS patient_documents (
                        document_id INTEGER PRIMARY KEY AUTOINCREMENT,
                        patient_id VARCHAR(50) NOT NULL,
                        filename VARCHAR(255) NOT NULL,
                        filepath VARCHAR(500) NOT NULL,
                        description VARCHAR(255),
                        uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE
                    );
                    """)

                    # Ensure investigations list is synchronized once per process local boot
                    if not DBWrapper._investigations_synced:
                        DBWrapper._investigations_synced = True
                        mig_cursor.execute("DELETE FROM investigations_list")
                        
                        # Endoscopy & ENT Procedures
                        mig_cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('FLP Endoscopy', 2000.00, 'Endoscopy & ENT Procedures')")
                        mig_cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('FLP Endoscopy (Pediatric)', 2500.00, 'Endoscopy & ENT Procedures')")
                        mig_cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('OFLP Endoscopy', 2000.00, 'Endoscopy & ENT Procedures')")
                        mig_cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('OFLP Endoscopy (Pediatric)', 2500.00, 'Endoscopy & ENT Procedures')")
                        mig_cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('FLB Endoscopy', 10000.00, 'Endoscopy & ENT Procedures')")
                        mig_cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('PTA Impedance', 1000.00, 'Endoscopy & ENT Procedures')")
                        mig_cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('PTA/SISI', 1200.00, 'Endoscopy & ENT Procedures')")
                        mig_cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('Ear Cleaning (One Side)', 1000.00, 'Endoscopy & ENT Procedures')")
                        mig_cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('Ear Cleaning (Bilateral)', 1500.00, 'Endoscopy & ENT Procedures')")
                        mig_cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('VFT', 1500.00, 'Endoscopy & ENT Procedures')")
                        mig_cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('VNG', 4000.00, 'Endoscopy & ENT Procedures')")
                        mig_cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('Foreign Body Procedure', 1500.00, 'Endoscopy & ENT Procedures')")
                        mig_cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('IT Injection (One Side)', 1500.00, 'Endoscopy & ENT Procedures')")
                        mig_cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('IT Injection (Two Side)', 3000.00, 'Endoscopy & ENT Procedures')")
                        
                        # Laboratory & Diagnostic Tests
                        mig_cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('ECG', 200.00, 'Laboratory & Diagnostic Tests')")
                        mig_cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('Sugar Test', 150.00, 'Laboratory & Diagnostic Tests')")
                        mig_cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('Allergy Test', 3000.00, 'Laboratory & Diagnostic Tests')")
                        mig_cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('Sleep Study', 6000.00, 'Laboratory & Diagnostic Tests')")
                        mig_cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('CPAP Test', 3500.00, 'Laboratory & Diagnostic Tests')")
                        mig_cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('Surgical Profile', 2000.00, 'Laboratory & Diagnostic Tests')")
                        mig_cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('Speech Evaluation', 500.00, 'Laboratory & Diagnostic Tests')")
                        mig_cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('OAE/BERA', 3500.00, 'Laboratory & Diagnostic Tests')")

                    mig_conn.commit()
                except Exception as e:
                    print("Migration/sync warning:", e)
                finally:
                    if mig_conn:
                        try:
                            mig_conn.close()
                        except Exception:
                            pass

    def init_sqlite(self):
        # Create and seed SQLite database
        conn = self._connect_sqlite()
        cursor = conn.cursor()
        cursor.executescript(SQLITE_SCHEMA)
        
        # Check and Seed Default Users
        cursor.execute("SELECT COUNT(*) FROM users")
        if cursor.fetchone()[0] == 0:
            cursor.execute("INSERT INTO users (username, password, role) VALUES ('admin', 'admin123', 'Admin')")
            cursor.execute("INSERT INTO users (username, password, role) VALUES ('doctor', 'doctor123', 'Doctor')")
            cursor.execute("INSERT INTO users (username, password, role) VALUES ('reception', 'reception123', 'Reception')")
            cursor.execute("INSERT INTO users (username, password, role) VALUES ('pharmacy', 'pharmacy123', 'Pharmacy')")
        
        # Check and Seed Reference Investigations
        # We always seed/refresh investigations on boot to keep prices up to date with configuration!
        cursor.execute("DELETE FROM investigations_list")
        # Endoscopy & ENT Procedures
        cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('FLP Endoscopy', 2000.00, 'Endoscopy & ENT Procedures')")
        cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('FLP Endoscopy (Pediatric)', 2500.00, 'Endoscopy & ENT Procedures')")
        cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('OFLP Endoscopy', 2000.00, 'Endoscopy & ENT Procedures')")
        cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('OFLP Endoscopy (Pediatric)', 2500.00, 'Endoscopy & ENT Procedures')")
        cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('FLB Endoscopy', 10000.00, 'Endoscopy & ENT Procedures')")
        cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('PTA Impedance', 1000.00, 'Endoscopy & ENT Procedures')")
        cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('PTA/SISI', 1200.00, 'Endoscopy & ENT Procedures')")
        cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('Ear Cleaning (One Side)', 1000.00, 'Endoscopy & ENT Procedures')")
        cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('Ear Cleaning (Bilateral)', 1500.00, 'Endoscopy & ENT Procedures')")
        cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('VFT', 1500.00, 'Endoscopy & ENT Procedures')")
        cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('VNG', 4000.00, 'Endoscopy & ENT Procedures')")
        cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('Foreign Body Procedure', 1500.00, 'Endoscopy & ENT Procedures')")
        cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('IT Injection (One Side)', 1500.00, 'Endoscopy & ENT Procedures')")
        cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('IT Injection (Two Side)', 3000.00, 'Endoscopy & ENT Procedures')")
        # Laboratory & Diagnostic Tests
        cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('ECG', 200.00, 'Laboratory & Diagnostic Tests')")
        cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('Sugar Test', 150.00, 'Laboratory & Diagnostic Tests')")
        cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('Allergy Test', 3000.00, 'Laboratory & Diagnostic Tests')")
        cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('Sleep Study', 6000.00, 'Laboratory & Diagnostic Tests')")
        cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('CPAP Test', 3500.00, 'Laboratory & Diagnostic Tests')")
        cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('Surgical Profile', 2000.00, 'Laboratory & Diagnostic Tests')")
        cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('Speech Evaluation', 500.00, 'Laboratory & Diagnostic Tests')")
        cursor.execute("INSERT INTO investigations_list (name, default_fee, category) VALUES ('OAE/BERA', 3500.00, 'Laboratory & Diagnostic Tests')")

        # Check and Seed Expenses
        cursor.execute("SELECT COUNT(*) FROM hospital_expenses")
        if cursor.fetchone()[0] == 0:
            cursor.execute("INSERT INTO hospital_expenses (category, item_name, vendor, description, quantity, unit_price, amount, expense_date, payment_method, invoice_number, created_by, remarks) VALUES ('Laboratory Materials', 'Surgical gloves and masks', 'Medipus Supplies', 'Replenishment for ENT clinic', 5, 250.00, 1250.00, datetime('now'), 'Cash', 'INV-2026-001', 'admin', 'Urgent stock needed')")
            cursor.execute("INSERT INTO hospital_expenses (category, item_name, vendor, description, quantity, unit_price, amount, expense_date, payment_method, invoice_number, created_by, remarks) VALUES ('Medical Equipment', 'EUA maintenance kit', 'ENT Tech Solutions', 'ENT equipment maintenance service', 1, 4500.00, 4500.00, datetime('now', '-1 day'), 'Bank Transfer', 'INV-2026-002', 'admin', 'Annual service contract')")
            cursor.execute("INSERT INTO hospital_expenses (category, item_name, vendor, description, quantity, unit_price, amount, expense_date, payment_method, invoice_number, created_by, remarks) VALUES ('Internet', 'Broadband subscription', 'Airtel Broadband', 'Internet connection subscription', 1, 999.00, 999.00, datetime('now', '-2 days'), 'Card', 'INV-2026-003', 'admin', 'Monthly billing')")
            cursor.execute("INSERT INTO hospital_expenses (category, item_name, vendor, description, quantity, unit_price, amount, expense_date, payment_method, invoice_number, created_by, remarks) VALUES ('Stationery', 'Prescription pads', 'Lotus Stationers', 'Registers and prescription pads', 10, 75.00, 750.00, datetime('now'), 'Cash', 'INV-2026-004', 'admin', '')")
            cursor.execute("INSERT INTO hospital_expenses (category, item_name, vendor, description, quantity, unit_price, amount, expense_date, payment_method, invoice_number, created_by, remarks) VALUES ('Staff Salary', 'Salary Receptionist', 'Receptionist Staff', 'Salary June', 1, 15000.00, 15000.00, datetime('now', '-15 days'), 'Bank Transfer', 'SAL-2026-06', 'admin', 'Full month salary')")

        # Check and Seed Patients
        cursor.execute("SELECT COUNT(*) FROM patients")
        if cursor.fetchone()[0] == 0:
            # PAT-001 (Expired Follow-up)
            cursor.execute("""
                INSERT INTO patients (patient_id, patient_name, gender, age, address, phone1, phone2, occupation, consultation_fee, discount_percent, final_amount, payment_mode, registration_date, total_bill, total_paid, remaining_balance, payment_status)
                VALUES ('PAT-001', 'John Doe', 'Male', 45, '12 Baker Street, London', '9876543210', '9876543211', 'Engineer', 500.00, 10.00, 450.00, 'Cash', datetime('now', '-20 days'), 450.00, 450.00, 0.00, 'Paid')
            """)
            cursor.execute("INSERT INTO patient_visits (patient_id, visit_date, fee_charged) VALUES ('PAT-001', datetime('now', '-20 days'), 450.00)")
            cursor.execute("""
                INSERT INTO consultations (patient_id, consultation_date, present_illness, past_history, treatment_history, family_history, personal_history, examination, provisional_diagnosis, complaints, investigation_details, surgery_eligible)
                VALUES ('PAT-001', datetime('now', '-20 days'), 'Slight throat irritation', 'None', 'None', 'None', 'Normal', 'Congestion in throat', 'Pharyngitis', 'Sore Throat;Cough', 'Blood Test', 'No')
            """)
            cursor.execute("INSERT INTO prescriptions (patient_id, medicine_name, duration_days, morning, afternoon, night, dispensed, created_at) VALUES ('PAT-001', 'Amoxicillin 500mg', 5, 1, 1, 1, 'Yes', datetime('now', '-20 days'))")
            cursor.execute("INSERT INTO prescriptions (patient_id, medicine_name, duration_days, morning, afternoon, night, dispensed, created_at) VALUES ('PAT-001', 'Paracetamol 650mg', 3, 1, 0, 1, 'Yes', datetime('now', '-20 days'))")
            cursor.execute("INSERT INTO bills (bill_id, patient_id, bill_date, item_category, description, amount, created_by) VALUES (1, 'PAT-001', datetime('now', '-20 days'), 'Consultation', 'Initial Consultation Fee (10% Discount applied)', 450.00, 'reception')")
            cursor.execute("INSERT INTO payments (transaction_id, patient_id, bill_id, payment_date, amount_paid, payment_method, received_by, remarks) VALUES (1, 'PAT-001', 1, datetime('now', '-20 days'), 450.00, 'Cash', 'reception', 'Initial registration payment')")

            # PAT-002 (Valid Follow-up)
            cursor.execute("""
                INSERT INTO patients (patient_id, patient_name, gender, age, address, phone1, phone2, occupation, consultation_fee, discount_percent, final_amount, payment_mode, registration_date, total_bill, total_paid, remaining_balance, payment_status)
                VALUES ('PAT-002', 'Jane Smith', 'Female', 29, '45 Ring Road, Bangalore', '8887776665', '', 'Teacher', 500.00, 0.00, 500.00, 'Online', datetime('now', '-3 days'), 500.00, 500.00, 0.00, 'Paid')
            """)
            cursor.execute("INSERT INTO patient_visits (patient_id, visit_date, fee_charged) VALUES ('PAT-002', datetime('now', '-3 days'), 500.00)")
            cursor.execute("""
                INSERT INTO consultations (patient_id, consultation_date, present_illness, past_history, treatment_history, family_history, personal_history, examination, provisional_diagnosis, complaints, investigation_details, surgery_eligible)
                VALUES ('PAT-002', datetime('now', '-3 days'), 'Nose bleed at night', 'Hypertension', 'On amlodipine', 'None', 'Normal', 'Dry nasal mucosa with crusting', 'Epistaxis', 'Nose Bleeding;Nasal Blockage', 'Blood Test;CT', 'No')
            """)
            cursor.execute("INSERT INTO prescriptions (patient_id, medicine_name, duration_days, morning, afternoon, night, dispensed, created_at) VALUES ('PAT-002', 'Nasal Moisturizing Spray', 10, 1, 1, 1, 'No', datetime('now', '-3 days'))")
            cursor.execute("INSERT INTO bills (bill_id, patient_id, bill_date, item_category, description, amount, created_by) VALUES (2, 'PAT-002', datetime('now', '-3 days'), 'Consultation', 'Initial Consultation Fee', 500.00, 'reception')")
            cursor.execute("INSERT INTO payments (transaction_id, patient_id, bill_id, payment_date, amount_paid, payment_method, received_by, remarks) VALUES (2, 'PAT-002', 2, datetime('now', '-3 days'), 500.00, 'UPI', 'reception', 'Paid online at registration')")

            # PAT-003 (Limit Exceeded)
            cursor.execute("""
                INSERT INTO patients (patient_id, patient_name, gender, age, address, phone1, phone2, occupation, consultation_fee, discount_percent, final_amount, payment_mode, registration_date, total_bill, total_paid, remaining_balance, payment_status)
                VALUES ('PAT-003', 'Robert C.', 'Male', 52, '88 Residency Heights, Delhi', '9998887776', '9998887777', 'Business Owner', 500.00, 0.00, 500.00, 'Online', datetime('now', '-5 days'), 500.00, 500.00, 0.00, 'Paid')
            """)
            cursor.execute("INSERT INTO patient_visits (patient_id, visit_date, fee_charged) VALUES ('PAT-003', datetime('now', '-5 days'), 500.00)")
            cursor.execute("INSERT INTO patient_visits (patient_id, visit_date, fee_charged) VALUES ('PAT-003', datetime('now', '-3 days'), 0.00)")
            cursor.execute("""
                INSERT INTO consultations (patient_id, consultation_date, present_illness, past_history, treatment_history, family_history, personal_history, examination, provisional_diagnosis, complaints, investigation_details, surgery_eligible)
                VALUES ('PAT-003', datetime('now', '-5 days'), 'Tinnitus in left ear', 'Diabetes', 'Metformin', 'None', 'Normal', 'Retracted tympanic membrane', 'Eustachian Tube Dysfunction', 'Ear Pain;Tinnitus;Ear Block', 'Audiometry;PTA;Impedance', 'Yes')
            """)
            cursor.execute("INSERT INTO bills (bill_id, patient_id, bill_date, item_category, description, amount, created_by) VALUES (3, 'PAT-003', datetime('now', '-5 days'), 'Consultation', 'Initial Consultation Fee', 500.00, 'reception')")
            cursor.execute("INSERT INTO bills (bill_id, patient_id, bill_date, item_category, description, amount, created_by) VALUES (4, 'PAT-003', datetime('now', '-3 days'), 'Follow-up Consultation', 'Follow-up (Free Visit 2 of 2)', 0.00, 'reception')")
            cursor.execute("INSERT INTO payments (transaction_id, patient_id, bill_id, payment_date, amount_paid, payment_method, received_by, remarks) VALUES (3, 'PAT-003', 3, datetime('now', '-5 days'), 500.00, 'UPI', 'reception', 'Paid online at registration')")

            # PAT-004 (Partially Paid / Outstanding)
            cursor.execute("""
                INSERT INTO patients (patient_id, patient_name, gender, age, address, phone1, phone2, occupation, consultation_fee, discount_percent, final_amount, payment_mode, registration_date, total_bill, total_paid, remaining_balance, payment_status)
                VALUES ('PAT-004', 'Mary Cooper', 'Female', 63, '34 Baker St, London', '7776665554', '', 'Retired', 500.00, 0.00, 500.00, 'Cash', datetime('now', '-2 days'), 5500.00, 2500.00, 3000.00, 'Partially Paid')
            """)
            cursor.execute("INSERT INTO patient_visits (patient_id, visit_date, fee_charged) VALUES ('PAT-004', datetime('now', '-2 days'), 500.00)")
            cursor.execute("""
                INSERT INTO consultations (patient_id, consultation_date, present_illness, past_history, treatment_history, family_history, personal_history, examination, provisional_diagnosis, complaints, investigation_details, surgery_eligible)
                VALUES ('PAT-004', datetime('now', '-2 days'), 'Difficulty swallowing', 'Heart disease', 'Aspirin', 'None', 'Normal', 'Redness and swelling in pharynx', 'Tonsillitis', 'Sore Throat;Difficulty Swallowing', 'Blood Test', 'Yes')
            """)
            cursor.execute("INSERT INTO bills (bill_id, patient_id, bill_date, item_category, description, amount, created_by) VALUES (5, 'PAT-004', datetime('now', '-2 days'), 'Consultation', 'Initial Consultation Fee', 500.00, 'reception')")
            cursor.execute("INSERT INTO bills (bill_id, patient_id, bill_date, item_category, description, amount, created_by) VALUES (6, 'PAT-004', datetime('now', '-2 days'), 'Surgery', 'Tonsillectomy Surgery Charge', 4000.00, 'doctor')")
            cursor.execute("INSERT INTO bills (bill_id, patient_id, bill_date, item_category, description, amount, created_by) VALUES (7, 'PAT-004', datetime('now', '-2 days'), 'Room', 'Daycare Recovery Ward Room Rent', 1000.00, 'reception')")
            cursor.execute("INSERT INTO payments (transaction_id, patient_id, bill_id, payment_date, amount_paid, payment_method, received_by, remarks) VALUES (4, 'PAT-004', 5, datetime('now', '-2 days'), 500.00, 'Cash', 'reception', 'Paid for consultation')")
            cursor.execute("INSERT INTO payments (transaction_id, patient_id, bill_id, payment_date, amount_paid, payment_method, received_by, remarks) VALUES (5, 'PAT-004', 6, datetime('now', '-1 day'), 2000.00, 'Bank Transfer', 'reception', 'Partial advance for surgery')")
            
        # Run database migrations for new columns and tables
        try:
            cursor.execute("ALTER TABLE patient_visits ADD COLUMN viewed BOOLEAN DEFAULT 0")
        except sqlite3.OperationalError:
            pass
            
        try:
            cursor.execute("ALTER TABLE prescriptions ADD COLUMN consultation_id INTEGER")
        except sqlite3.OperationalError:
            pass
            
        try:
            cursor.execute("ALTER TABLE prescriptions ADD COLUMN food_relation VARCHAR(20) DEFAULT 'After Food'")
        except sqlite3.OperationalError:
            pass
            
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS patient_documents (
            document_id INTEGER PRIMARY KEY AUTOINCREMENT,
            patient_id VARCHAR(50) NOT NULL,
            filename VARCHAR(255) NOT NULL,
            filepath VARCHAR(500) NOT NULL,
            description VARCHAR(255),
            uploaded_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (patient_id) REFERENCES patients(patient_id) ON DELETE CASCADE
        );
        """)

        conn.commit()
        conn.close()

    def get_conn(self):
        if self.use_sqlite:
            conn = self._connect_sqlite()
            conn.row_factory = dict_factory
            return conn
        else:
            # Let Flask-MySQLdb handle it, which returns the db connection object
            return self.mysql.connection

    def query(self, sql, args=(), one=False, commit=False):
        # Translate common MySQL functions to SQLite if using SQLite
        if self.use_sqlite:
            # Translate the small MySQL SQL subset used by this application
            # into SQLite-compatible expressions before binding parameters.
            sql = sql.replace("CURDATE()", "date('now')")
            sql = sql.replace("NOW()", "datetime('now')")
            sql = sql.replace("COALESCE", "coalesce")
            sql = sql.replace("LAST_INSERT_ID()", "last_insert_rowid()")
            sql = sql.replace("INTERVAL 20 DAY", "'-20 days'")
            sql = sql.replace("INTERVAL 3 DAY", "'-3 days'")
            sql = sql.replace("INTERVAL 5 DAY", "'-5 days'")

            # DATE_FORMAT is used by a few legacy/MySQL report queries.
            # SQLite's equivalent is strftime().
            import re
            sql = re.sub(
                r"DATE_FORMAT\(([^,()]+),\s*'%Y-%m'\)",
                r"strftime('%Y-%m', \1)",
                sql,
                flags=re.IGNORECASE,
            )
            sql = re.sub(
                r"DATE_FORMAT\(([^,()]+),\s*'%Y'\)",
                r"strftime('%Y', \1)",
                sql,
                flags=re.IGNORECASE,
            )

            # Convert simple CONCAT(...) calls used by ledger/report queries.
            # These arguments are intentionally simple SQL expressions.
            def _sqlite_concat(match):
                parts = [part.strip() for part in match.group(1).split(",")]
                return " || ".join(parts)

            sql = re.sub(
                r"CONCAT\(([^()]*)\)",
                _sqlite_concat,
                sql,
                flags=re.IGNORECASE,
            )

            # MySQLdb uses %s placeholders; SQLite uses ?.
            sql = sql.replace("%s", "?")

        conn = self.get_conn()
        cursor = conn.cursor()
        
        try:
            cursor.execute(sql, args)
            if commit:
                conn.commit()
                # Return last insert row id for inserts
                if self.use_sqlite:
                    result = cursor.lastrowid
                else:
                    result = cursor.lastrowid or True
            else:
                if self.use_sqlite:
                    rv = cursor.fetchall()
                else:
                    # In Flask-MySQLdb we use cursors
                    import MySQLdb.cursors
                    rv = cursor.fetchall()
                result = (rv[0] if rv else None) if one else rv
        except Exception as e:
            if commit:
                conn.rollback()
            raise e
        finally:
            cursor.close()
            if self.use_sqlite:
                conn.close()
                
        return result
